# Databricks notebook source
max_date=spark.sql("""show partitions odh_horizon_cdb_landing.cur_milestone_planned""").rdd.flatMap(lambda x:x).map(lambda x : x.replace("tran_date=","")).max()

# COMMAND ----------

# MAGIC %md
# MAGIC create the dataframe
# MAGIC add column
# MAGIC selecting the columns - iloc and loc
# MAGIC rename column
# MAGIC create new column from existing data
# MAGIC drop column
# MAGIC data cleansing - fillna values
# MAGIC dropna values
# MAGIC case statements-
# MAGIC
# MAGIC select top 5 records
# MAGIC select bottom 5 records
# MAGIC index the records using the column names
# MAGIC joining on indexes and multiple columns
# MAGIC horizontal join - join and merge
# MAGIC vertical join - concat
# MAGIC pivot and unpivot using pandas
# MAGIC aggregation using pandas
# MAGIC iloc and loc

# COMMAND ----------

# MAGIC %md
# MAGIC String Operation: Pandas provide a set of string functions for working with string data. The following are the few operations on string data:
# MAGIC lower(): Any strings in the index or series are converted to lowercase letters.
# MAGIC upper(): Any strings in the index or series are converted to uppercase letters.
# MAGIC strip(): This method eliminates spacing from every string in the Series/index, along with a new line.
# MAGIC islower(): If all of the characters in the Series/Index string are lowercase, it returns True. Otherwise, False is returned.
# MAGIC isupper(): If all of the characters in the Series/Index string are uppercase, it returns True. Otherwise, False is returned.
# MAGIC split(’ '): It’s a method that separates a string according to a pattern.
# MAGIC cat(sep=’ '): With a defined separator, it concatenates series/index items.
# MAGIC contains(pattern): If a substring is available in the current element, it returns True; otherwise, it returns False.
# MAGIC replace(a,b): It substitutes the value b for the value a.
# MAGIC startswith(pattern): If all of the components in the series begin with a pattern, it returns True.
# MAGIC endswith(pattern): If all of the components in the series terminate in a pattern, it returns True.
# MAGIC find(pattern): It can be used to return the pattern’s first occurrence.
# MAGIC findall(pattern): It gives you a list of all the times the pattern appears.
# MAGIC swapcase: It is used to switch the lower/upper case.
# MAGIC Null values: When no data is being sent to the items, a Null value/missing value can appear. There may be no values in the respective columns, which are commonly represented as NaN. Pandas provide several useful functions for identifying, deleting, and changing null values in Data Frames. The following are the functions.
# MAGIC isnull(): isnull 's job is to return true if either of the rows has null values.
# MAGIC notnull(): It is the inverse of the isnull() function, returning true values for non-null values.
# MAGIC dropna(): This function evaluates and removes null values from rows and columns.
# MAGIC fillna(): It enables users to substitute other values for the NaN values.
# MAGIC replace(): It’s a powerful function that can take the role of a regex, dictionary, string, series, and more.
# MAGIC interpolate(): It’s a useful function for filling null values in a series or data frame.
# MAGIC Row and column selection: We can retrieve any row and column of the DataFrame by specifying the names of the rows and columns. It is one-dimensional and is regarded as a Series when you select it from the DataFrame.
# MAGIC Filter Data: By using some of the boolean logic in DataFrame, we can filter the data.
# MAGIC Count Values: Using the ‘value counts()’ option, this process is used to count the overall possible combinations.
# MAGIC 7. Compare the Pandas methods: map(), applymap(), apply()

# COMMAND ----------

# MAGIC %md
# MAGIC #Create Dataframe

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from default.nba_2
# MAGIC -- dbfs:/user/hive/warehouse/nba_2

# COMMAND ----------

# DBTITLE 1,Pandas
import pandas as pd 

data = pd.read_csv("dbfs:/user/hive/warehouse/nba_2.csv", index_col ="Name") 
first = data["Age"] 
print(first) 

# code for pandas to read the csv file. 
# Below code read the csv file uploaded from the delta storage 

# COMMAND ----------

# DBTITLE 1,Pyspark
df =spark.read.format("delta").load("dbfs:/user/hive/warehouse/nba_2")
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC #Show dataframe

# COMMAND ----------

# DBTITLE 1,pandas
df_pd = df.toPandas()
print(type(df))
print(type(df_pd))
df_pd

# COMMAND ----------

# DBTITLE 1,pyspark
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC #select columns
# MAGIC

# COMMAND ----------

# DBTITLE 1,pandas

#retrieving multiple columns by indexing operator 

df_pd[['Name', 'Team', 'Number', 'Position', 'Age']]

# COMMAND ----------

df_pd[df_pd['Name'] == "Jeff Withey" ]

# COMMAND ----------

# DBTITLE 1,pyspark
df.select("Name","Age").show(truncate = False)

# COMMAND ----------

# MAGIC %md
# MAGIC #add columns

# COMMAND ----------

import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 11, 12], 'Marks': [85, 77, 91]}

student_df = pd.DataFrame(student_dict)
print(student_df)

address = ['Chicago', 'London', "Berlin" ]
student_df['Address'] = address
  
print(student_df)

# COMMAND ----------

# MAGIC %md
# MAGIC # df.insert()

# COMMAND ----------

import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 11, 12], 'Marks': [85, 77, 91]}

student_df = pd.DataFrame(student_dict)
print(student_df)

# add a column at any position we like and not just at the end.
address = ['Chicago', 'London', 'Berlin']
student_df.insert(2, "Address", ['Chicago', 'London', 'Berlin'], True)

print(student_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #df.assign()

# COMMAND ----------

# MAGIC %md
# MAGIC Using Dataframe.assign() method: This method will create a new dataframe with a new column added to the old dataframe.

# COMMAND ----------

import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 11, 12], 'Marks': [85, 77, 91]}

# create DataFrame from dict
student_df = pd.DataFrame(student_dict)
print(student_df)
df2 = student_df.assign(address=['Chicago', 'London', 'Berlin'])
  
# Observe the result
print(df2)

# COMMAND ----------

# MAGIC %md
# MAGIC # add rows

# COMMAND ----------

# DBTITLE 1,pandas
import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 11, 12], 'Marks': [85, 77, 91]}

student_df = pd.DataFrame(student_dict)
print(student_df)

print("The number of index/records : ",len(student_df.index))

student_df.loc[len(student_df.index)] = ['Alex', 19, 93]

print(student_df)

# COMMAND ----------

# DBTITLE 1,pyspark
data = [('James', 'Sales', 3000),
        ('Michael', 'Sales', 4600),
        ('Robert', 'Sales', 4100)]
columns = ["Employee", "Department", "Salary"]
df = spark.createDataFrame(data, columns)
df.show()

# COMMAND ----------

new_row = spark.createDataFrame([('Maria', 'Marketing', 4000)], columns)

# COMMAND ----------

df = df.union(new_row)
df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC #df.drop()
# MAGIC delete the rows data/ index 

# COMMAND ----------

# DBTITLE 1,delete row
import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 11, 12], 'Marks': [85, 77, 91]}

student_df = pd.DataFrame(student_dict)
print(student_df)

student_df = student_df.set_index('Name')
print(student_df)

student_df.drop(["Harry"],axis = 0, inplace = True)
student_df

# COMMAND ----------

import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 11, 12], 'Marks': [85, 77, 91]}

student_df = pd.DataFrame(student_dict)
print(student_df)

student_df.drop(student_df[student_df['Name'] == 'Harry'].index, inplace=True)
student_df

# COMMAND ----------

# DBTITLE 1,delete column
import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 11, 12], 'Marks': [85, 77, 91]}

student_df = pd.DataFrame(student_dict)
print(student_df)

student_df.drop(["Age"], axis = 1, inplace = True)
print(student_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #df.append()

# COMMAND ----------

# MAGIC %md
# MAGIC df.append() and df.concat() are using to add rows to df- vertically

# COMMAND ----------

df2 = {'Name': 'Tom', 'Age': 18, 'Marks': 73}
student_df = student_df.append(df2, ignore_index = True)
print(student_df)

# COMMAND ----------

# MAGIC %md
# MAGIC # df.concat()

# COMMAND ----------

import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 14, 12], 'Marks': [85, 77, 91]}

# create DataFrame from dict
df = pd.DataFrame(student_dict)
print(df)

dict = {'Name':['Amy', 'Maddy'],
        'Age':[19, 12],
        'Marks':[93, 81]
       }
df2 = pd.DataFrame(dict)
print(df2)
df3 = pd.concat([df1, df2], ignore_index = True)

print(df3)

# COMMAND ----------

# MAGIC %md
# MAGIC # set index

# COMMAND ----------

# DBTITLE 1,Pandas DataFrame
import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 11, 12], 'Marks': [85, 77, 91]}

student_df = pd.DataFrame(student_dict)
print(student_df)

student_df = student_df.set_index('Name')
print(student_df)

# COMMAND ----------

student_df[student_df['Kate']]

# COMMAND ----------

import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 10, 12], 'Marks': [85, 77, 91]}

student_df = pd.DataFrame(student_dict)
print(student_df)

student_df = student_df.set_index('Age')
print(student_df)

# COMMAND ----------

# MAGIC %md
# MAGIC student_df[student_df['Name'] == "Kate"] will work with columns but not with indexes

# COMMAND ----------

import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 11, 12], 'Marks': [85, 77, 91]}

student_df = pd.DataFrame(student_dict)
print(student_df)

student_df.drop(student_df[student_df['Name'] == 'Harry'].index, inplace=True)
student_df

# COMMAND ----------

# print(student_df[student_df['Age'] == 10])
student_df[student_df['Name'] == "Kate"]

# COMMAND ----------

import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 11, 12], 'Marks': [85, 77, 91]}

student_df = pd.DataFrame(student_dict)
print(student_df)

student_df = student_df.set_index(['Name', 'Marks'])
print(student_df)

# COMMAND ----------

# create DataFrame from dict - creating multi index
import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 11, 12], 'Marks': [85, 77, 91]}

student_df = pd.DataFrame(student_dict)
print(student_df)

index = pd.Index(['x1', 'x2', 'x3'])
student_df = student_df.set_index([index, 'Name'])
print(student_df)

# COMMAND ----------

# DBTITLE 1,select columns
student_df['Age'] 

# COMMAND ----------

# DBTITLE 1,Rename Index
import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 
                'Age': [10, 11, 12], 
                'Marks': [85, 77, 91]
                }
student_df = pd.DataFrame(student_dict)
print(student_df)

student_df = student_df.set_index('Name')
print(student_df)

student_df.index.names = ['FirstName']
print(student_df)

# COMMAND ----------

# DBTITLE 1,Reset index
import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 11, 12], 'Marks': [85, 77, 91]}

student_df = pd.DataFrame(student_dict)
print(student_df)

student_df = student_df.set_index('Name')
print(student_df)

student_df.reset_index(drop=True, inplace=True)
print(student_df)

# COMMAND ----------

# DBTITLE 1,access rows with index
import pandas as pd

employees = [('Stuti', 28, 'Varanasi', 20000),
			('Saumya', 32, 'Delhi', 25000),
			('Aaditya', 25, 'Mumbai', 40000),
			('Saumya', 32, 'Delhi', 35000),
			('Saumya', 32, 'Delhi', 30000),
			('Saumya', 32, 'Mumbai', 20000),
			('Aaditya', 40, 'Dehradun', 24000),
			('Seema', 32, 'Delhi', 70000)
			]

df = pd.DataFrame(employees,columns =['Name', 'Age','City', 'Salary'])
df

# COMMAND ----------

# DBTITLE 1,loc[[index]]

# Set index on a Dataframe
df.set_index("Name",inplace = True)
 
# Using the operator .loc[]
# to select multiple rows
result = df.loc[["Stuti", "Seema"]]
 
# Show the dataframe
result

# COMMAND ----------

# DBTITLE 1,loc[[index],[column]]
# Set 'Name' column as index
# on a Dataframe
# df.set_index("Name", inplace = True)

# Using the operator .loc[] to
# select multiple rows with some
# particular columns
result = df.loc[["Stuti", "Seema"],
			["City", "Salary"]]

# Show the dataframe
result

# COMMAND ----------

result = df["City"]
 
result

# COMMAND ----------

result = df[[ "Age", "Salary"]]
 
result

# COMMAND ----------

result = df.loc[:, ["City", "Salary"]]
 
result

# COMMAND ----------

# DBTITLE 1,filter
delhi_employees = df[df['City'] == 'Delhi']
print(delhi_employees)

# COMMAND ----------

# MAGIC %md
# MAGIC #filter

# COMMAND ----------

import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 14, 12], 'Marks': [85, 77, 91]}

df = pd.DataFrame(student_dict)
print(df)

df1 = df[df['Age'] > 10]

df1

# COMMAND ----------

# DBTITLE 1,iloc[[index],[column]]
result = df.iloc[:, [0, 1]]
result

# COMMAND ----------

# MAGIC %md
# MAGIC #unique

# COMMAND ----------

import pandas as pd
s = pd.Series(data = [1,2,3,4,3,5,3,7,1])
print(s)
print(s.value_counts())

# COMMAND ----------

# MAGIC %md
# MAGIC #isin

# COMMAND ----------

import pandas as pd

series1 = pd.Series([12, 24, 38, 210, 110, 147, 929])
series2 = pd.Series([17, 83, 76, 54, 110, 929, 510])

print("Series1:")
print(series1)
print("\nSeries2:")
print(series2)

print("\nItems of series1 not present in series2:")
res = series1[~series1.isin(series2)]
print(res)

# COMMAND ----------

# MAGIC %md
# MAGIC #groupBy

# COMMAND ----------

import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 14, 12], 'Marks': [85, 77, 91]}

df = pd.DataFrame(student_dict)
print(df)

gk = df.groupby('Age')
gk.first()

# COMMAND ----------

# MAGIC %md
# MAGIC #aggregate

# COMMAND ----------

import pandas as pd

data = {
  "x": [560, 240, 630],
  "y": [300, 1112, 452]
}

df = pd.DataFrame(data)

x = df.aggregate(["sum"])
y = df.aggregate(["min"])
z = df.aggregate(["max"])

print(x)
print(y)
print(z)

# COMMAND ----------

# MAGIC %md
# MAGIC #pivot 

# COMMAND ----------

import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 14, 12], 'Marks': [85, 77, 91]}
 
df = pd.DataFrame(student_dict)
print(df)

table = pd.pivot_table(df, index =['Name', 'Age'])
print(table)

# COMMAND ----------

# MAGIC %md
# MAGIC What’s the difference between pivot_table() and groupby()?
# MAGIC Both pivot_table() and groupby() are used to aggregate your dataframe. The major difference is in the shape of the result.

# COMMAND ----------

import pandas as pd

student_dict = {'Name': ['Kate', 'Harry', 'Sheila'], 'Age': [10, 14, 12], 'Marks': [85, 77, 91]}

df = pd.DataFrame(student_dict)
print(df)

gk = df.groupby('Age')
gk.first()

# COMMAND ----------

# MAGIC %md
# MAGIC #timedelta
# MAGIC

# COMMAND ----------

import pandas as pd
import numpy as np
    
td = pd.Timedelta('5 days 09:08:03.000000312')


print(td)
print(td.seconds)

# COMMAND ----------

List = [1, 2, 'Geeks', 4, 'For', 6, 'Geeks']

print(List[-1])

print(List[-3])

# COMMAND ----------

# MAGIC %md
# MAGIC #numpy

# COMMAND ----------

import pandas as pd

# initialize a dataframe
df = pd.DataFrame(
	[[10, 12, 33],
	[41, 53, 66],
	[17, 81, 19],
	[10, 11, 12]],

columns=['X', 'Y', 'Z'])

print("df",type(df))

py_df = spark.createDataFrame(df)
print("py_df",type(py_df))

pd_df = py_df.toPandas()
print("pd_df",type(pd_df))

arr = df.to_numpy()
print("arr",type(arr))

print('\nNumpy Array\n----------\n', arr)

# COMMAND ----------

import pandas as pd
import random

A = [ random.randint(0,100) for i in range(10) ]
B = [ random.randint(0,100) for i in range(10) ]

df = pd.DataFrame({ 'field_A': A, 'field_B': B })
print(df)


print(df.field_A.quantile(0.1)) # 10th percentile


print(df.field_A.quantile(0.5)) # same as median

print(df.field_A.quantile(0.9)) # 90th percentile

# COMMAND ----------

dbutils.fs.ls("dbfs:/user/hive/warehouse/.csv",