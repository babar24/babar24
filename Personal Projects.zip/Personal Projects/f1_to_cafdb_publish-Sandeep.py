# Databricks notebook source
# MAGIC %run CAFDB/cafdb_publish/notebook/common/common_ingestion_util

# COMMAND ----------

# MAGIC %run CAFDB/cafdb_publish/notebook/CA_MarketPlace/CA_MarketPlace_Phase1

# COMMAND ----------

cafdb-publish/cafdb_publish/notebook/CA_MarketPlace/CA_MarketPlace_Phase1.py

# COMMAND ----------

dbutils.library.help("list")

# COMMAND ----------

import os
import json
import boto3
# import itertoolssource_file_path
from pyspark.sql.functions import *
from decimal import Decimal
from collections import Counter
from boto3.dynamodb.conditions import Key
from pyspark.sql import Row
from boto3.dynamodb.types import TypeDeserializer
from boto3.dynamodb.transform import TransformationInjector
import pandas as pd
import calendar
from datetime import date,timedelta
from pyspark.sql import DataFrame
from datetime import datetime


# COMMAND ----------

def copy_source_files(files):
    source_path = files
    archive_path = source_path.replace("pre_landing","archive")
    dbutils.fs.mv(source_path,archive_path,True)
    print("archived file from {} to {}".format(source_path,archive_path))

# COMMAND ----------

def rds_db_screts(rds_db_name):

  if rds_db_name == 'CPP':
    scope_key = "f1_cafdb_cpp_publish"
  elif rds_db_name == 'FLAIR':
    scope_key = "f1_cafdb_flair_publish"
  elif rds_db_name == 'CAFDB':
    scope_key = "f1_cafdb_publish"
  elif rds_db_name == 'RDI':
    scope_key = "f1_cafdb_rdi_publish"
  else:
    scope_key = "f1_super_cafdb_publish"
  secrets_key = "rds_cafdb"
  driver = "org.postgresql.Driver"
  secrets = {"jdbcUsername": dbutils.secrets.get(scope=scope_key, key=secrets_key+"_user_name"),
               "jdbcPassword": dbutils.secrets.get(scope=scope_key, key=secrets_key+"_password"),
               "jdbcUrl": dbutils.secrets.get(scope=scope_key, key=secrets_key+"_jdbc_url")
              }
  return secrets

# COMMAND ----------

dbutils.widgets.get('fruits_combobox')

# COMMAND ----------

dbutils.widgets.multiselect(
  name='days_multiselect',
  defaultValue='Tuesday',
  choices=['Monday', 'Tuesday', 'Wednesday', 'Thursday',
    'Friday', 'Saturday', 'Sunday'],
  label='Days of the Week'
)

print(dbutils.widgets.get("days_multiselect"))

# COMMAND ----------

dbutils.widgets.text(
  name='your_name_text',
  defaultValue='Sandeep S Gutte',
  label='Your name'
)

print(dbutils.widgets.get("your_name_text"))

# COMMAND ----------

dbutils.widgets.get('age')

# COMMAND ----------

dbutils.widgets.dropdown(
  name='toys_dropdown',
  defaultValue='cape',
  choices=['alphabet blocks', 'basketball', 'cape', 'doll'],
  label='Toys'
)

print(dbutils.widgets.get("toys_dropdown"))

# COMMAND ----------

dbutils.widgets.combobox(
  name='fruits_combobox',
  defaultValue='apple',
  choices=['apple', 'banana', 'coconut', 'dragon fruit'],
  label='Fruits'
)

print(dbutils.widgets.get("fruits_combobox"))


# COMMAND ----------

dbutils.widgets.help()

# COMMAND ----------

dbutils.secrets.listScopes()

# COMMAND ----------

# dbutils.secrets.get(scope="f1_super_cafdb_publish", key="rds_cafdb")
dbutils.secrets.get(scope='etl-framework', key='storage_account')


# COMMAND ----------

dbutils.secrets.help("get")

# COMMAND ----------

# dbutils.notebook.help()
dbutils.fs.help()
# dbutils.fs.ls('dbfs:/')
# dbutils.credentials.help("showCurrentRole")
# dbutils.credentials.showCurrentRole()
# dbutils.help()

# COMMAND ----------

dbutils.fs.head("/FileStore/tables/RDI_Data/RDI_TMO_GRANULAR_ACTUALS.csv",500)

# COMMAND ----------

dbutils.credentials.assumeRole("arn:aws:iam::123456789012:roles/my-role")

# COMMAND ----------

dbutils.credentials.showRoles()

# Out[1]: ['arn:aws:iam::123456789012:role/my-role-a', 'arn:aws:iam::123456789012:role/my-role-b']