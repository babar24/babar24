# Databricks notebook source
# MAGIC %run CAFDB/cafdb_publish/notebook/common/common_ingestion_util

# COMMAND ----------

def rds_db_screts(rds_db_name):

  if rds_db_name == 'CPP':
    scope_key = "f1_cafdb_cpp_publish"
  elif rds_db_name == 'FLAIR':
    scope_key = "f1_cafdb_flair_publish"
  elif rds_db_name == 'CAFMART':
    scope_key = "f1_cafdb_cafmart_publish"
  elif rds_db_name == 'GDOLT':
    scope_key = "f1_cafdb_gdolt_publish"
  elif rds_db_name == 'ADHOC':
    scope_key = "f1_cafdb_adhoc_publish"
  elif rds_db_name == 'CA_TMOMETER':
        scope_key = "f1_cafdb_tmometer_publish"
  elif rds_db_name == 'CAFDB':
    scope_key = "f1_cafdb_publish"
  elif rds_db_name == 'RDI':
    scope_key = "f1_cafdb_rdi_publish"
  else:
    scope_key = "f1_super_cafdb_publish"
  secrets_key = "rds_cafdb"
  driver = "org.postgresql.Driver"
  secrets = {"jdbcUsername": dbutils.secrets.get(scope=scope_key, key=secrets_key+"_user_name"),
               "jdbcPassword": dbutils.secrets.get(scope=scope_key, key=secrets_key+"_password"),
               "jdbcUrl": dbutils.secrets.get(scope=scope_key, key=secrets_key+"_jdbc_url")
              }
  return secrets

# COMMAND ----------

def rds_table_read(table_name,db_name):
  driver = "org.postgresql.Driver"
  secrets = rds_db_screts(db_name)
  print(secrets)
#   db_table = "test"
  df_read_metadata=spark.read \
  .format("jdbc") \
  .option("url", secrets['jdbcUrl']) \
  .option("fetchsize", 1000) \
  .option("dbtable", table_name) \
  .option("user", secrets['jdbcUsername']) \
  .option("password", secrets['jdbcPassword']) \
  .option("driver", "com.mysql.jdbc.Driver") \
  .load()
  df_read_metadata.createOrReplaceTempView('tmp_'+table_name)
  return df_read_metadata

# COMMAND ----------

rds_table_read('RDI_COMPLIANCE_DATA','RDI')

# COMMAND ----------

# MAGIC %md
# MAGIC ###Dates

# COMMAND ----------

a=spark.sql("""
SELECT 
TO_DATE(CAST(UNIX_TIMESTAMP(first_timesheet, 'dd-MMM-yy') AS timestamp)) as first_timesheet,
TO_DATE(CAST(UNIX_TIMESTAMP(TIME_PERIOD, 'dd-MMM-yy') AS timestamp)) as TIME_PERIOD,
-- add_months(last_day(TO_DATE(CAST(UNIX_TIMESTAMP(TIME_PERIOD, 'dd-MMM-yy') AS timestamp))+1),-1) as FYP_DATE,
date_format(TO_DATE(CAST(UNIX_TIMESTAMP(TIME_PERIOD, 'dd-MMM-yy') AS timestamp)),'yyyy-MM'||'-01') as PDATE, 
date_format(TO_DATE(CAST(UNIX_TIMESTAMP(TIME_PERIOD, 'dd-MMM-yy') AS timestamp)),'MMM-yyyy') as YrMth_Mod,
date_format(TO_DATE(CAST(UNIX_TIMESTAMP(TIME_PERIOD, 'dd-MMM-yy') AS timestamp)),'yyMM') as YrMth
FROM tmp_RDI_COMPLIANCE_DATA
""")

# COMMAND ----------

display(a)

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select current_date() as CD, 
# MAGIC current_timestamp() as CT,
# MAGIC unix_date(current_date()) as UD,
# MAGIC unix_timestamp(current_date()) as UT,
# MAGIC unix_timestamp('12:00:00', 'HH:mm:ss') UHMS,
# MAGIC unix_timestamp(current_timestamp(), 'yyyy-MM-dd HH:mm:ss')as ,
# MAGIC date_format("12-Oct-2024")
# MAGIC
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

max_date=spark.sql("""show partitions odh_horizon_reporting_dm_landing.v_wp_single_current""").rdd.flatMap(lambda x:x).map(lambda x : x.replace("tran_date=","")).max()

partition_where = max_date.replace("/"," and ")

print(partition_where)


# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC show partitions odh_horizon_reporting_dm_landing.v_wp_single_current

# COMMAND ----------

from pyspark.sql import SparkSession
spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()
data = [("James","M",60000),
        ("Michael","M",70000),
        ("Robert",None,400000),
        ("Maria","F",500000),
        ("Jen","",None)]

columns = ["name","gender","salary"]
df = spark.createDataFrame(data = data, schema = columns)
df.show()

# COMMAND ----------

from pyspark.sql.functions import when
import re
df2 = df.withColumn("new_gender", when(df.gender == "M","Male")
                                 .when(df.gender == "F","Female")
                                 .when(df.gender.isNull() ,"")
                                 .otherwise(df.gender))
df2.show()

# COMMAND ----------

spark.conf.get("spark.sql.shuffle.partitions")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Excel Read
# MAGIC

# COMMAND ----------

dfs1 = spark.read.format("com.crealytics.spark.excel") \
  .option("location", "s3a://novartisrs3aprdief1prelanding001/pre_landing/cafdb/rdi/NDR_ALLOCATION.xlsx") \
  .option("useHeader", "true") \
  .option("Header", "true") \
  .option("treatEmptyValuesAsNulls", "false") \
  .option("inferSchema", "true") \
  .option("addColorColumns", "false") \
  .load("s3a://novartisrs3aprdief1prelanding001/pre_landing/cafdb/rdi/NDR_ALLOCATION.xlsx")
schema = dfs1.schema.json()

# COMMAND ----------

schema = Custom_Schema().get_schema_from_json("/dbfs/FileStore/tables/NDR_ALLOCATION.json")
source_name_path = "s3a://novartisrs3aqaief1prelanding001/pre_landing/cafdb/rdi/NDR_ALLOCATION.xlsx"
dfs1 = spark.read.format("com.crealytics.spark.excel") \
.option("location", source_name_path) \
.option("header", "true") \
.option("useHeader", "true") \
.option("Header", "true") \
.option("treatEmptyValuesAsNulls", "false") \
.option("inferSchema", "true") \
.option("addColorColumns", "false") \
.schema(schema) \
.load("s3a://novartisrs3aqaief1prelanding001/pre_landing/cafdb/rdi/NDR_ALLOCATION.xlsx")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Access Specifiers
# MAGIC

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ### __init__()

# COMMAND ----------

# initialising class
class Demo:

	# defining a constructor
	def __init__(self, name):

		self.name = name
		print("Initialised value is", self.name)


# Driver code
obj1 = Demo("GFG")
obj2 = Demo("Geeks")
obj3 = Demo("GeeksForGeeks")


# COMMAND ----------

# initialising class
class Demo:

	# defining a constructor
	def __init__(self):
		print("Init for base class")


class child(Demo):

	def __init__(self):
		Demo.__init__(self)
		print("Init for the child class")


# Driver code
obj1 = Demo()
obj2 = child()


# COMMAND ----------

# MAGIC %md
# MAGIC So here also we can see that we can access the constructor for base class from child class which violates the property of private methods.
# MAGIC
# MAGIC Private methods in Python
# MAGIC Here we are trying to access a private method outside a class and we get an error for the same, but in Python, we can access a private method also using the concept of Name Mangling.

# COMMAND ----------

# Creating a class
class Demo:

	# Declaring public method
	def f(self):
		print("Public method")

	# Declaring private method
	def __f(self):
		print("Private method")


# Driver's code
obj = Demo()
obj.f()

print("Using the concept of name mangling")
obj._Demo__f()

print("Without using name mangling")
obj.__f()


# COMMAND ----------

# MAGIC %md
# MAGIC Conclusion
# MAGIC So we can conclude that __init__ is not a private method, In Python, there’s nothing like private/protected by technique, it’s just a convention, and we can access private/protected methods. It’s more like a convention, rather than a technique. It is advised that we should follow this convention for better understanding.
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Name Mangling
# MAGIC

# COMMAND ----------

class Demo:
	# Declaring public method
	def f(self):
		print("Public method")

	# Declaring private method
	def __f(self):
		print("Private method")

# Driver's code
obj = Demo()
obj.f()

print("Using the concept of name mangling")
obj._Demo__f()

print("Without using name mangling")
obj.__f()


# COMMAND ----------

# name mangling 
class Student: 
	def __init__(self, name): 
		self.__name = name 

	def displayName(self): 
		print(self.__name) 

s1 = Student("Santhosh") 
s1.displayName() 

# Raises an error 
print(s1.__name) 


# COMMAND ----------

# Python program to demonstrate 
# name mangling 
class Student: 
	def __init__(self, name): 
		self.__name = name 

s1 = Student("Santhosh") 
print(dir(s1)) 


# COMMAND ----------

# MAGIC %md
# MAGIC ###Iterator
# MAGIC

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ###Generator
# MAGIC

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Enumerator

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ##all  
# MAGIC The Python all() function returns true if all the elements of a given iterable (List, Dictionary, Tuple, set, etc.) are True otherwise it returns False. It also returns True if the iterable object is empty. Sometimes while working on some code if we want to ensure that user has not entered a False value then we use the all() function.

# COMMAND ----------

print(all([True, True, False,True]))

# COMMAND ----------

# MAGIC %md
# MAGIC #Star Pattern

# COMMAND ----------

def print_star_pattern(rows):
    for i in range(1, rows + 1):
        print("X" * (rows - i), end='')
        print('* ' * i)

num_rows = 5
print_star_pattern(num_rows)

# COMMAND ----------

rows = 10

for i in range (1, rows+1):
  print(' ' * (rows-i), end='')
  print('* ' * i)