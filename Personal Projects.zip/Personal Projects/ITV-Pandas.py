# Databricks notebook source
# MAGIC %md
# MAGIC ###Concat
# MAGIC

# COMMAND ----------

import pandas as pd
import numpy as np
 
df1 = pd.DataFrame(np.random.randint(25, size=(4, 4)), 
                   index=["1", "2", "3", "4"], 
                   columns=["A", "B", "C", "D"])
 
df2 = pd.DataFrame(np.random.randint(25, size=(6, 4)),
                   index=["5", "6", "7", "8", "9", "10"], 
                   columns=["A", "B", "C", "D"])
 
df3 = pd.DataFrame(np.random.randint(25, size=(4, 4)),
                   columns=["A", "B", "C", "D"])
 
df4 = pd.DataFrame(np.random.randint(25, size=(4, 4)),
                   columns=["E", "F", "G", "H"])
 
# display(df1, df2, df3, df4)
display(df1)
display(df2)

# COMMAND ----------

display(df3)
display(df4)

# COMMAND ----------

# concatenating df1 and df2 along rows
vertical_concat = pd.concat([df1, df2], axis=0)
display(vertical_concat)


# COMMAND ----------

# concatenating df3 and df4 along columns
horizontal_concat = pd.concat([df3, df4], axis=1)
display(horizontal_concat)


# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql import functions as f
spark = SparkSession.builder \
.appName("split function") \
.getOrCreate()

from pyspark.sql import Row

data = [
Row(employee_id=1, age_gender='M=25'),
Row(employee_id=2, age_gender='M=25'),
Row(employee_id=3, age_gender='M=25'),
Row(employee_id=4, age_gender='M=25'),
Row(employee_id=5, age_gender='M=25')
]

df=spark.createDataFrame(data)
display(df)
df=df.withColumn("gender",f.split(df["age_gender"],"=").getItem(0))

df=df.withColumn("age",f.split(df["age_gender"],"=").getItem(1))
df.show()

# COMMAND ----------

a = 3
b = 5

print(a and b)
print(b and a)

# COMMAND ----------

import numpy as np
import pandas as pd

pd.set_option("display.precision", 2)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Series
# MAGIC

# COMMAND ----------

ser = pd.Series([12,23,34,54,78,32,45,78.6,23,90.5])

# COMMAND ----------

type(ser)

# COMMAND ----------

ser.name = "Sandeep Weight"

# COMMAND ----------

ser

# COMMAND ----------

ser

# COMMAND ----------

ser[1]

# COMMAND ----------

ser.index

# COMMAND ----------

ser.index = ['a','b','c','d','f','g','h','i','j','k']

# COMMAND ----------

ser

# COMMAND ----------

ser = ser * 1000

# COMMAND ----------

ser 

# COMMAND ----------

ser > 50000

# COMMAND ----------

ser[ser > 50000]

# COMMAND ----------

ser

# COMMAND ----------

ser.mean()

# COMMAND ----------

ser.memory_usage()

# COMMAND ----------

ser.median()

# COMMAND ----------

ser[(ser > 50000) & (ser < 70000)]

# COMMAND ----------

ser.iloc[8]

# COMMAND ----------

ser.iloc[0] 
# ser.iloc[9]

# COMMAND ----------

# MAGIC %md
# MAGIC ### DataFrames

# COMMAND ----------

import pandas as pd

certificates_earned = pd.DataFrame({
    'Certificates': [8, 2, 5, 6],
    'Time (in months)': [16, 5, 9, 12]
})

certificates_earned.index = ['Tom', 'Kris', 'Ahmad', 'Beau']

print(certificates_earned.iloc[2])

# COMMAND ----------

certificates_earned.loc[:]

# COMMAND ----------

certificates_earned.iloc[-1 ]


# COMMAND ----------

# MAGIC %md
# MAGIC ###Operations

# COMMAND ----------

import pandas as pd

certificates_earned = pd.DataFrame({
    'Certificates': [8, 2, 5, 6],
    'Time (in months)': [16, 5, 9, 12]
})
names = ['Tom', 'Kris', 'Ahmad', 'Beau']

print(certificates_earned)

certificates_earned.index = names
longest_streak = pd.Series([13, 11, 9, 7], index=names)
certificates_earned['Longest streak'] = longest_streak

print(certificates_earned)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Series - II

# COMMAND ----------

import pandas as pd
import numpy as np

s = pd.Series(['a', 3, np.nan, 1, np.nan])

print(s)

print(s.notnull().sum())

print(type(s))

# COMMAND ----------

s.notnull()

# COMMAND ----------

s.notnull().sum( )

# COMMAND ----------

s.isnull()

# COMMAND ----------

s.dropna()

# COMMAND ----------

s

# COMMAND ----------

# MAGIC %md
# MAGIC Immutable series object - Create a new Series

# COMMAND ----------

new_series = s.dropna()

# COMMAND ----------

new_series

# COMMAND ----------

# MAGIC %md
# MAGIC ###  Pandas Missing Data 

# COMMAND ----------

s

# COMMAND ----------

# MAGIC %md
# MAGIC Forward Fill

# COMMAND ----------

import pandas as pd
import numpy as np

s = pd.Series([np.nan, 1, 2, np.nan, 3])
s = s.fillna(method='ffill')

print(s)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Duplicated

# COMMAND ----------

import pandas as pd
import numpy as np

s = pd.Series([np.nan, 1, 2, np.nan, 3])
s = s.fillna(method='bfill')

print(s)

# COMMAND ----------

s.duplicated()

# COMMAND ----------

s.drop_duplicates()

# COMMAND ----------

s.drop

# COMMAND ----------

s.drop_  

# COMMAND ----------

import matplotlib.pyplot as plt 


# COMMAND ----------

plt.subplot(1, 4, 1)

# COMMAND ----------

spark.conf.set('spark.sql.execution.arrow.enabled', 'true')
spark.conf.set('spark.sql.execution.arrow.pyspark.enabled', 'true')

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC desc extended default.telecom_churn

# COMMAND ----------

# MAGIC %md
# MAGIC #Pandas Data Operations

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from default.telecom_churn

# COMMAND ----------

df=spark.sql("select * from default.telecom_churn")
import pandas as pd 
df_pd=df.toPandas()

# COMMAND ----------

print(type(df_pd))
print(type(df))

# COMMAND ----------

df_pd=df_pd.iloc[:4,[0,1,2,3,4]]

# COMMAND ----------

df_pd.sort_values(by=["Account length"],inplace=True)

# COMMAND ----------

df_pd['International_plan']=df_pd['International plan']

# COMMAND ----------

df_pd

# COMMAND ----------

df_pd.loc[df_pd["International_plan"].str.contains("Yes"),"International__plan"]="Yes- It's Internationl"
df_pd.loc[df_pd["International_plan"].str.contains("No"),"International__plan"]="No- It's Not Internationl"

# COMMAND ----------

df_pd

# COMMAND ----------

df_pd

# COMMAND ----------

df_pd

# COMMAND ----------

df_pd

# COMMAND ----------

multiply = lambda x, y: x * y

# COMMAND ----------

# MAGIC %md
# MAGIC # NumPy
# MAGIC Numpy- Fixed Types int8/16/32, Faster to read less bytes of memory,no need to type check ,uses continguous memory,SIMD-single instruction multiple data unit- Vector processing, effective cache  utilization Insert/Delete/Append
# MAGIC
# MAGIC Lists- int -size/reference/object type/object value,Very Slow,check for different data type,memory is scattered in blocks, Insert/Delete/Append
# MAGIC
# MAGIC Numpy -  Scifi/MatPlotLib/pandas core component/machine learning / 4d Photography
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

import numpy as np

# COMMAND ----------

b = np.array([[1.0,2.0,3.1],[3.0,4.0,5.0]])
print(b)

# COMMAND ----------

b.ndim

# COMMAND ----------

b.dtype

# COMMAND ----------

b.shape

# COMMAND ----------

b.itemsize

# COMMAND ----------

b.nbytes

# COMMAND ----------

a = np.array([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]])

# Output:
# [[ 1  2  20  4  5]
# [ 6  7 20  9 10]]

# COMMAND ----------

a[:, 2] = 20

# COMMAND ----------

a

# COMMAND ----------

np.zeros((2,2))

# COMMAND ----------

np.full_like((2,2),55)

# COMMAND ----------

a = np.array([1, 2, 3, 4, 5])
b = a
b[2] = 20

# COMMAND ----------

b

# COMMAND ----------

a = np.array(([1, 2, 3, 4, 5], [6, 7, 8, 9, 10]))
b = np.max(a, axis=1).sum()
a

# COMMAND ----------

b

# COMMAND ----------


a = np.ones((2, 4))
b = a.reshape((4, 2))
print(a)
print("Matrix got reshaped to below ")
print(b)

# COMMAND ----------

#File Containt
#29,97,32,100,45
#15,88,5,75,22

#Ouptput
[29. 32. 45. 15.  5. 22.]

filedata = np.genfromtxt('data.txt', delimiter=',')
output = filedata[filedata < 50]

print(output)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ### Array Zip vs Explode

# COMMAND ----------

from pyspark.sql import functions as F
data=[
  ("Sandeep",16,["Physics","Cheemistry","Maths"],["A","B"])
]

schema= ["Name","Age","Subjects","Grades"]

df=spark.createDataFrame(data=data,schema=schema)
display(df)


# COMMAND ----------

df = df.withColumn("new", F.arrays_zip("Subjects", "Grades"))
      #  .withColumn("new", F.explode("new"))
       # .select("Name", "Age", F.col("new.Subjects").alias("Subjects"), F.col("new.Grades").alias("Grades"))
display(df)

# COMMAND ----------

df = df.withColumn("new", F.arrays_zip("Subjects", "Grades"))\
       .withColumn("new", F.explode("new"))
display(df)

# COMMAND ----------

df = df.withColumn("new", F.arrays_zip("Subjects", "Grades"))\
       .withColumn("new", F.explode("new"))\
       .select("Name", "Age", F.col("new.Subjects").alias("Subjects"), F.col("new.Grades").alias("Grades"))
df.show()

# COMMAND ----------

df = df.withColumn('Subjects',F.explode('Subjects')).select('Name','Age','Subjects','Grades').distinct()

df = df.withColumn('Grades',F.explode('Grades')).select('Name','Age','Subjects', 'Grades').distinct()

df.show()

# COMMAND ----------

display(df.set_index('A')
              .apply(lambda x: x.apply(pd.Series).stack())
              .reset_index()
              .drop('level_1', 1))

# COMMAND ----------

import pandas as pd 
df_pd=df.toPandas()
display(df_pd)
type(df_pd)

# COMMAND ----------

from pyspark.sql.types import ArrayType,StringType,StringType,StructType,StructField

combine = F.udf(lambda x, y: list(zip(x, y)),
              ArrayType(StructType([StructField("subs", StringType()),
                                    StructField("grades", StringType())])))

df = df.withColumn("new", combine("Subjects", "Grades"))\
       .withColumn("new", F.explode("new"))\
       .select("Name", "Age", F.col("new.subs").alias("Subjects"), F.col("new.grades").alias("Grades"))
df.show()

# COMMAND ----------


# Create pandas DataFrame
import pandas as pd
import numpy as np
technologies = (
    {'A': [["Spark","PySpark","Python"], 'Course', [], ["Java","pandas"]],
     'B': [25000,15000,30000,40000],
     'C': [['30days','40days','35days'], np.nan, [], ['40days','55days']]})
df = pd.DataFrame(technologies)
print(df)


# COMMAND ----------

# df1=df.explode("A")
# display(df1)

# df2 = df.explode(list('AC'))
# df2 = df.explode(list('AC'), ignore_index=True)
# display(df2)

df2 = df.explode(list('A'))
print(df2)


# df2 = df.explode(list('AC'))
# print(df2)

# COMMAND ----------

pip show pandas

# COMMAND ----------


import pandas as pd
import numpy as np
technologies = ({'A': [["Spark","PySpark","Python"], 'Course', [], ["Java","pandas"]],
                   'B': 25000,
                   'C': [['30days','40days','35days'], np.nan, [], ['40days','55days']]})
df = pd.DataFrame(technologies)
print(df,end = "\n")

# use DataFrame.explode() function
df2 = df.explode('A')
print(df2)




# COMMAND ----------


# Explode single column 
# using DataFrame.explode()function
# df2 = df.explode(list('A'))
# print(df2)

# Explode single column & ignore_index
# df2 = df.explode('A',ignore_index=True)
# print(df2)

# Explode multiple columns 
# Using DataFrame.explode() function
# df2 = df.explode(list('AC'))
# print(df2)

# Use DataFrame.explode() Function & ignore_index
df2 = df.explode(list('AC'), ignore_index=True)
print(df2)

# COMMAND ----------

import pandas as pd 
df = pd.DataFrame({'A': ['x1','x2','x3', 'x4'], 
'B':[['v1','v2'],['v3','v4'],['v5','v6'],['v7','v8']], 
'C':[['c1','c2'],['c3','c4'],['c5','c6'],['c7','c8']],
'D':[['d1','d2'],['d3','d4'],['d5','d6'],['d7','d8']], 
'E':[['e1','e2'],['e3','e4'],['e5','e6'],['e7','e8']]
})


# COMMAND ----------

display(df)

# COMMAND ----------

dff = spark.createDataFrame(df)
dff = dff.withColumn("new", F.arrays_zip("B", "C"))\
       .withColumn("new", F.explode("new"))\
       .select("A", F.col("new.B").alias("Subjects"), F.col("new.C").alias("Grades"))
dff.show()

# COMMAND ----------

display(df.set_index('A')
              .apply(lambda x: x.apply(pd.Series).stack())
              .reset_index()
              .drop('level_1', 1))

# COMMAND ----------

# MAGIC %md
# MAGIC ###Pandas Data ETL

# COMMAND ----------

import re
import pandas as pd
import email

emails = []

# COMMAND ----------

# MAGIC %md
# MAGIC #Time
# MAGIC

# COMMAND ----------

import time
current_time_seconds = time.time()

current_time_milliseconds = int(time.time() * 1000)
print(current_time_milliseconds)

# COMMAND ----------

from datetime import datetime

current_time_seconds = (datetime.utcnow() - datetime(1970,1,1)).total_seconds()
print(current_time_seconds)
current_time_milliseconds = int((datetime.utcnow() - datetime(1970,1,1)).total_seconds() * 1000)
print(current_time_milliseconds)

# COMMAND ----------

from datetime import datetime
# Get current time in seconds (epoch)
current_time_seconds = datetime.now().timestamp()
# Get current time in milliseconds
current_time_milliseconds = int(datetime.now().timestamp() * 1000)
print(current_time_milliseconds)

# COMMAND ----------

# MAGIC %md
# MAGIC #List Comprehension

# COMMAND ----------

l=[1,2,3,4,5]
[x&1 for x in l]

# COMMAND ----------

l1=[1,2,3]
l2=[4,5,6]
[x*y for x in l1 for y in l2]

# COMMAND ----------

 l1=[-65, 2, 7, -99, -4, 3]
 [x for x in l1 if x<0]

# COMMAND ----------

s=["pune", "mumbai", "delhi"]
# [(w.upper(), len(w)) for w in s]
[[w.upper(), len(w)] for w in s]

# COMMAND ----------

l1=[2,4,6]
l2=[-2,-4,-6]
for i in zip(l1, l2):
	print(i)

# COMMAND ----------

l1=[10, 20, 30]
l2=[-10, -20, -30]
l3=[x+y for x, y in zip(l1, l2)]
print(l3)

# COMMAND ----------

l=[1, 2, 3, 4, 5, 6, 7, 8, 9]
[x**3 for x in l]

# COMMAND ----------

l=[2, 5,]
y = [x**3 for x in l]
print(type(y))
print(y)

# COMMAND ----------

l=[
  [1 ,2, 3], 
  [4, 5, 6],
  [7, 8, 9]
  ]
[i for row in l for i in row]

# COMMAND ----------

l=[[1 ,2, 3], [4, 5, 6], [7, 8, 9]]
[[row[i] for row in l] for i in range(3)]

# COMMAND ----------

import math
[str(round(math.pi)) for i in range (1, 6)]

# COMMAND ----------

l1=[1,2,3]
l2=[4,5,6]
l3=[7,8,9]
for x, y in zip(l1, l2):
	print(x, y)

# COMMAND ----------

l1=[1,2,3]
l2=[4,5,6]
l3=[7,8,9]
for x, y, z in zip(l1, l2, l3):
	print(x, y, z)

# COMMAND ----------

w="hello"
v=('a', 'e', 'i', 'o', 'u')

[l for l in w if l in v]

# COMMAND ----------

[ord(ch) for ch in 'abc']

# COMMAND ----------

t=32.00
[round((x-32)*5/9) for x in t]

# COMMAND ----------

t=[32.00,33.00]
[round((x-32)*5/9) for x in t]

# COMMAND ----------

# Write a list comprehension for producing a list of numbers between 1 and 1000 that are divisible by 3.

[x for x in range(50) if x%3==0]

# COMMAND ----------

for i in range(1, 11):
	if int(i*0.5)==i*0.5:
		print(i,i*0.5)

# COMMAND ----------

[(2**x) for x in range(0, 13)]

# COMMAND ----------

# [x for x in range(0, 20) if (x//2==0)]
[x for x in range(0, 20) if (x%2==0)]

# COMMAND ----------

[j for i in range(2,8) for j in range(i*2, 20, i)]

# COMMAND ----------

l=["good", "oh!", "excellent!", "#450"]
[n for n in l if n.isalpha() or n.isdigit()]

# COMMAND ----------

# MAGIC %md
# MAGIC #Dict Comprehension

# COMMAND ----------

dict = {'a': 1, 'b': 2, 'c': 3,'a': 1,}
if 'a' in dict:
    print("Key exists")
else:
    print("Key does not exist")

# COMMAND ----------

myDict = {}
myDict['apple'] = 1
myDict['banana'] = 2

print(myDict)
del myDict['apple']
removedValue = myDict.pop('banana', None)
lastItem = myDict.popitem()

# COMMAND ----------

dict = {'b': 1, 'a': 2, 'c': 3}
sorted_dict = dict(sorted(dict.items()))

# COMMAND ----------

dict1 = {"a": 1, "b": 2}
dict2 = {"b": 3, "c": 4}
dict1.update(dict2)

print(dict1)

# COMMAND ----------

dict1 = {"a": 1, "b": 2}
dict2 = {"b": 3, "c": 4}
merged_dict = {**dict1, **dict2}
print(merged_dict)

# COMMAND ----------

# MAGIC %md
# MAGIC #Pandas Lambda

# COMMAND ----------

# MAGIC %md
# MAGIC Lambda function - create column - percentage - df.assign()

# COMMAND ----------

import pandas as pd

values= [['Rohan',455],['Elvish',250],['Deepak',495],
		['Soni',400],['Radhika',350],['Vansh',450]] 

df = pd.DataFrame(values,columns=['Name','Total_Marks'])

df = df.assign(Percentage = lambda x: (x['Total_Marks'] /500 * 100))

df

# COMMAND ----------

# MAGIC %md
# MAGIC withing df, only for index ='d' - Square the values

# COMMAND ----------


import pandas as pd
import numpy as np

values_list = [[15, 2.5, 100], [20, 4.5, 50], [25, 5.2, 80],
			[45, 5.8, 48], [40, 6.3, 70], [41, 6.4, 90], [51, 2.3, 111]]

df = pd.DataFrame(values_list, columns=['Field_1', 'Field_2', 'Field_3'],
				index=['a', 'b', 'c', 'd', 'e', 'f', 'g'])

# df = df.apply(lambda x: np.square(x) if x.name == 'd' else x, axis=1)
df = df.apply(lambda x: np.square(x) if x.name in ['c','d'] else x, axis=1)

df


# COMMAND ----------

import pandas as pd

data = {
'Name': ['Jai', 'Princi', 'Gaurav', 'Anuj'],
'Height': [5.1, 6.2, 5.1, 5.2],
'Qualification': ['Msc', 'MA', 'Msc', 'Msc']
}

df = pd.DataFrame(data)
df.insert(2, "Age", [21, 23, 24, 21], True)
print(df)

# COMMAND ----------

