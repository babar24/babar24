# Databricks notebook source
# MAGIC %md
# MAGIC ## inheritance

# COMMAND ----------

# Python program to demonstrate
# single inheritance

# Base class
class Parent:
	def func1(self):
		print("This function is in parent class.")

# Derived class


class Child(Parent):
	def func2(self):
		print("This function is in child class.")


# Driver's code
object = Child()
object.func1()
object.func2()


# COMMAND ----------

# Python program to demonstrate
# multiple inheritance

# Base class1
class Mother:
	mothername = ""

	def mother(self):
		print(self.mothername)

# Base class2


class Father:
	fathername = ""

	def father(self):
		print(self.fathername)

# Derived class


class Son(Mother, Father):
	def parents(self):
		print("Father :", self.fathername)
		print("Mother :", self.mothername)


# Driver's code
s1 = Son()
s1.fathername = "RAM"
s1.mothername = "SITA"
s1.parents()


# COMMAND ----------

# Python program to demonstrate
# multilevel inheritance

# Base class


class Grandfather:

	def __init__(self, grandfathername):
		self.grandfathername = grandfathername

# Intermediate class


class Father(Grandfather):
	def __init__(self, fathername, grandfathername):
		self.fathername = fathername

		# invoking constructor of Grandfather class
		Grandfather.__init__(self, grandfathername)

# Derived class


class Son(Father):
	def __init__(self, sonname, fathername, grandfathername):
		self.sonname = sonname

		# invoking constructor of Father class
		Father.__init__(self, fathername, grandfathername)

	def print_name(self):
		print('Grandfather name :', self.grandfathername)
		print("Father name :", self.fathername)
		print("Son name :", self.sonname)


# Driver code
s1 = Son('Prince', 'Rampal', 'Lal mani')
print(s1.grandfathername)
s1.print_name()


# COMMAND ----------

# Python program to demonstrate
# Hierarchical inheritance


# Base class
class Parent:
	def func1(self):
		print("This function is in parent class.")

# Derived class1


class Child1(Parent):
	def func2(self):
		print("This function is in child 1.")

# Derivied class2


class Child2(Parent):
	def func3(self):
		print("This function is in child 2.")


# Driver's code
object1 = Child1()
object2 = Child2()
object1.func1()
object1.func2()
object2.func1()
object2.func3()


# COMMAND ----------

# Python program to demonstrate
# hybrid inheritance


class School:
	def func1(self):
		print("This function is in school.")


class Student1(School):
	def func2(self):
		print("This function is in student 1. ")


class Student2(School):
	def func3(self):
		print("This function is in student 2.")


class Student3(Student1, School):
	def func4(self):
		print("This function is in student 3.")


# Driver's code
object = Student3()
object.func1()
object.func2()


# COMMAND ----------

# MAGIC %md
# MAGIC ##return multiple values

# COMMAND ----------

def profile():
    name = "John Doe"
    age = 28
    return name, age

profile_info = profile()
print(profile_info)

# COMMAND ----------

def profile():
    name = "John Doe"
    age = 28
    return name, age

name, age = profile()
print(name)
print(age)

# COMMAND ----------

def profile():
    name = "John Doe"
    age = 28
    return {"name": name, "age": age}

profile_info = profile()
print(profile_info)

print(type(profile_info))

# COMMAND ----------

# MAGIC %md
# MAGIC ##re

# COMMAND ----------

import re 
match = re.search(r'portal', 'GeeksforGeeks: A computer science portal for geeks')

print(match) 
print(match.group()) 
print('Start Index:', match.start()) 
print('End Index:', match.end()) 

# COMMAND ----------

import re 

print(re.findall(r'[Gg]eeks', 'GeeksforGeeks: A computer science portal for geeks'))


# COMMAND ----------

import re 


print('range',re.search(r'[a-zA-Z]', '!@#$%a@'))

print('Start Index:', match.start()) 
print('End Index:', match.end()) 


# COMMAND ----------

import re 

print(re.search(r'[^a-z]', 'c'))


# COMMAND ----------

import re 

print(re.search(r'G[^e]', 'Geeks')) 


# COMMAND ----------

import re 
print('Geeks:', re.search(r'\bGeeks\b', 'Geeks')) 
print('GeeksforGeeks:', re.search(r'\bGeeks\b', 'GeeksforGeeks')) 

# COMMAND ----------

# MAGIC %md
# MAGIC ##len

# COMMAND ----------

s = "Sandeep"
print(len(s))

# COMMAND ----------

# DBTITLE 1,Occurance of the char within string
s="initsinitintintinnnn"
ch={}
for i in s:
	if i in ch:
  # if i in ch.keys():
		ch[i]+=1
	else:
		ch[i]=1
max_chr=max(ch,key=ch.get)
print(ch)
print(max_chr)
        

# COMMAND ----------

s = "initsinitintintinnnn"
ch = {}
for i in s:
    if i in ch.keys():
        ch[i] += 1
    else:
        ch[i] = 1

max_chr = max(ch, key=ch.get)
print(ch)
print(max_chr)

# COMMAND ----------

# MAGIC %md
# MAGIC ##upper & lower

# COMMAND ----------

def reverseCase(str):
  res = ""
  for i in str: 
    if i.isupper():
      print(i.lower())
    else:
      print(i.upper())

reverseCase("SandeeP")

# COMMAND ----------

def capitalizeWord(str):
   result=""
   words = str.split(" ")
   for word in words:
      result= result + word[0:1].upper() + word[1:len(str)] + " "
   return result

# COMMAND ----------

print(capitalizeWord("sandeep shesharao gutte chikhali"))

s="sandeep"
x= len(s)

print(x)

# COMMAND ----------

# MAGIC %md
# MAGIC ##join and split

# COMMAND ----------

s = 'Geeks for Geeks'

print("Output of the split function is below : ")
print(s.split(" ")) 

print("Output of the split function is below : ")
print("-".join(s.split()))

# split() - string is splitted in list of words
# join() - Joined into the string of words

# COMMAND ----------

# MAGIC %md
# MAGIC ##Lambda

# COMMAND ----------

# MAGIC %md
# MAGIC Lambda functions are similar to user-defined functions but without a name. They're commonly referred to as anonymous functions. Lambda functions are efficient whenever you want to create a function that will only contain simple expressions – that is, expressions that are usually a single line of a statement

# COMMAND ----------

lst = [5,2,6,4,9,1,8,7]

y = map(lambda x: x*2,lst)

print(type(y))
print(y)
print(list(y))

# COMMAND ----------

lst = [5,2,6,4,9,1,8,7]
lambda lst, key, value: [dict(i, **{key: value}) for i in lst]

# COMMAND ----------

# the legendary Y combinator makes it possible
# to let nameless functions recurse using an indirection
Y = lambda f: (lambda x: x(x))(lambda y: f(lambda *args: y(y)(*args)))
# our iterator lambda
it = lambda f: lambda Lst: (Lst[0], f(Lst[1:])) if Lst else None
# see it in action:
Y(it)([1,2,3])

# COMMAND ----------

from pyspark.sql.types import *
count = {8: 'u', 4: 't', 9: 'z', 10: 'j', 5: 'k', 3: 's'}
count_updated = dict(filter(lambda val: val[0] % 3 == 0,
                     count.items())
                     )

print(count_updated)

# COMMAND ----------

dict1 = {
  'c':88,
  'd':22,
  'a':55,
  'b':33
}


y = map(lambda x: x*2,dict1)
print(type(y))

print(dict(y))



# COMMAND ----------

# MAGIC %md
# MAGIC ##iter()

# COMMAND ----------

mytuple = ("apple", "banana", "cherry")
myit = iter(mytuple)

print(next(myit))
# print(next(myit))
print(next(myit))

# COMMAND ----------

mystr = "banana"
myit = iter(mystr)

print(next(myit))
print(next(myit))
print(next(myit))
# print(next(myit))
print(next(myit))
print(next(myit))

# COMMAND ----------

# MAGIC %md
# MAGIC ##dict comprehension

# COMMAND ----------

# MAGIC %md
# MAGIC List comprehensions and dictionary comprehensions are a powerful substitute to for-loops and also lambda functions. Not only do list and dictionary comprehensions make code more concise and easier to read, they are also faster than traditional for-loops

# COMMAND ----------

dict1={575:"Apple",
876:"Mango",
132:"Grapes",
876:"Mango",
"":"Mango",
# Null:"Mango",
782:"Banana"
}


# COMMAND ----------

# print(dict1)

for i,j in dict1.items(): 
  print(i,":",j)

# COMMAND ----------



# Printing the Keys of the Dictionary
for i in dict1.keys():
  print(i)

# Printing the Values of the Dictionary
for i in dict1.keys():
  print(dict1[i])

# COMMAND ----------

dict = {
  'c':88,
  'd':22,
  'a':55,
  'b':33
}

# COMMAND ----------


print(dict)

lst =list(dict.keys())
lst.sort()

lst1 =list(dict.values())
lst1.sort()

print(lst)
print(lst1)


# COMMAND ----------


dic1 = {i:dict[i] for i in lst}

print(dic1)


max_len = max(dict,key = dict.get)
min_len = min(dict,key = dict.get)

# avg_len = avg(dict,key = dict.get) -- doesnt exist

print(max_len)
print(min_len)


# COMMAND ----------

from collections import OrderedDict

dict = {'ravi': '10', 'rajnish': '9',
		'sanjeev': '15', 'yash': '2', 'suraj': '32'}
dict1 = OrderedDict(sorted(dict.items()))
print(dict1)


# COMMAND ----------

fruits = ['apple', 'banana', 'peach', 'apple', 'pear']
d = {}
for fruit in fruits:
    if fruit not in d:
        d[fruit] = 0
    d[fruit] += 1

print(d)

# COMMAND ----------

from os import listdir
from os.path import isfile,join

path ="/dbfs/user/hive/warehouse/san_employee"

# lst = [f for f in listdir(dirpath) if isfile(join(dirpath,f))]

file = [f for f in listdir(path) if isfile(join(path,f))]

print(file)

# COMMAND ----------

dict = {
  'c':88,
  'd':22,
  'a':55,
  'b':33
}

# COMMAND ----------

dict1 = {v for k,v in dict.items()}
dict2 = {v:k for k,v in dict.items()}

print(dict1)
print(dict2)
print(type(dict1))
print(type(dict2))
  

# COMMAND ----------

# MAGIC %md
# MAGIC ##ord

# COMMAND ----------

print(ord('a')) # Output: 97
print(ord('€')) # Output: 8364

# COMMAND ----------

# MAGIC %md
# MAGIC ##hash

# COMMAND ----------

# initializing objects
int_val = 4
str_val = 'GeeksforGeeks'
flt_val = 24.56

# Printing the hash values.
# Notice Integer value doesn't change
# You'll have answer later in article.
print("The integer hash value is : " + str(hash(int_val)))
print("The string hash value is : " + str(hash(str_val)))
print("The float hash value is : " + str(hash(flt_val)))

tuple_val = (1, 2, 3, 4, 5)

list_val = [1, 2, 3, 4, 5]
 
print("The tuple hash value is : " + str(hash(tuple_val)))
# print("The list hash value is : " + str(hash(list_val))


# COMMAND ----------

# MAGIC %md
# MAGIC ##format

# COMMAND ----------

name = "Ram"
age = 22
message = "My name is {0} and I am {1} years old. {1} is my favorite number.".format(name, age)
print(message)


# COMMAND ----------

txt = "I have {an:.2f} Rupees!"
print(txt.format(an = 4))


# COMMAND ----------

# MAGIC %md
# MAGIC ##reversed

# COMMAND ----------

# creating a list 
cars = ["nano", "swift", "bolero", "BMW"] 
# reversing the list 
reversed_cars = list(reversed(cars)) 
#printing the list 
print(reversed_cars)


# COMMAND ----------

class gfg: 
	vowels = ['a', 'e', 'i', 'o', 'u'] 

	# Function to reverse the list 
	def __reversed__(self): 
		return reversed(self.vowels) 

# Main Function	 
if __name__ == '__main__': 
	obj = gfg() 
	print(list(reversed(obj))) 


# COMMAND ----------

# MAGIC %md
# MAGIC ##slice

# COMMAND ----------

L = [1, 2, 3, 4, 5]
slice_obj1 = slice(3)
slice_obj2 = slice(1, 5, 2)

print("List slicing")
print(L[slice_obj1])
print(L[slice_obj2])


# COMMAND ----------

# MAGIC %md
# MAGIC ##input

# COMMAND ----------

# Taking input from the user
name = input("Enter your name")

# Output
print("Hello", name)


# COMMAND ----------

# MAGIC %md
# MAGIC ##round

# COMMAND ----------

x = round(5.76543, 2)
print(x)

# COMMAND ----------

x = round(5.76543)
print(x)

x = round(49.76543,-2)
print(x)

x = round(51.76543,-2)
print(x)

# COMMAND ----------

# MAGIC %md
# MAGIC ##ceil and floor

# COMMAND ----------

import math

# prints the ceil using floor() method
print ("math.floor(-23.11) : ", math.floor(-23.11))
print ("math.floor(300.16) : ", math.ceil(300.16))
print ("math.floor(300.72) : ", math.floor(300.72))


# COMMAND ----------

# MAGIC %md
# MAGIC ## logging
# MAGIC

# COMMAND ----------

# importing module
import logging

# Create and configure logger
logging.basicConfig(filename="newfile.log",
					format='%(asctime)s %(message)s',
					filemode='w')

# Creating an object
logger = logging.getLogger()

# Setting the threshold of logger to DEBUG
logger.setLevel(logging.DEBUG)

# Test messages
logger.debug("Harmless debug Message")
logger.info("Just an information")
logger.warning("Its a Warning")
logger.error("Did you try to divide by zero")
logger.critical("Internet is down")


# COMMAND ----------

# MAGIC %md
# MAGIC ## median

# COMMAND ----------

import statistics

data1 = [2, -2, 3, 6, 9, 4, 5, -1]


print("Median of data-set is : % s "
      		% (statistics.median(data1)))


# COMMAND ----------

# MAGIC %fs ls 'dbfs:/user/hive/warehouse/san_employee/'

# COMMAND ----------

from os import listdir
from os.path import isfile, join
dirpath = "/dbfs/user/hive/warehouse/san_employee/"
# dirpath = 's3a://novartisrs3aprdief1prelanding001/pre_landing/cafdb/rdi/'

lst = [f for f in listdir(dirpath) if isfile(join(dirpath,f))]
# lst = [f for f in listdir(dirpath) if isfile(f)]

for i in lst:
  print(i)


# COMMAND ----------

# MAGIC %fs ls 's3a://novartisrs3aprdief1prelanding001/pre_landing/cafdb/rdi/'

# COMMAND ----------


import glob
import pandas as pd
 
# path = 's3a://novartisrs3aprdief1prelanding001/pre_landing/cafdb/rdi/'
dirpath = "/dbfs/user/hive/warehouse/san_employee/"
file_list = glob.glob(dirpath + "/*.parquet")

for i in file_list:
  print(i)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Text Analytics

# COMMAND ----------

# from docx.api import Document
# from doc import Document
from docx import Document
import pandas as pd
import os
import os.path, time
from datetime import date 
import glob
import re

# COMMAND ----------

import string
import random
 
# initializing size of string
N = 7
 
# using random.choices()
# generating random strings
res = ''.join(random.choices(string.ascii_lowercase +
                             string.digits, k=N))
print(res)

# COMMAND ----------

# MAGIC %md
# MAGIC #float number validation
# MAGIC

# COMMAND ----------

def isfloat(num):
    try:
        float(num)
        return True
    except ValueError:
        return False

print(isfloat('s12'))
print(isfloat('-.0'))



# COMMAND ----------



# COMMAND ----------

