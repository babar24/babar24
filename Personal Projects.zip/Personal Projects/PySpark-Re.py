# Databricks notebook source

partition_size = spark.conf.get("spark.sql.files.maxPartitionBytes").replace("b","")
print(f"Partition Size: {partition_size} in bytes and {int(partition_size) / 1024 / 1024} in MB")


# COMMAND ----------

executor_memory = spark.conf.get("spark.executor.memory").replace("m","")
print(f"executor memory: {executor_memory} in mb and {int(executor_memory) / 1024  } in GB")

# COMMAND ----------

print(f"Parallelism : {sc.defaultParallelism}")

# this value depends on the cores and nodes active. If all 4 nodes are available then 16. Coz each node is provided with 4 cores.
# current/ min worker nodes =2 means 2*4=8 

# COMMAND ----------

rdd = spark.sparkContext.parallelize(range(0,20))
print("From local[5] : "+str(rdd.getNumPartitions()))

# COMMAND ----------

spark.conf.get("spark.sql.shuffle.partitions")

# COMMAND ----------

spark.conf.get("spark.executor.memory")

# COMMAND ----------

print(df.rdd.getNumPartitions())

# COMMAND ----------

spark.conf.get("spark.dynamicAllocation.enabled")

# COMMAND ----------

spark.conf.get("spark.driver.memory")

# COMMAND ----------

spark.conf.get("spark.executor.memoryOverhead")

# COMMAND ----------

spark.conf.get("spark.executor.cores")

# COMMAND ----------

spark.conf.get("spark.yarn.executor.memoryOverhead")

# COMMAND ----------

spark.conf.get("spark.sql.adaptive.enabled")

# COMMAND ----------

spark.conf.get("spark.sql.adaptive.localShuffleReader.enabled")

# COMMAND ----------

spark.conf.get("spark.sql.adaptive.coalescePartitions.enabled")

# COMMAND ----------

x=(df.rdd.getNumPartitions())
print(x)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Checking if value exists in df

# COMMAND ----------

df = spark.createDataFrame([['A'],['A'],['B']], ['vals'])
df.show()

# COMMAND ----------

from pyspark.sql import functions as F
df.selectExpr('any(vals == "A")').show()

# COMMAND ----------

from pyspark.sql import functions as F
df.select(F.expr('any(vals == "A")')).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Counting frequency of values 
# MAGIC

# COMMAND ----------

df = spark.createDataFrame([['A'],['A'],['B']], ['col1'])
df.show()

# COMMAND ----------

df.groupBy('col1').count().show()

# COMMAND ----------

df.groupBy('col1').count().orderBy('count', ascending=False).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Combining columns into a single column

# COMMAND ----------

df = spark.createDataFrame([['Alex','Jobs'], ['Bob','Miley'], ['Cathy','Lee']], ['fname','lname'])
df.show()

# COMMAND ----------

from pyspark.sql.functions import concat_ws
df=df.withColumn("concat",concat_ws(", ","fname","lname"))
display(df)

# COMMAND ----------

# DBTITLE 1,array - to combine multiple columns into one
from pyspark.sql import functions as F
df_merged = df.select(F.array('fname', 'lname').alias('merged'))
df_merged.show()
df_merged.createOrReplaceTempView("tmpp")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from tmpp

# COMMAND ----------

df = spark.createDataFrame([['Alex', 20], ['Bob', 30]], ['name', 'age'])
df.show()

from pyspark.sql import functions as F
df.select(F.col('name').substr(1,3).alias('shorter_name')).show()


# COMMAND ----------

df = spark.createDataFrame([['id-69', 20], ['id-82', 30]], ['id', 'age'])
df.show()

from pyspark.sql import functions as F
df.select(F.regexp_extract('id', '(\d+)', 1).alias('id_number')).show()


# COMMAND ----------

df = spark.createDataFrame([['aaa'], ['bb'], ['cccc'], ['dd'], ['eeee']], ['vals'])
df.show()

df.createOrReplaceTempView("my_vals")

spark.sql('SELECT * FROM my_vals ORDER BY length(vals) ASC LIMIT 1;').show()
spark.sql('SELECT * FROM my_vals ORDER BY length(vals) DESC LIMIT 1;').show()

q = 'SELECT * FROM my_vals WHERE length(vals) = (SELECT max(length(vals)) FROM my_vals)'
spark.sql(q).show()

# COMMAND ----------



rows = [["Alex", 25],["Alexander", 65], ["Bob", 30]]
df = spark.createDataFrame(rows, ["name", "age"])
df.show()

from pyspark.sql import functions as F
df_new = df.withColumn("name", F.regexp_replace("name", "le", "LE"))
df_new.show()



df_new = df.withColumn("name", F.regexp_replace("name", "\[le", ""))
df_new.show()

# COMMAND ----------

from pyspark.sql import functions as F


rows = [["Alex", 25],["Alexander", 65], ["Bob", 30]]
df = spark.createDataFrame(rows, ["name", "age"])
df.show()


substr_to_remove = ["le","B","b"]
regex = "|".join(substr_to_remove)

print(type(regex))

print(regex)

df_new = df.withColumn("name", F.regexp_replace("name", regex, ""))
df_new.show()

df = spark.createDataFrame([["!A@lex"], ["B#!ob"]], ["name"])
df.show()

# COMMAND ----------

from pyspark.sql import functions as F
rows = [["Alex", 25],["Alexander@@", 65], ["Bob@", 30]]
df = spark.createDataFrame(rows, ["name", "age"])
df.show()

df_new = df.withColumn("name", F.translate("name", "le!@#", "89345"))
df_new.show()


# COMMAND ----------


from pyspark.sql import functions as F
rows = [["Alex", 25],["Alexander@@", 65], ["Bob@", 30]]
df = spark.createDataFrame(rows, ["name", "age"])
df.show()

from pyspark.sql import functions as F
df_new = df.withColumn("name", F.regexp_replace("name", "@@", "l"))
df_new.show()

# COMMAND ----------

from pyspark.sql import functions as F

rows = [["Alex", 25],["Alexander^@", 65], ["Bob@", 30]]
df = spark.createDataFrame(rows, ["name", "age"])
df.show()

df_new = df.withColumn("name", F.regexp_replace("name", "\^@", "**"))
df_new.show()

# \is used before ^ to replace ^@

# COMMAND ----------

df = spark.createDataFrame([['@a','@b'], ['@c','@d']], ['A', 'B'])
df.show()

str_before = '@'
str_after = '#'
df_new = df.withColumn('A', F.regexp_replace('A', str_before, str_after))
df_new = df_new.withColumn('B', F.regexp_replace('B', str_before, str_after))
df_new.show()



# COMMAND ----------

df = spark.createDataFrame([['##A'],['B##'],['#C#']], ['vals'])
df.show()

from pyspark.sql import functions as F
df = df.select(F.regexp_replace('vals', '^#+', '').alias('new_vals'))
df.show()

# ^ used is for matchin the start of the pattern

# COMMAND ----------


df = spark.createDataFrame([['##A'],['B##'],['#C#'],['E#E']], ['vals'])
df.show()

# Replace the substrings matched by the regex #+$
# with an empty string '' in the vals column
df.select(F.regexp_replace('vals', '#+$', '').alias('new_vals')).show()


# COMMAND ----------

df = spark.createDataFrame([['##A'],['B##'],['#C#'],['E#E']], ['vals'])
df.show()

from pyspark.sql import functions as F
df = df.select(F.regexp_replace('vals', '^#+|#+$', '').alias('new_vals'))
df.show()

# COMMAND ----------

df = spark.createDataFrame([['#@A'],['B#@'],['#C#@D']], ['vals'])
df.show()

from pyspark.sql import functions as F
df = df.select(F.regexp_replace('vals', '^(#@)|(#@)$', '').alias('new_vals'))
df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Working with Corrupt Data

# COMMAND ----------

dbutils.fs.put("/FileStore/tables/channelsan.csv","""CHANNEL_ID,CHANNEL_DESC,CHANNEL_CLASS,CHANNEL_CLASS_ID,CHANNEL_TOTAL,CHANNEL_TOTAL_ID
3,Direct Sales,Direct,12,Channel total,1
9,Tele Sales,Direct,12,Channel total,1
5,Catalog,Indirect,13,Channel total,1
4,Internet,Indirect,13,Channel total,1
2,Partners,Others,14,Channel total,1
12,Partners,Others,14,Channel total,1,45,ram,3434
sample,Partners,Others,14,Channel total,1,45,ram,3434
10 Partners Others 14 Channel total 1
11 Partners Others 14 Channel total 1
""")

# COMMAND ----------

dbutils.fs.ls("/FileStore/tables/channelsan.csv")

# COMMAND ----------

from pyspark.sql.types import *
schema_channels = StructType([StructField('CHANNEL_ID', IntegerType(), True), 
                              StructField('CHANNEL_DESC', StringType(), True), 
                              StructField('CHANNEL_CLASS', StringType(), True), 
                              StructField('CHANNEL_CLASS_ID', IntegerType(), True), 
                              StructField('CHANNEL_TOTAL', StringType(), True), 
                              StructField('CHANNEL_TOTAL_ID', IntegerType(), True),
                              StructField('BadData', StringType(), True)])
df_channels = spark.read.schema(schema_channels).csv("/FileStore/tables/channelsan.csv",header=True,columnNameOfCorruptRecord="BadData")
display(df_channels)
     

# COMMAND ----------

df_channels.cache()
good_data = df_channels.filter("BadData is null").drop("BadData")
bad_data = df_channels.filter("BadData is not null").select("BadData")

# COMMAND ----------

display(bad_data)
     

# COMMAND ----------

from pyspark.sql.types import *
schema_channels = StructType([StructField('CHANNEL_ID', IntegerType(), True), 
                              StructField('CHANNEL_DESC', StringType(), True), 
                              StructField('CHANNEL_CLASS', StringType(), True), 
                              StructField('CHANNEL_CLASS_ID', IntegerType(), True), 
                              StructField('CHANNEL_TOTAL', StringType(), True), 
                              StructField('CHANNEL_TOTAL_ID', IntegerType(), True)])
df_channels = spark.read.schema(schema_channels).option("badRecordsPath","/channels/badata/").csv("/FileStore/tables/channelsan.csv",header=True,columnNameOfCorruptRecord="BadData")
display(df_channels)

# COMMAND ----------

# MAGIC %md
# MAGIC ##JSON READ

# COMMAND ----------

dbutils.fs.put("/schenarios/complex_json.json","""[{
	"id": "0001",
	"type": "donut",
	"name": "Cake",
	"ppu": 0.55,
	"batters":
		{
			"batter":
				[
					{ "id": "1001", "type": "Regular" },
					{ "id": "1002", "type": "Chocolate" },
					{ "id": "1003", "type": "Blueberry" },
					{ "id": "1004", "type": "Devil's Food" }
				]
		},
	"topping":
		[
			{ "id": "5001", "type": "None" },
			{ "id": "5002", "type": "Glazed" },
			{ "id": "5005", "type": "Sugar" },
			{ "id": "5007", "type": "Powdered Sugar" },
			{ "id": "5006", "type": "Chocolate with Sprinkles" },
			{ "id": "5003", "type": "Chocolate" },
			{ "id": "5004", "type": "Maple" }
		]
}]""",True)
     

# COMMAND ----------

from pyspark.sql.functions import explode,col
df_json = spark.read.option("multiline","true").json("/schenarios/complex_json.json")
df_json.printSchema()

# COMMAND ----------

df_final = df_json.withColumn("topping_explode",explode("topping"))\
                .withColumn("topping_id",col("topping_explode.id"))\
                .withColumn("topping_type",col("topping_explode.type"))\
                .drop("topping","topping_explode")\
                .withColumn("batter_explode",explode("batters.batter"))\
                .withColumn("batter_id",col("batter_explode.id"))\
                .withColumn("batter_type",col("batter_explode.type"))\
                .drop("batters","batter_explode")
display(df_final)

# COMMAND ----------

a = ["Apple","Orange"]
print(a[-1][1])
print(a[0][1])