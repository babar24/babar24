# Databricks notebook source
# MAGIC %run CAFDB/cafdb_publish/notebook/common/common_ingestion_util

# COMMAND ----------

from pyspark.sql.types import StructField, StructType, StringType, IntegerType,DateType,DoubleType
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import functions as F
from pyspark.sql.window import Window

from pyspark.sql.functions import datediff,col,Column
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta

from datetime import datetime
from pyspark.sql.functions import percentile_approx,substring,col

import py4j
import pandas as pd
import numpy as np

# COMMAND ----------

def rds_db_screts(rds_db_name):

  if rds_db_name == 'CPP':
    scope_key = "f1_cafdb_cpp_publish"
  elif rds_db_name == 'FLAIR':
    scope_key = "f1_cafdb_flair_publish"
  elif rds_db_name == 'CAFMART':
    scope_key = "f1_cafdb_cafmart_publish"
  elif rds_db_name == 'GDOLT':
    scope_key = "f1_cafdb_gdolt_publish"
  elif rds_db_name == 'ADHOC':
    scope_key = "f1_cafdb_adhoc_publish"
  elif rds_db_name == 'CA_TMOMETER':
        scope_key = "f1_cafdb_tmometer_publish"
  elif rds_db_name == 'CAFDB':
    scope_key = "f1_cafdb_publish"
  elif rds_db_name == 'RDI':
    scope_key = "f1_cafdb_rdi_publish"
  else:
    scope_key = "f1_super_cafdb_publish"
  secrets_key = "rds_cafdb"
  driver = "org.postgresql.Driver"
  secrets = {"jdbcUsername": dbutils.secrets.get(scope=scope_key, key=secrets_key+"_user_name"),
               "jdbcPassword": dbutils.secrets.get(scope=scope_key, key=secrets_key+"_password"),
               "jdbcUrl": dbutils.secrets.get(scope=scope_key, key=secrets_key+"_jdbc_url")
              }
  return secrets

# COMMAND ----------

def rds_table_read(table_name,db_name):
  driver = "org.postgresql.Driver"
  secrets = rds_db_screts(db_name)
  print(secrets)
#   db_table = "test"
  df_read_metadata=spark.read \
  .format("jdbc") \
  .option("url", secrets['jdbcUrl']) \
  .option("fetchsize", 1000) \
  .option("dbtable", table_name) \
  .option("user", secrets['jdbcUsername']) \
  .option("password", secrets['jdbcPassword']) \
  .option("driver", "com.mysql.jdbc.Driver") \
  .load()
  df_read_metadata.createOrReplaceTempView('tmp_'+table_name)
  return df_read_metadata

# COMMAND ----------

def write_df_into_rds(df,target_table_name,write_mode,secrets):
  try:
    if write_mode == 'overwrite':
      l_table_truncate = 'true'
    else:
      l_table_truncate = 'false'
      
    print(target_table_name)
    df.write.format('jdbc').options(
      url=secrets['jdbcUrl'],
      driver='com.mysql.jdbc.Driver',
      dbtable=target_table_name,
      truncate= l_table_truncate,
      user=secrets['jdbcUsername'],
      password =secrets['jdbcPassword']).mode(write_mode).save()  #overwrite    append    ignore
  except Exception as error:
    print("job got failed while reading rds tables : {}".format(error))
    print(error)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Horizon Table Read

# COMMAND ----------

source_file_path_dict_actual = [{'path': 's3a://novartisrs3aprdief1raw001/landing/odh/horizon_reporting_dm/v_activity_baseline', 'table_name': 'tmp_v_activity_baseline', 'read_layer': 'landing'}]
source = FileUtils(spark)
for source_file_path in source_file_path_dict_actual:
        print (source_file_path)
        dataframe = source.create_source_dataframe(source_file_path)
        dataframe.createOrReplaceTempView(source_file_path["table_name"])

# COMMAND ----------

source_file_path_dict = [{'path': 's3a://novartisrs3aprdief1raw001/landing/odh/horizon_reporting_dm/v_wp_single_current', 'table_name': 'tmp_v_wp_single_current', 'read_layer': 'landing'}]
source = FileUtils(spark)
for source_file_path in source_file_path_dict:
        print (source_file_path)
        dataframe = source.create_source_dataframe(source_file_path)
        dataframe.createOrReplaceTempView(source_file_path["table_name"])

# COMMAND ----------

      
source_file_path_dict_actual = [{'path': 's3a://novartisrs3aprdief1raw001/landing/odh/horizon_reporting_dm/v_milestone_baseline', 'table_name': 'tmp_v_milestone_baseline', 'read_layer': 'landing'}]
source = FileUtils(spark)
for source_file_path in source_file_path_dict_actual:
        print (source_file_path)
        dataframe = source.create_source_dataframe(source_file_path)
        dataframe.createOrReplaceTempView(source_file_path["table_name"])


# COMMAND ----------

source_file_path_dict_actual = [{'path': 's3a://novartisrs3aprdief1raw001/landing/odh/horizon_reporting_dm/v_wp_project_map', 'table_name': 'tmp_v_wp_project_map', 'read_layer': 'landing'}]
source = FileUtils(spark)
for source_file_path in source_file_path_dict_actual:
        print (source_file_path)
        dataframe = source.create_source_dataframe(source_file_path)
        dataframe.createOrReplaceTempView(source_file_path["table_name"])



# COMMAND ----------


source_file_path_dict = [{'path': 's3a://novartisrs3aprdief1raw001/landing/odh/horizon_cdb/cur_milestone_planned', 'table_name': 'tmp_horizon_planned', 'read_layer': 'landing'}]
source = FileUtils(spark)
for source_file_path in source_file_path_dict:
        print (source_file_path)
        dataframe = source.create_source_dataframe(source_file_path)
        dataframe.createOrReplaceTempView(source_file_path["table_name"])
		
source_file_path_dict_actual = [{'path': 's3a://novartisrs3aprdief1raw001/landing/odh/horizon_cdb/cur_milestone_actual', 'table_name': 'tmp_horizon_actual', 'read_layer': 'landing'}]
source = FileUtils(spark)
for source_file_path in source_file_path_dict_actual:
        print (source_file_path)
        dataframe = source.create_source_dataframe(source_file_path)
        dataframe.createOrReplaceTempView(source_file_path["table_name"])



# COMMAND ----------

# MAGIC %md
# MAGIC ###Nagesh Adhoc 
# MAGIC

# COMMAND ----------

df_actuals_r=spark.sql("""select
  distinct parent_sub_entity_cd as study_code_alias,
  milestone_event_num,
  milestone_event_nm,
cast(milestone_dt as Date) as actual_date
from tmp_horizon_actual
where milestone_event_num in (3204,3704)
and parent_sub_entity_cd!='null' 
and parent_sub_entity_cd IS NOT NULL
order by study_code_alias,milestone_event_num,actual_date asc
""")

df_planned_r=spark.sql("""select
  distinct parent_sub_entity_cd as study_code_alias,
  milestone_event_num,
  milestone_event_nm,
  cast(milestone_dt as Date) as planned_date
from
  tmp_horizon_planned
where milestone_event_num in (3204,3704)
  and parent_sub_entity_cd IS NOT NULL and  parent_sub_entity_cd!="null" 
  and milestone_dt!='null' 
  order by study_code_alias,milestone_event_num,planned_date asc
  """)

# COMMAND ----------

df_actuals_r.createOrReplaceTempView("df_actuals_rt")
df_planned_r.createOrReplaceTempView("df_planned_rt")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select 
# MAGIC COALESCE(NULL,a.study_code_alias,p.study_code_alias) AS study_code_alias,
# MAGIC COALESCE(NULL,a.milestone_event_num,p.milestone_event_num) AS milestone_event_nm,
# MAGIC COALESCE(NULL,a.milestone_event_nm,p.milestone_event_nm) AS milestone_event_nm,
# MAGIC a.actual_date,
# MAGIC p.planned_date
# MAGIC from df_actuals_rt a
# MAGIC full outer join df_planned_rt p
# MAGIC on a.study_code_alias=p.study_code_alias
# MAGIC and a.milestone_event_num=p.milestone_event_num

# COMMAND ----------

df = df_actuals_r.join(df_planned_r,["study_code_alias","milestone_event_num"],"fullouter")

# COMMAND ----------

display(df)

# COMMAND ----------



# COMMAND ----------

display(df)

# COMMAND ----------


try:
  read_params = {
    "source_file_path": dbutils.widgets.get("source_file_path")
  }
except:
  print("no F1 source for target table load")


# COMMAND ----------

source_file_path_dict_actual = json.loads(read_params["source_file_path"].replace("'", '"'))
print(source_file_path_dict_actual)

# COMMAND ----------

source = FileUtils(spark)
for source_file_path in source_file_path_dict_actual:
        print (source_file_path)
        dataframe = source.create_source_dataframe(source_file_path)
        dataframe.createOrReplaceTempView(source_file_path["table_name"])

# COMMAND ----------

# MAGIC %md
# MAGIC ### CDO_MILESTONE_DB_SNAPSHOT

# COMMAND ----------

df = spark.sql("""
SELECT ACT.WORKPACKAGE_CD WORK_ID, 
WP.STUDY_CD TRIAL_CODE, 
ACT.ACTIVITY_NM ACTIVITY_NAME,
WP.WORKPACKAGE_MANAGER,
WP.WORKPACKAGE_OWNER, 
ACT.PLANNED_START_DT as ACTIVITY_PLANNED_START,
ACT.ACTUAL_START_DT as ACTIVITY_ACTUAL_START,
COALESCE(NULL,ACT.ACTUAL_START_DT,ACT.PLANNED_START_DT) AS ACTIVITY_START,
YEAR(current_date()) as current_year,
YEAR(current_date())+1 as next_year,
ACT.PLANNED_FINISH_DT as ACTIVITY_PLANNED_FINISH,
ACT.ACTUAL_FINISH_DT as ACTIVITY_ACTUAL_FINISH,
MS.MILESTONE_EVENT_NM || ' - ' || MS.MILESTONE_EVENT_NUM MILESTONE_EVENT,
MS.PLANNED_DT,MS.ACTUAL_DT,
MS.BASELINE_FINISH 
FROM tmp_v_activity_baseline ACT,
(SELECT WORKPACKAGE_TECHNICAL_ID, MILESTONE_EVENT_NM, MILESTONE_EVENT_NUM, PLANNED_DT,ACTUAL_DT, MILESTONE_FATHER,BASELINE_FINISH 
FROM tmp_v_milestone_baseline
WHERE MILESTONE_EVENT_NUM IN (4000, 3709, 3700, 3711, 3705, 3773, 3634, 3534, 3926, 3544, 3938, 3710, 
3712, 3708, 3707, 3664, 3514, 3914, 3964, 3676, 3946, 3968, 3922, 3976, 3672, 3680, 3942, 3719, 3524, 3688,
3668, 3918, 3706, 3934, 3644, 3930, 3738, 3769, 3972, 3684) 
)MS,
(SELECT WORKPACKAGE_TECHNICAL_ID, STUDY_CD,WORKPACKAGE_MANAGER,WORKPACKAGE_OWNER 
FROM tmp_v_wp_single_current 
WHERE STUDY_CD IS NOT NULL
)WP 
WHERE WP.WORKPACKAGE_TECHNICAL_ID = ACT.WORKPACKAGE_TECHNICAL_ID
AND ACT.WORKPACKAGE_TECHNICAL_ID = MS.WORKPACKAGE_TECHNICAL_ID
AND ACT.ACTIVITY_BL_TECHNICAL_ID = MS.MILESTONE_FATHER
ORDER BY 1
""")

df.count()

# COMMAND ----------

display(df)
df.createOrReplaceTempView("df_t")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from df_t
# MAGIC -- where TRIAL_CODE = "CYTB323A12101"
# MAGIC where TRIAL_CODE = "CKJX839C12302"
# MAGIC -- CAIN457Q12301
# MAGIC -- CKJX839C12302

# COMMAND ----------

df = df.filter(df.ACTIVITY_NAME.rlike("Snapshot") | df.ACTIVITY_NAME.rlike("snapshot"))
display(df)

# COMMAND ----------

df = df.filter(df.ACTIVITY_NAME.rlike("Snapshot") | df.ACTIVITY_NAME.rlike("snapshot"))
df = df.filter((year(df.ACTIVITY_START) >= df.current_year) & (year(df.ACTIVITY_START) <= df.next_year))

today = datetime.today()
start = today - timedelta(days=today.weekday())

df.count()

# COMMAND ----------

df = df.withColumnRenamed("TRIAL_CODE", "study_code_alias")\
  .withColumnRenamed("ACTIVITY_NAME","milestone_event_nm")\
  .withColumn("updated_milestone_name",lit("Snapshot"))\
  .withColumn("Type",lit("planned"))\
  .withColumnRenamed("ACTIVITY_START","milestone_dt")
  
df = df.select("study_code_alias","milestone_event_nm","updated_milestone_name","Type","milestone_dt")

# COMMAND ----------

display(df)

# COMMAND ----------

df = df.groupBy("study_code_alias","milestone_event_nm","updated_milestone_name","Type") \
      .agg(max("milestone_dt").alias("milestone_dt"))

df = df.withColumn("data_refresh_date",lit(today))\
  .withColumn("run_refresh_date",lit(start))
  
df = df.select("study_code_alias","milestone_event_nm","updated_milestone_name","Type","milestone_dt","data_refresh_date","run_refresh_date")

display(df)

# COMMAND ----------

secrets = rds_db_screts('CA_TMOMETER')
# write_df_into_rds(df,'CDO_MILESTONE_DB_SNAPSHOT','append',secrets)

# COMMAND ----------

# MAGIC %md
# MAGIC ### CDO_HORIZON_STUDY_MILESTONE

# COMMAND ----------

#actual_date in future mark as data_error
df_actuals=spark.sql("""select
  distinct parent_sub_entity_cd,
  milestone_event_num,
  milestone_event_nm,
  cast(milestone_dt as Date) as milestone_dt_actuals,
  CASE
  when CAST( CURRENT_TIMESTAMP AS Date )< milestone_dt then 'yes'
  else 'no'
  end as data_error
from
  tmp_horizon_actual
where
  (milestone_event_nm like '%IDC%'
  or milestone_event_nm like '%data cut off %'
  or milestone_event_nm like '%All CRF data%'
  or milestone_event_num=3700
  or milestone_event_nm like '%Last Data Generated%'
  or milestone_event_nm like '%iDB%'
  or milestone_event_num=4000 or milestone_event_num=3774)
  and parent_sub_entity_cd!='null' and parent_sub_entity_cd IS NOT NULL
  order by parent_sub_entity_cd,milestone_event_num,milestone_dt_actuals asc""")


df_planned=spark.sql("""select
  distinct parent_sub_entity_cd,
  milestone_event_num,
  milestone_event_nm,
  cast(milestone_dt as Date) as milestone_dt_planned,
  'no' as data_error
from
  tmp_horizon_planned
where
  (milestone_event_nm like '%IDC%'
  or milestone_event_nm like '%data cut off %'
  or milestone_event_nm like '%All CRF data%'
  or milestone_event_num =3700
  or milestone_event_nm like '%Last Data Generated%'
  or milestone_event_nm like '%iDB%'
  or milestone_event_num =4000 or milestone_event_num=3774)
  and parent_sub_entity_cd IS NOT NULL and  parent_sub_entity_cd!="null" and milestone_dt!='null' 
  order by parent_sub_entity_cd,milestone_event_num,milestone_dt_planned asc""") 

# COMMAND ----------

data=df_planned.join(df_actuals,(df_planned.parent_sub_entity_cd==df_actuals.parent_sub_entity_cd)&(df_planned.milestone_event_num==df_actuals.milestone_event_num),'left')

df=data.toPandas()
df=df.iloc[:,[0,1,2,3,8,9]]
df.sort_values(by=['parent_sub_entity_cd','milestone_event_num','milestone_dt_planned'],inplace=True)

df['milestone_name']=df['milestone_event_nm']
df.loc[df["milestone_name"].str.contains('IDC'), "milestone_name"] = 'Data cut off(IDC)'
df.loc[df["milestone_name"].str.contains('All CRF data'), "milestone_name"] = 'All CRF data In'
df.loc[df["milestone_name"].str.contains('Last Data Generated'), "milestone_name"] = 'Last Data Generated'
df.loc[df["milestone_name"].str.contains('iDB'), "milestone_name"] = 'iDBL'
df.loc[df["milestone_name"].str.contains('LPLV'), "milestone_name"] = 'LPLV'
df.loc[df["milestone_name"].str.contains('DBL - Final Clinical DB Lock'), "milestone_name"] = 'DBL'

df_dbl_lplv_d=df[(df["milestone_event_num"]=='4000') | (df["milestone_event_num"]=='3700') | (df["milestone_event_num"]=='3774')]

df_dbl_lplv_previous_planned=df_dbl_lplv_d[df_dbl_lplv_d['milestone_dt_planned']<=date.today()]
df_dbl_lplv_next_planned=df_dbl_lplv_d[df_dbl_lplv_d['milestone_dt_planned']>date.today()]

df_dbl_lplv_previous_planned['milestone_dt_previous_planned']=df_dbl_lplv_d['milestone_dt_planned']

df_dbl_lplv_next_planned['milestone_dt_next_planned']=df_dbl_lplv_d['milestone_dt_planned'] 
df_dbl_lplv=pd.concat([df_dbl_lplv_previous_planned,df_dbl_lplv_next_planned])

df=df[(df["milestone_event_num"]!='4000') & (df["milestone_event_num"]!='3700') & (df["milestone_event_num"]!='3774')]

df_dbl_lplv=df_dbl_lplv.iloc[:,[0,1,6,2,7,4,8,5]]


# COMMAND ----------

df_previous_planned=df[df['milestone_dt_planned']<=date.today()]
df_next_planned=df[df['milestone_dt_planned']> date.today()]
final=df_previous_planned.groupby(['parent_sub_entity_cd','milestone_name']).agg({'milestone_dt_planned': [np.max]}).reset_index()
final_next=df_next_planned.groupby(['parent_sub_entity_cd','milestone_name']).agg({'milestone_dt_planned': [np.min]}).reset_index()
final.columns = ["_".join(col_name).rstrip('_') for col_name in final.columns]
final_next.columns = ["_".join(col_name).rstrip('_') for col_name in final_next.columns]
final.rename(columns = {'milestone_dt_planned_amax':'milestone_dt_previous_planned'}, inplace = True)
final_next.rename(columns = {'milestone_dt_planned_amin':'milestone_dt_next_planned'}, inplace = True)
new_df = pd.merge(final, df_previous_planned,how='inner', left_on=['parent_sub_entity_cd','milestone_name','milestone_dt_previous_planned'], right_on = ['parent_sub_entity_cd','milestone_name','milestone_dt_planned'])
new_df_next = pd.merge(final_next, df_next_planned,how='inner', left_on=['parent_sub_entity_cd','milestone_name','milestone_dt_next_planned'], right_on = ['parent_sub_entity_cd','milestone_name','milestone_dt_planned'])
new_df=new_df.iloc[:,[0,3,1,4,2,6,7]]
new_df_next=new_df_next.iloc[:,[0,3,1,4,2,6,7]]

# COMMAND ----------


new_df['milestone_dt_next_planned']=np.nan
new_df_next['milestone_dt_previous_planned']=np.nan

new_df=new_df.iloc[:,[0,1,2,3,4,5,7,6]]
new_df_next=new_df_next.iloc[:,[0,1,2,3,7,5,4,6]]

final_data=pd.concat([new_df,new_df_next])

new_data=pd.concat([final_data,df_dbl_lplv])
today=date.today()

new_data['data_refresh_date']=pd.Timestamp.now()
start = today - timedelta(days=today.weekday())

new_data['run_refresh_date']=start
columns = StructType([StructField('parent_sub_entity_cd',StringType(), True),
                      StructField('milestone_event_num',StringType(), True),
                      StructField('milestone_name',StringType(), True),
                      StructField('milestone_event_nm',StringType(), True),
                      StructField('milestone_dt_previous_planned',DateType(), True),
                      StructField('milestone_dt_actuals',DateType(), True),
                      StructField('milestone_dt_next_planned',DateType(),True),
                      StructField('data_error',StringType(),True),
                      StructField('data_refresh_date',TimestampType(),True),
                      StructField('run_refresh_date',DateType(),True)                                                  
                     ])
myres=spark.createDataFrame(new_data,schema=columns)

# COMMAND ----------

secrets = rds_db_screts('CA_TMOMETER')
write_df_into_rds(myres,'CDO_HORIZON_STUDY_MILESTONE','append',secrets)

# COMMAND ----------

# MAGIC %md
# MAGIC ###CDO_MILESTONE_RAW

# COMMAND ----------

tmp_CDO_MILESTONE_DB_SNAPSHOT = rds_table_read('CDO_MILESTONE_DB_SNAPSHOT','CA_TMOMETER')

# COMMAND ----------

db_snapshot = spark.sql("""
select study_code_alias,
'8888' as   milestone_event_num,
milestone_event_nm as  milestone_event_nm,
updated_milestone_name as  updated_milestone_name,
type as type,
cast(milestone_dt as Date) as milestone_dt 
from tmp_CDO_MILESTONE_DB_SNAPSHOT
where  data_refresh_date in (select max(data_refresh_date) from tmp_CDO_MILESTONE_DB_SNAPSHOT)
""")

# COMMAND ----------

db_snap_raw = db_snapshot.toPandas()


# COMMAND ----------

df_actuals_r=spark.sql("""select
  distinct parent_sub_entity_cd as study_code_alias,
  milestone_event_num,
  milestone_event_nm,
 
'Actuals' as type,
cast(milestone_dt as Date) as milestone_dt
from
  tmp_horizon_actual
where
  (milestone_event_nm like '%IDC%'
  or milestone_event_nm like '%data cut off %'
  or milestone_event_nm like '%All CRF data%'
  or milestone_event_num=3700
  or milestone_event_nm like '%Last Data Generated%'
  or milestone_event_nm like '%iDB%'
  or milestone_event_num=4000 or milestone_event_num=3774)
  and parent_sub_entity_cd!='null' and parent_sub_entity_cd IS NOT NULL
  order by study_code_alias,milestone_event_num,milestone_dt asc""")

df_planned_r=spark.sql("""select
  distinct parent_sub_entity_cd as study_code_alias,
  milestone_event_num,
  milestone_event_nm,
  'Planned' as type,
  cast(milestone_dt as Date) as milestone_dt
from
  tmp_horizon_planned
where
  (milestone_event_nm like '%IDC%'
  or milestone_event_nm like '%data cut off %'
  or milestone_event_nm like '%All CRF data%'
  or milestone_event_num=3700
  or milestone_event_nm like '%Last Data Generated%'
  or milestone_event_nm like '%iDB%'
  or milestone_event_num =4000 or milestone_event_num=3774)
  and parent_sub_entity_cd IS NOT NULL and  parent_sub_entity_cd!="null" and milestone_dt!='null' 
  order by study_code_alias,milestone_event_num,milestone_dt asc""")

# COMMAND ----------

df_actuals_r=df_actuals_r.toPandas()
df_planned_r=df_planned_r.toPandas()
data_raw=pd.concat([df_actuals_r,df_planned_r])
data_raw['updated_milestone_name']=data_raw['milestone_event_nm']
data_raw.loc[data_raw["updated_milestone_name"].str.contains('IDC'), "updated_milestone_name"] = 'Data cut off(IDC)'
data_raw.loc[data_raw["updated_milestone_name"].str.contains('All CRF data'), "updated_milestone_name"] = 'All CRF data In'
data_raw.loc[data_raw["updated_milestone_name"].str.contains('Last Data Generated'), "updated_milestone_name"] = 'Last Data Generated'
data_raw.loc[data_raw["updated_milestone_name"].str.contains('LPLV'), "updated_milestone_name"] = 'LPLV'
data_raw.loc[data_raw["updated_milestone_name"].str.contains('iDB'), "updated_milestone_name"] = 'iDBL'
data_raw.loc[data_raw["updated_milestone_name"].str.contains('DBL - Final Clinical DB Lock'), "updated_milestone_name"] = 'DBL'

data_raw=data_raw.iloc[:,[0,1,2,5,3,4]]

# COMMAND ----------

spark.conf.set("spark.sql.execution.arrow.enabled", "true")

# COMMAND ----------

df_data_raw=pd.concat([data_raw,db_snap_raw])

# COMMAND ----------

today=date.today()
# print(today)
three_months_from_now = date.today() + relativedelta(months=+3)
# print(three_months_from_now)
six_months_from_now = date.today() + relativedelta(months=+6)
# print(six_months_from_now)
nine_months_from_now = date.today() + relativedelta(months=+9)
# print(nine_months_from_now)
twelve_months_from_now = date.today() + relativedelta(months=+12)
# print(twelve_months_from_now)

# COMMAND ----------

df_data_raw.loc[(df_data_raw['type']=='Planned')&(df_data_raw['milestone_dt'] <today), 'planned_milestone_flag'] = 'Past planned milestone'
df_data_raw.loc[(df_data_raw['type']=='Planned')&(df_data_raw['milestone_dt'] >=today)&(df_data_raw['milestone_dt'] <three_months_from_now), 'planned_milestone_flag'] = 'Current day to 3 months'
df_data_raw.loc[(df_data_raw['type']=='Planned')&(df_data_raw['milestone_dt'] >=three_months_from_now)&(df_data_raw['milestone_dt'] <six_months_from_now), 'planned_milestone_flag'] = '3 to 6 months'
df_data_raw.loc[(df_data_raw['type']=='Planned')&(df_data_raw['milestone_dt'] >= six_months_from_now)& (df_data_raw['milestone_dt']< nine_months_from_now), 'planned_milestone_flag'] = '6 to 9 months'
df_data_raw.loc[(df_data_raw['type']=='Planned')&(df_data_raw['milestone_dt'] >=nine_months_from_now)&(df_data_raw['milestone_dt']<twelve_months_from_now), 'planned_milestone_flag'] = '9 to 12 months'
df_data_raw.loc[(df_data_raw['type']=='Planned')&(df_data_raw['milestone_dt']>=twelve_months_from_now),'planned_milestone_flag'] = 'After 12 months'


# COMMAND ----------

currentyeardate = date(date.today().year, 1, 1)
df_data_raw.loc[(df_data_raw['type']=='Actuals')&(df_data_raw['milestone_dt']>=currentyeardate)&(df_data_raw['milestone_dt']<today), 'actuals_YTD_Flag'] = 'Yes'
df_data_raw.loc[(df_data_raw['type']=='Actuals')&(~(df_data_raw['milestone_dt']>=currentyeardate)&(df_data_raw['milestone_dt']<today)), 'actuals_YTD_Flag'] = 'No'


# COMMAND ----------

today=date.today()
df_data_raw['data_refresh_date']=pd.Timestamp.now() 
start = today - timedelta(days=today.weekday())
df_data_raw['run_refresh_date']=start
# display(df_data_raw)

# COMMAND ----------

columns = StructType([StructField('study_code_alias',StringType(), True),
                      StructField('milestone_event_num',StringType(), True),
                      StructField('milestone_event_nm',StringType(), True),
                      StructField('updated_milestone_name',StringType(), True),
                      StructField('type',StringType(), True),
                      StructField('milestone_dt',DateType(), True),
                      StructField('planned_milestone_flag',StringType(), True),
                      StructField('actuals_YTD_Flag',StringType(), True),
                      StructField('data_refresh_date',TimestampType(), True),
                      StructField('run_refresh_date',DateType(), True)                                
                     ])
myres_raw=spark.createDataFrame(df_data_raw,schema=columns)
# display(myres_raw)


# COMMAND ----------


secrets = rds_db_screts('CA_TMOMETER')
write_df_into_rds(myres_raw,'CDO_MILESTONE_RAW','append',secrets)

# COMMAND ----------

# MAGIC %md
# MAGIC ### CDO_OPEN_QUERIES_RAVE_COUNT

# COMMAND ----------

open_queries=spark.sql("""select  study_code_alias,country_name as country_code,count(*) as open_query_count from clinical_data_management_unified.rave_query_detail where query_status=1 group by study_code_alias,country_code""")

open_queries=open_queries.toPandas()

today = date.today()
start = today - timedelta(days=today.weekday())
open_queries['data_refresh_date']=pd.Timestamp.now() 
open_queries['run_refresh_date']=start

# COMMAND ----------

columns = StructType([StructField('study_code_alias',StringType(), True),
                      StructField('country_code',StringType(), True),
                      StructField('open_query_count',IntegerType(), True),
                      StructField('data_refresh_date',TimestampType(), True),
                      StructField('run_refresh_date',DateType(), True)                                  
                     ])
myres=spark.createDataFrame(open_queries,schema=columns)

# COMMAND ----------

secrets = rds_db_screts('CA_TMOMETER')
write_df_into_rds(myres,'CDO_OPEN_QUERIES_RAVE_COUNT','append',secrets)

# COMMAND ----------

# MAGIC %md
# MAGIC ###CDO_MISSING_PI_SIGN_RAVE_COUNT

# COMMAND ----------

missing_PI_signatures=spark.sql("""select project as study_code_alias,countryname as country_code, count(*) as missing_PI_count
from dial_raveops_landing.raveops_page_status where sign =1 and audit_updated_tmstmp in (select max(audit_updated_tmstmp) from dial_raveops_landing.raveops_page_status) group by project,countryname""")

missing_PI_signatures=missing_PI_signatures.toPandas()
today = date.today()
missing_PI_signatures['data_refresh_date']=pd.Timestamp.now() 

start = today - timedelta(days=today.weekday())
missing_PI_signatures['run_refresh_date']=start
missing_PI_signatures['missing_PI_count']=missing_PI_signatures['missing_PI_count'].fillna(0)


# COMMAND ----------

columns = StructType([StructField('study_code_alias',StringType(), True),
                      StructField('country_code',StringType(), True),
                      StructField('missing_PI_count',IntegerType(), True),
                      StructField('data_refresh_date',TimestampType(), True),
                      StructField('run_refresh_date',DateType(), True)                                
                     ])
myres=spark.createDataFrame(missing_PI_signatures,schema=columns)

# COMMAND ----------

secrets = rds_db_screts('CA_TMOMETER')
write_df_into_rds(myres,'CDO_MISSING_PI_SIGN_RAVE_COUNT','append',secrets)

# COMMAND ----------

# MAGIC %md
# MAGIC ### CDO_SIGNED_PI_SIGN_RAVE_COUNT

# COMMAND ----------

signed_signatures=spark.sql("""select project as study_code_alias,countryname as country_code, count(*) as total_signed_count
from dial_raveops_landing.raveops_page_status where sign =0 and audit_updated_tmstmp in (select max(audit_updated_tmstmp) from dial_raveops_landing.raveops_page_status) group by project,countryname  order by study_code_alias,country_code """)
signed_signatures=signed_signatures.toPandas()

# COMMAND ----------


today = date.today()
signed_signatures['data_refresh_date']=pd.Timestamp.now() 

start = today - timedelta(days=today.weekday())
signed_signatures['run_refresh_date']=start
signed_signatures['total_signed_count']=signed_signatures['total_signed_count'].fillna(0)
columns = StructType([StructField('study_code_alias',StringType(), True),
                      StructField('country_code',StringType(), True),
                      StructField('total_signed_count',IntegerType(), True),
                      StructField('data_refresh_date',TimestampType(), True),
                      StructField('run_refresh_date',DateType(), True)                                
                     ])
myres=spark.createDataFrame(signed_signatures,schema=columns)

# COMMAND ----------

secrets = rds_db_screts('CA_TMOMETER')
write_df_into_rds(myres,'CDO_SIGNED_PI_SIGN_RAVE_COUNT','append',secrets)

# COMMAND ----------

# MAGIC %md
# MAGIC ###CDO_TOTAL_PAGES_ENTERED_COUNT

# COMMAND ----------

pages_count=spark.sql("""select project as study_code_alias,countryname as country_code, count(*) as total_pages_entered
from dial_raveops_landing.raveops_page_status where  audit_updated_tmstmp in (select max(audit_updated_tmstmp) from dial_raveops_landing.raveops_page_status) group by project,country_code""")

pages_count=pages_count.toPandas()

# COMMAND ----------

pages_count['data_refresh_date']=pd.Timestamp.now() 
today = date.today()

start = today - timedelta(days=today.weekday())
pages_count['run_refresh_date']=start
pages_count['total_pages_entered']=pages_count['total_pages_entered'].fillna(0)
columns = StructType([StructField('study_code_alias',StringType(), True),
                      StructField('country_code',StringType(), True),
                      StructField('total_pages_entered',IntegerType(), True),
                      StructField('data_refresh_date',TimestampType(), True),
                      StructField('run_refresh_date',DateType(), True)                                
                     ])
myres=spark.createDataFrame(pages_count,schema=columns)

# COMMAND ----------

secrets = rds_db_screts('CA_TMOMETER')
write_df_into_rds(myres,'CDO_TOTAL_PAGES_ENTERED_COUNT','append',secrets)

# COMMAND ----------

# MAGIC %md
# MAGIC ### CDO_IE_TRIALS_HORIZON

# COMMAND ----------

tmp_CDO_MILESTONE_RAW = rds_table_read('CDO_MILESTONE_RAW','CA_TMOMETER')
tmp_Book_of_Work_Origin_Excel = rds_table_read('Book_of_Work_Origin_Excel','CAFMART')
tmp_Milestone_Report_iDOT = rds_table_read('Milestone_Report_iDOT','CA_TMOMETER')
tmp_GDOLT_MV_KPI_MASTER = rds_table_read('GDOLT_MV_KPI_MASTER','CAFMART')
tmp_RegionCountryMapping = rds_table_read('RegionCountryMapping','CAFMART')

# COMMAND ----------


df_actuals=spark.sql("""select
  distinct parent_sub_entity_cd,
  milestone_event_num,
  milestone_event_nm,
  cast(milestone_dt as Date) as milestone_dt_actuals
from
  tmp_horizon_actual
where
  (milestone_event_num=3200
  or milestone_event_num=4000 
  or milestone_event_num=3700)
  and parent_sub_entity_cd!='null' 
  and parent_sub_entity_cd IS NOT NULL
  order by parent_sub_entity_cd,milestone_event_num,milestone_dt_actuals asc""")


df_planned=spark.sql("""select
  distinct parent_sub_entity_cd,
  milestone_event_num,
  milestone_event_nm,
  cast(milestone_dt as Date) as milestone_dt_planned
from
  tmp_horizon_planned
where
  (milestone_event_num =3200
  or milestone_event_num =4000 
  or milestone_event_num=3700)
  and parent_sub_entity_cd IS NOT NULL 
  and parent_sub_entity_cd!="null" and milestone_dt!='null' 
  order by parent_sub_entity_cd,milestone_event_num,milestone_dt_planned asc""") 
  

# COMMAND ----------

data=df_planned.join(df_actuals,(df_planned.parent_sub_entity_cd==df_actuals.parent_sub_entity_cd)&(df_planned.milestone_event_num==df_actuals.milestone_event_num),'left')

# COMMAND ----------

df=data.toPandas()

df=df.iloc[:,[0,1,2,3,7]]
df.sort_values(by=['parent_sub_entity_cd','milestone_event_num','milestone_dt_planned'],inplace=True)

idb=df

# COMMAND ----------

# df[df['parent_sub_entity_cd']=='CAAA001A12401']

# COMMAND ----------

idb_df_pln=idb.pivot_table(values='milestone_dt_planned', index='parent_sub_entity_cd', columns='milestone_event_nm', aggfunc='first').reset_index()

idb_df_act=idb.pivot_table(values='milestone_dt_actuals', index='parent_sub_entity_cd', columns='milestone_event_nm', aggfunc='first').reset_index()

ie_df= idb_df_pln.merge(idb_df_act , on='parent_sub_entity_cd', how='left')


# COMMAND ----------

milestone_ie_df=spark.createDataFrame(ie_df)

# COMMAND ----------

milestone_ie_df = milestone_ie_df.withColumnRenamed("parent_sub_entity_cd","study_code_alias")

milestone_ie_df = milestone_ie_df.withColumnRenamed("FPFV - FPFV_x","FPFVPlanneddate3200")
milestone_ie_df = milestone_ie_df.withColumnRenamed("FPFV - FPFV_y","FPFVActualdate3200")

milestone_ie_df = milestone_ie_df.withColumnRenamed("DBL - Final Clinical DB Lock_x","ClinPlanneddate4000")
milestone_ie_df = milestone_ie_df.withColumnRenamed("DBL - Final Clinical DB Lock_y","ClinActualdate4000")

milestone_ie_df = milestone_ie_df.withColumnRenamed("LPLV - LPLV_x","LPLV_Planned")
milestone_ie_df = milestone_ie_df.withColumnRenamed("LPLV - LPLV_y","LPLV_Actual")

# COMMAND ----------

display(milestone_ie_df)

# COMMAND ----------

# ie_df[ie_df['parent_sub_entity_cd']=='CAAA001A12401']

# COMMAND ----------

df_hrz_stud = spark.sql("""
select wpsc.study_cd as study_code_alias,wpsc.workpackage_cd,wppm.project_code
from tmp_v_wp_single_current wpsc
inner join tmp_v_wp_project_map wppm
on  wpsc.workpackage_cd = wppm.workpackage_code
where wpsc.study_cd is not null 
and workpackage_type_cd in ("Clinical Study","ClinicalStudy")
and wppm.project_code not like "%_MA" 
""")

# COMMAND ----------

tmp_CDO_MILESTONE_RAW = rds_table_read('CDO_MILESTONE_RAW','CA_TMOMETER')

# COMMAND ----------

df_milestones = spark.sql("""
select * 
from tmp_CDO_MILESTONE_RAW
where type='Planned'
and year(milestone_dt) in ('2023','2024','2025')
""")

# COMMAND ----------

df_all_studies = df_milestones.join(df_hrz_stud,["study_code_alias"],"inner")
df_all_studies = df_all_studies.select('study_code_alias').distinct()
df_all_studies.count()
df_all_studies.createOrReplaceTempView("hrz_studies_dist")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from hrz_studies_dist

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC refresh table clinical_operations_unified.study

# COMMAND ----------


df_impact_study_status = spark.sql("""select study_code_alias,study_status_desc
                                   from clinical_operations_unified.study
                                   """)

df_hrz_stud_imp = df_all_studies.join(df_impact_study_status,["study_code_alias"],"left")

df_hrz_stud_imp = df_hrz_stud_imp.filter((col("study_status_desc") == 'Active') | (col("study_status_desc") == 'Planned') | (col("study_status_desc") == 'Completed')) 
                             
df_hrz_stud_imp.count()


# COMMAND ----------

display(df_hrz_stud_imp)

# COMMAND ----------

milestone_ie_df.count()

# COMMAND ----------

df_hrz_stud_imp.count()

# COMMAND ----------

milestone_ie_df.createOrReplaceTempView("milestones_32_40")
df_hrz_stud_imp.createOrReplaceTempView("tbl_all_studies")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from tbl_all_studies

# COMMAND ----------

df_horizon_bow_data = spark.sql("""
select 
distinct hrz.study_code_alias as STUDY_CD,
hrz.study_status_desc as IMPACT_TRIAL_STATUS,

bow.Organization_Unit_Operated_By as ORGANIZATION_UNIT,
bow.Managing_Line_Function as MANAGING_LINE_FUNCTION_NM,
bow.GDO_TM_Sourcing as GDO_TM_SOURCING,
bow.GDO_Monitoring_Sourcing as GDO_MONITORING,
bow.GDO_DM_Sourcing as GDO_DM_SOURCING,
bow.GDO_MW_Sourcing as GDO_MW_SOURCING,
bow.GDO_SP_Sourcing as GDO_SP_SOURCING,
bow.DMC_SP_Sourcing as DMC_SP_SOURCING,
bow.SDTM_SP_Sourcing AS SDTM_SP_SOURCING,
bow.GDO_TOM_Sourcing AS GDO_TOM_SOURCING,
bow.GDO_Sourcing AS GDO_SOURCING,

mil.FPFVPlanneddate3200, 
mil.FPFVActualdate3200,
mil.ClinPlanneddate4000,
mil.ClinActualdate4000,
mil.LPLV_Planned,
mil.LPLV_Actual
from tbl_all_studies hrz 

left join milestones_32_40 mil
on mil.study_code_alias =hrz.study_code_alias

left join tmp_Book_of_Work_Origin_Excel bow
on  hrz.study_code_alias =bow.Trial
""")

# COMMAND ----------

print(df_horizon_bow_data.count())
bow = df_horizon_bow_data

# COMMAND ----------

# DBTITLE 1,DBL iDBL Dates logic
bow=bow.toPandas()

idb=spark.sql("""select study_code_alias as STUDY_CD,milestone_event_nm,milestone_dt 
              from tmp_CDO_MILESTONE_RAW 
              where updated_milestone_name='iDBL' 
              and type='Planned' 
              and data_refresh_date in (select max(data_refresh_date) from tmp_CDO_MILESTONE_RAW)
              and milestone_dt >= current_date()
              order by study_code_alias ,milestone_event_num 
              """)
idb.count()
idb=idb.toPandas()


# COMMAND ----------

idb.count()

# COMMAND ----------

idb_df=idb.pivot_table(values='milestone_dt', index='STUDY_CD', columns='milestone_event_nm', aggfunc='first').reset_index()

ie_df= bow.merge(idb_df , on='STUDY_CD', how='left')

# COMMAND ----------

ie_df.count()

# COMMAND ----------

ie_df.rename(columns={'iDB 1 - Interim Database Lock 1':'IDB1','iDB 2 - Interim Database Lock 2':'IDB2','iDB 3 - Interim Database Lock 3':'IDB3','iDB 4 - Interim Database Lock 4':'IDB4','iDB 5 - Interim Database Lock 5':'IDB5','iDB 6 - Interim Database Lock 6':'IDB6','iDB 7 - Interim Database Lock 7':'IDB7','iDB 8 - Interim Database Lock 8':'IDB8','iDB 9 - Interim Database Lock 9':'IDB9','iDB 10 - Interim Database Lock 10':'IDB10','iDB 11 - Interim Database Lock 11':'IDB11','iDB 12 - Interim Database Lock 12':'IDB12','iDB 13 - Interim Database Lock 13':'IDB13','iDB 14 - Interim Database Lock 14':'IDB14','iDB 15 - Interim Database Lock 15':'IDB15','iDB 16 - Interim Database Lock 16':'IDB16'},inplace=True)


# COMMAND ----------

col_to_add = ["IDB1",	"IDB2",	"IDB3",	"IDB4",	"IDB5",	"IDB6",	"IDB7",	"IDB8",	"IDB9",	"IDB10",	"IDB11",	"IDB12",	"IDB13",	"IDB14",	"IDB15",	"IDB16"]

# COMMAND ----------

for col in col_to_add:
  if col not in ie_df.columns:
    ie_df[col] = None
  else:
    # print("Column : exists")
    pass


# COMMAND ----------

today=date.today()
print(today)
three_months_from_now = date.today() + relativedelta(months=+3)
print(three_months_from_now)
six_months_from_now = date.today() + relativedelta(months=+6)
print(six_months_from_now)
twelve_months_from_now = date.today() + relativedelta(months=+12)
print(twelve_months_from_now)
eighteen_months_from_now = date.today() + relativedelta(months=+18)
print(eighteen_months_from_now)

# COMMAND ----------

ie_df.loc[ie_df['ClinPlanneddate4000'] <today, 'DBL_FLAG'] = 'Past planned DBL'
ie_df.loc[(ie_df['ClinPlanneddate4000'] >=today)&(ie_df['ClinPlanneddate4000'] <six_months_from_now), 'DBL_FLAG'] = 'Current day to 6 months'
ie_df.loc[(ie_df['ClinPlanneddate4000'] >= six_months_from_now)& (ie_df['ClinPlanneddate4000']< twelve_months_from_now), 'DBL_FLAG'] = '6 to 12 months'
ie_df.loc[(ie_df['ClinPlanneddate4000'] >=twelve_months_from_now)&(ie_df['ClinPlanneddate4000']<eighteen_months_from_now), 'DBL_FLAG'] = '12 to 18 months'
ie_df.loc[ie_df['ClinPlanneddate4000'] >=eighteen_months_from_now, 'DBL_FLAG'] = 'After 18 months'

ie_df.loc[(ie_df['ClinActualdate4000']< date.today()) &  (~ie_df['ClinPlanneddate4000'].notnull()),'DBL_FLAG'] = 'Actual DBL in past, no planned DBL'

ie_df.loc[((ie_df['ClinPlanneddate4000'] >=today)&(ie_df['ClinPlanneddate4000'] <three_months_from_now))|
((ie_df['IDB1'] >=today)&(ie_df['IDB1'] <three_months_from_now))|
((ie_df['IDB2'] >=today)&(ie_df['IDB2'] <three_months_from_now))|
((ie_df['IDB3'] >=today)&(ie_df['IDB3'] <three_months_from_now))|
((ie_df['IDB4'] >=today)&(ie_df['IDB4'] <three_months_from_now))|
((ie_df['IDB5'] >=today)&(ie_df['IDB5'] <three_months_from_now))|
((ie_df['IDB6']>=today)&(ie_df['IDB6'] <three_months_from_now))|
((ie_df['IDB7'] >=today)&(ie_df['IDB7'] <three_months_from_now))|
((ie_df['IDB8'] >=today)&(ie_df['IDB8'] <three_months_from_now))|
((ie_df['IDB9'] >=today)&(ie_df['IDB9'] <three_months_from_now))|
((ie_df['IDB10'] >=today)&(ie_df['IDB10'] <three_months_from_now))|
((ie_df['IDB11'] >=today)&(ie_df['IDB11'] <three_months_from_now))|
((ie_df['IDB12'] >=today)&(ie_df['IDB12'] <three_months_from_now))|
((ie_df['IDB13'] >=today)&(ie_df['IDB13'] <three_months_from_now))|
((ie_df['IDB14'] >=today)&(ie_df['IDB14'] <three_months_from_now))|
((ie_df['IDB15'] >=today)&(ie_df['IDB15'] <three_months_from_now))|
((ie_df['IDB16'] >=today)&(ie_df['IDB16'] <three_months_from_now)), 'IDB_DBL_NEXT_3MONTHS_FLAG'] = 'Yes'

ie_df.loc[((ie_df['ClinPlanneddate4000'] >=today)&(ie_df['ClinPlanneddate4000'] <three_months_from_now)), 'DBL_NEXT_3MONTHS_FLAG'] = 'Yes'

ie_df.loc[((ie_df['IDB1'] >=today)&(ie_df['IDB1'] <three_months_from_now))|
((ie_df['IDB2'] >=today)&(ie_df['IDB2'] <three_months_from_now))|
((ie_df['IDB3'] >=today)&(ie_df['IDB3'] <three_months_from_now))|
((ie_df['IDB4'] >=today)&(ie_df['IDB4'] <three_months_from_now))|
((ie_df['IDB5'] >=today)&(ie_df['IDB5'] <three_months_from_now))|
((ie_df['IDB6']>=today)&(ie_df['IDB6'] <three_months_from_now))|
((ie_df['IDB7'] >=today)&(ie_df['IDB7'] <three_months_from_now))|
((ie_df['IDB8'] >=today)&(ie_df['IDB8'] <three_months_from_now))|
((ie_df['IDB9'] >=today)&(ie_df['IDB9'] <three_months_from_now))|
((ie_df['IDB10'] >=today)&(ie_df['IDB10'] <three_months_from_now))|
((ie_df['IDB11'] >=today)&(ie_df['IDB11'] <three_months_from_now))|
((ie_df['IDB12'] >=today)&(ie_df['IDB12'] <three_months_from_now))|
((ie_df['IDB13'] >=today)&(ie_df['IDB13'] <three_months_from_now))|
((ie_df['IDB14'] >=today)&(ie_df['IDB14'] <three_months_from_now))|
((ie_df['IDB15'] >=today)&(ie_df['IDB15'] <three_months_from_now))|
((ie_df['IDB16'] >=today)&(ie_df['IDB16'] <three_months_from_now)), 'IDBL_NEXT_3MONTHS_FLAG'] = 'Yes'


# COMMAND ----------

ie_df.count()

# COMMAND ----------

ie_df['plannedLPLV_plannedDBL_weeks'] = (ie_df['ClinPlanneddate4000'] - ie_df['LPLV_Planned'])
ie_df['actualLPLV_plannedDBL_weeks'] = (ie_df['ClinPlanneddate4000'] - ie_df['LPLV_Actual'])
ie_df['actualLPLV_actualDBL_weeks'] = (ie_df['ClinActualdate4000'] - ie_df['LPLV_Actual'])

ie_df['plannedLPLV_plannedDBL_weeks']=ie_df['plannedLPLV_plannedDBL_weeks']/np.timedelta64(1,'W')
ie_df['actualLPLV_plannedDBL_weeks'] =ie_df['actualLPLV_plannedDBL_weeks'] /np.timedelta64(1,'W')
ie_df['actualLPLV_actualDBL_weeks'] =ie_df['actualLPLV_actualDBL_weeks'] /np.timedelta64(1,'W')

ie_df['plannedLPLV_plannedDBL_weeks']=ie_df['plannedLPLV_plannedDBL_weeks'].round(decimals=2)
ie_df['actualLPLV_plannedDBL_weeks']=ie_df['actualLPLV_plannedDBL_weeks'].round(decimals=2)
ie_df['actualLPLV_actualDBL_weeks'] =ie_df['actualLPLV_actualDBL_weeks'].round(decimals=2)
ie_df=ie_df.iloc[:,[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,27,28,29,30,31,32,33,34,20,21,22,23,24,25,26,35,36,38,37,39,40,41]]


# COMMAND ----------

ie_df.count()

# COMMAND ----------

columns = StructType([StructField('STUDY_CD',StringType(), True),
                      StructField('IMPACT_TRIAL_STATUS',StringType(), True),
                      StructField('ORGANIZATION_UNIT',StringType(), True),
                      StructField('MANAGING_LINE_FUNCTION_NM',StringType(), True),
                      StructField('GDO_TM_SOURCING',StringType(), True),
                      StructField('GDO_MONITORING',StringType(), True),
                      StructField('GDO_DM_SOURCING',StringType(), True),
                      StructField('GDO_MW_SOURCING',StringType(), True),
                      StructField('GDO_SP_SOURCING',StringType(), True),
                      StructField('DMC_SP_SOURCING',StringType(), True),
                      StructField('SDTM_SP_SOURCING',StringType(), True),
                      StructField('GDO_TOM_SOURCING',StringType(), True),
                      StructField('GDO_SOURCING',StringType(), True),

                      StructField('FPFVPlanneddate3200',DateType(), True),
                      StructField('FPFVActualdate3200',DateType(), True),
                      StructField('ClinPlanneddate4000',DateType(), True),
                      StructField('ClinActualdate4000',DateType(), True),

                      StructField('LPLV_Planned',DateType(), True),
                      StructField('LPLV_Actual',DateType(), True),
                      StructField('IDB1',DateType(), True),
                      StructField('IDB2',DateType(), True), 
                      StructField('IDB3',DateType(), True),
                      StructField('IDB4',DateType(), True),
                      StructField('IDB5',DateType(), True),
                      StructField('IDB6',DateType(), True),
                      StructField('IDB7',DateType(), True),
                      StructField('IDB8', DateType(), True),
                      StructField('IDB9', DateType(), True),
                      StructField('IDB10',DateType(), True),
                      StructField('IDB11',DateType(), True),
                      StructField('IDB12',DateType(), True),
                      StructField('IDB13',DateType(), True),
                      StructField('IDB14',DateType(), True),
                      StructField('IDB15',DateType(), True),
                      StructField('IDB16',DateType(), True),
                      StructField('DBL_FLAG',StringType(), True), 
                      StructField('IDB_DBL_NEXT_3MONTHS_FLAG',StringType(), True), 
                      StructField('IDBL_NEXT_3MONTHS_FLAG',StringType(), True),  
                      StructField('DBL_NEXT_3MONTHS_FLAG',StringType(), True), 
                      StructField('plannedLPLV_plannedDBL_weeks',DoubleType(), True), 
                      StructField('actualLPLV_plannedDBL_weeks',DoubleType(), True), 
                      StructField('actualLPLV_actualDBL_weeks',DoubleType(), True)

                     ])
myres=spark.createDataFrame(ie_df,schema=columns)

# COMMAND ----------

myres.count()

# COMMAND ----------


event_desc=spark.sql("""select STUDY as STUDY_CD,LATEST_KEY_EVENT_DESC 
                     from tmp_GDOLT_MV_KPI_MASTER 
                     """)
                     
df_final = myres.join(event_desc , on='STUDY_CD', how='left')


# COMMAND ----------

df_final.count()

# COMMAND ----------


df_final=df_final.na.fill(value='No',subset=["IDB_DBL_NEXT_3MONTHS_FLAG","IDBL_NEXT_3MONTHS_FLAG","DBL_NEXT_3MONTHS_FLAG"])

# COMMAND ----------

df_final.count()

# COMMAND ----------

df_IS_BOW_FLAG = spark.sql("""
select distinct Trial as STUDY_CD, "Yes" as IS_BOW_FLAG from tmp_Book_of_Work_Origin_Excel
""")

df_final = df_final.join(df_IS_BOW_FLAG,["STUDY_CD"],"left")

df_final=df_final.toPandas()

# COMMAND ----------

df_final.count()

# COMMAND ----------

display(df_final)

# COMMAND ----------

dbl_idbl_data=spark.sql("""select study_code_alias as STUDY_CD,milestone_event_nm,milestone_dt as planned_milestone_dt
              from tmp_CDO_MILESTONE_RAW 
              where updated_milestone_name in ('iDBL','DBL') 
              and type='Planned' 
              and data_refresh_date in (select max(data_refresh_date) from tmp_CDO_MILESTONE_RAW)
              order by milestone_dt,study_code_alias""")
rank_data=dbl_idbl_data.toPandas()


rank_data=rank_data[rank_data['planned_milestone_dt']>today]
rank_data_pivot=rank_data.pivot_table(values='planned_milestone_dt', index='STUDY_CD', columns='milestone_event_nm', aggfunc='first').reset_index()


idb_list=['iDB 1 - Interim Database Lock 1','iDB 2 - Interim Database Lock 2','iDB 3 - Interim Database Lock 3','iDB 4 - Interim Database Lock 4','iDB 5 - Interim Database Lock 5','iDB 6 - Interim Database Lock 6','iDB 7 - Interim Database Lock 7','iDB 8 - Interim Database Lock 8','iDB 9 - Interim Database Lock 9','iDB 10 - Interim Database Lock 10','iDB 11 - Interim Database Lock 11','iDB 12 - Interim Database Lock 12','iDB 13 - Interim Database Lock 13','iDB 14 - Interim Database Lock 14','iDB 15 - Interim Database Lock 15','iDB 16 - Interim Database Lock 16']

for x in idb_list:
  if(x in rank_data_pivot.columns):
    pass
  else:
      rank_data_pivot[x]=None

rank_data_pivot.rename(columns={'iDB 1 - Interim Database Lock 1':'IDB1','iDB 2 - Interim Database Lock 2':'IDB2','iDB 3 - Interim Database Lock 3':'IDB3','iDB 4 - Interim Database Lock 4':'IDB4','iDB 5 - Interim Database Lock 5':'IDB5','iDB 6 - Interim Database Lock 6':'IDB6','iDB 7 - Interim Database Lock 7':'IDB7','iDB 8 - Interim Database Lock 8':'IDB8','iDB 9 - Interim Database Lock 9':'IDB9','iDB 10 - Interim Database Lock 10':'IDB10','iDB 11 - Interim Database Lock 11':'IDB11','iDB 12 - Interim Database Lock 12':'IDB12','iDB 13 - Interim Database Lock 13':'IDB13','iDB 14 - Interim Database Lock 14':'IDB14','iDB 15 - Interim Database Lock 15':'IDB15','iDB 16 - Interim Database Lock 16':'IDB16'},inplace=True)

rank_data_pivot['DBL - Final Clinical DB Lock']=pd.to_datetime(rank_data_pivot['DBL - Final Clinical DB Lock'])
rank_data_pivot['IDB1']=pd.to_datetime(rank_data_pivot['IDB1'])
rank_data_pivot['IDB2']=pd.to_datetime(rank_data_pivot['IDB2'])
rank_data_pivot['IDB3']=pd.to_datetime(rank_data_pivot['IDB3'])
rank_data_pivot['IDB4']=pd.to_datetime(rank_data_pivot['IDB4'])
rank_data_pivot['IDB5']=pd.to_datetime(rank_data_pivot['IDB5'])
rank_data_pivot['IDB6']=pd.to_datetime(rank_data_pivot['IDB6'])
rank_data_pivot['IDB7']=pd.to_datetime(rank_data_pivot['IDB7'])
rank_data_pivot['IDB8']=pd.to_datetime(rank_data_pivot['IDB8'])
rank_data_pivot['IDB9']=pd.to_datetime(rank_data_pivot['IDB9'])
rank_data_pivot['IDB10']=pd.to_datetime(rank_data_pivot['IDB10'])
rank_data_pivot['IDB11']=pd.to_datetime(rank_data_pivot['IDB11'])
rank_data_pivot['IDB12']=pd.to_datetime(rank_data_pivot['IDB12'])
rank_data_pivot['IDB13']=pd.to_datetime(rank_data_pivot['IDB13'])
rank_data_pivot['IDB14']=pd.to_datetime(rank_data_pivot['IDB14'])
rank_data_pivot['IDB15']=pd.to_datetime(rank_data_pivot['IDB15'])
rank_data_pivot['IDB16']=pd.to_datetime(rank_data_pivot['IDB16'])

rank_data_pivot['dbl_idbl_min_date'] = rank_data_pivot[['DBL - Final Clinical DB Lock','IDB1','IDB2','IDB3','IDB4','IDB5','IDB6','IDB7','IDB8','IDB9','IDB10','IDB11','IDB12','IDB13','IDB14','IDB15','IDB16']].min(axis=1,skipna=True)

rank_data_pivot=rank_data_pivot[['STUDY_CD','dbl_idbl_min_date']]

rank_data_pivot.sort_values(by='dbl_idbl_min_date',inplace=True)
rank_data_pivot['STUDY_RANK'] = rank_data_pivot['dbl_idbl_min_date'].rank(ascending=True)
rank_data_hor=rank_data_pivot[['STUDY_CD','STUDY_RANK']]

df_merge = df_final.merge(rank_data_hor,on='STUDY_CD',how='left')

df_merge['STUDY_RANK']=df_merge['STUDY_RANK'].fillna(100000)
df_final=df_merge

# COMMAND ----------

df_final.count()

# COMMAND ----------

today = date.today()
start = today - timedelta(days=today.weekday())

df_final['data_refresh_date']=pd.Timestamp.now() 
df_final['run_refresh_date']=start

columns = StructType([StructField('STUDY_CD',StringType(), True),
                      StructField('IMPACT_TRIAL_STATUS',StringType(), True),
                      StructField('ORGANIZATION_UNIT',StringType(), True),
                      StructField('MANAGING_LINE_FUNCTION_NM',StringType(), True),
                      StructField('GDO_TM_SOURCING',StringType(), True),
                      StructField('GDO_MONITORING',StringType(), True),
                      StructField('GDO_DM_SOURCING',StringType(), True),
                      StructField('GDO_MW_SOURCING',StringType(), True),
                      StructField('GDO_SP_SOURCING',StringType(), True),
                      StructField('DMC_SP_SOURCING',StringType(), True),
                      StructField('SDTM_SP_SOURCING',StringType(), True),
                      StructField('GDO_TOM_SOURCING',StringType(), True),
                      StructField('GDO_SOURCING',StringType(), True),

                      StructField('FPFVPlanneddate3200',DateType(), True),
                      StructField('FPFVActualdate3200',DateType(), True),
                      StructField('ClinPlanneddate4000',DateType(), True),
                      StructField('ClinActualdate4000',DateType(), True),

                      StructField('LPLV_Planned',DateType(), True),
                      StructField('LPLV_Actual',DateType(), True),
                      StructField('IDB1',DateType(), True),
                      StructField('IDB2',DateType(), True), 
                      StructField('IDB3',DateType(), True),
                      StructField('IDB4',DateType(), True),
                      StructField('IDB5',DateType(), True),
                      StructField('IDB6',DateType(), True),
                      StructField('IDB7',DateType(), True),
                      StructField('IDB8', DateType(), True),
                      StructField('IDB9', DateType(), True),
                      StructField('IDB10',DateType(), True),
                      StructField('IDB11',DateType(), True),
                      StructField('IDB12',DateType(), True),
                      StructField('IDB13',DateType(), True),
                      StructField('IDB14',DateType(), True),

                      StructField('IDB15',DateType(), True),
                      StructField('IDB16',DateType(), True),
                      StructField('DBL_FLAG',StringType(), True), 
                      StructField('IDB_DBL_NEXT_3MONTHS_FLAG',StringType(), True), 
                      StructField('IDBL_NEXT_3MONTHS_FLAG',StringType(), True),  
                      StructField('DBL_NEXT_3MONTHS_FLAG',StringType(), True), 
                      StructField('plannedLPLV_plannedDBL_weeks',DoubleType(), True), 
                      StructField('actualLPLV_plannedDBL_weeks',DoubleType(), True), 
                      StructField('actualLPLV_actualDBL_weeks',DoubleType(), True),

                      #StructField('DO_MANAGED_FLAG',StringType(), True),
                      StructField('LATEST_KEY_EVENT_DESC',StringType(), True),
                      StructField('IS_BOW_FLAG',StringType(), True),
                      StructField('STUDY_RANK',DoubleType(), True),
                      StructField('data_refresh_date',TimestampType(), True),
                      StructField('run_refresh_date',DateType(), True)

                     ])
final_ie_data=spark.createDataFrame(df_final,schema=columns)


# COMMAND ----------

secrets = rds_db_screts('CA_TMOMETER')
write_df_into_rds(final_ie_data,'CDO_IE_TRIALS_HORIZON_060923','append',secrets)

# COMMAND ----------

# MAGIC %md
# MAGIC ### CDO_CRF_VERIFIED

# COMMAND ----------

crf_verified=spark.sql("""select project as study_code_alias,countryname as country_code,count(*) as pending_verification_count
 from dial_raveops_landing.raveops_page_status where verified=0 and audit_updated_tmstmp in (select max(audit_updated_tmstmp) from dial_raveops_landing.raveops_page_status) group by project,countryname""")
crf_verified=crf_verified.toPandas()


# COMMAND ----------

crf_verified['data_refresh_date']=pd.Timestamp.now() 
today = date.today()

start = today - timedelta(days=today.weekday())
crf_verified['run_refresh_date']=start
crf_verified['pending_verification_count']=crf_verified['pending_verification_count'].fillna(0)
columns = StructType([StructField('study_code_alias',StringType(), True),
                      StructField('country_code',StringType(), True),
                      StructField('pending_verification_count',IntegerType(), True),
                      StructField('data_refresh_date',TimestampType(), True),
                      StructField('run_refresh_date',DateType(), True)                                
                     ])
myres=spark.createDataFrame(crf_verified,schema=columns)


# COMMAND ----------

secrets = rds_db_screts('CA_TMOMETER')
write_df_into_rds(myres,' CDO_CRF_VERIFIED','append',secrets)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Integration  - CDO_STUDY_COUNTRY_METRICS

# COMMAND ----------

rds_table_read('CDO_Visit_Projection_Tracker_Count','CA_TMOMETER')
rds_table_read('CDO_Missing_Page_Count','CA_TMOMETER')
rds_table_read('CDO_Lab_Reports_Count','CA_TMOMETER')

rds_table_read('CDO_OPEN_QUERIES_RAVE_COUNT','CA_TMOMETER')
rds_table_read('CDO_MISSING_PI_SIGN_RAVE_COUNT','CA_TMOMETER')
rds_table_read('CDO_SIGNED_PI_SIGN_RAVE_COUNT','CA_TMOMETER')
rds_table_read('CDO_TOTAL_PAGES_ENTERED_COUNT','CA_TMOMETER')
rds_table_read('CDO_CRF_VERIFIED','CA_TMOMETER')
rds_table_read('ESB_V_STUDY_COUNTRY','CAFMART')

# COMMAND ----------

projection=spark.sql("""select * from 
  tmp_CDO_Visit_Projection_Tracker_Count where
DATE(data_refresh_date) in ( select max(DATE(data_refresh_date))from tmp_CDO_Visit_Projection_Tracker_Count
 group by run_refresh_date)""")
missing_page=spark.sql("""select * from tmp_CDO_Missing_Page_Count where
DATE(data_refresh_date) in ( select max(DATE(data_refresh_date))from tmp_CDO_Missing_Page_Count
 group by run_refresh_date)""")
lab_report=spark.sql("""select * from tmp_CDO_Lab_Reports_Count where
DATE(data_refresh_date) in ( select max(DATE(data_refresh_date))from tmp_CDO_Lab_Reports_Count
 group by run_refresh_date)""")

open_queries=spark.sql("""select * from tmp_CDO_OPEN_QUERIES_RAVE_COUNT where
DATE(data_refresh_date) in ( select max(DATE(data_refresh_date))from tmp_CDO_OPEN_QUERIES_RAVE_COUNT
 group by run_refresh_date)""")
missing_pi=spark.sql("""select * from tmp_CDO_MISSING_PI_SIGN_RAVE_COUNT where
DATE(data_refresh_date) in ( select max(DATE(data_refresh_date))from tmp_CDO_MISSING_PI_SIGN_RAVE_COUNT
 group by run_refresh_date)""")
signed_pi=spark.sql("""select * from tmp_CDO_SIGNED_PI_SIGN_RAVE_COUNT where
DATE(data_refresh_date) in ( select max(DATE(data_refresh_date))from tmp_CDO_SIGNED_PI_SIGN_RAVE_COUNT
 group by run_refresh_date)""")
pages=spark.sql("""select * from tmp_CDO_TOTAL_PAGES_ENTERED_COUNT where
DATE(data_refresh_date) in ( select max(DATE(data_refresh_date))from tmp_CDO_TOTAL_PAGES_ENTERED_COUNT
 group by run_refresh_date)""")
crf=spark.sql("""select * from tmp_CDO_CRF_VERIFIED where
DATE(data_refresh_date) in ( select max(DATE(data_refresh_date))from tmp_CDO_CRF_VERIFIED
 group by run_refresh_date)""") 

# COMMAND ----------

projection=projection.toPandas()
missing_page=missing_page.toPandas()
lab_report=lab_report.toPandas()

open_queries=open_queries.toPandas()
missing_pi=missing_pi.toPandas()
signed_pi=signed_pi.toPandas()
pages=pages.toPandas()
crf=crf.toPandas()

projection['run_refresh_date']=projection['run_refresh_date'].dt.date
missing_page['run_refresh_date']=missing_page['run_refresh_date'].dt.date
lab_report['run_refresh_date']=lab_report['run_refresh_date'].dt.date


projection['data_refresh_date']=projection['data_refresh_date'].dt.date
missing_page['data_refresh_date']=missing_page['data_refresh_date'].dt.date
lab_report['data_refresh_date']=lab_report['data_refresh_date'].dt.date

open_queries['data_refresh_date']=open_queries['data_refresh_date'].dt.date
missing_pi['data_refresh_date']=missing_pi['data_refresh_date'].dt.date
signed_pi['data_refresh_date']=signed_pi['data_refresh_date'].dt.date
pages['data_refresh_date']=pages['data_refresh_date'].dt.date
crf['data_refresh_date']=crf['data_refresh_date'].dt.date

#study_country_level
projection.rename(columns={'Study_Code_alias':'study_code_alias','Country_Code':'country_code'},inplace=True)
missing_page.rename(columns={'Study_Code_alias':'study_code_alias','Country_Code':'country_code'},inplace=True)
lab_report.rename(columns={'Study_Code_alias':'study_code_alias','Country_Code':'country_code'},inplace=True)

# COMMAND ----------

combi=pd.concat([open_queries.loc[:,['study_code_alias','country_code','data_refresh_date','run_refresh_date',]],missing_pi.loc[:,['study_code_alias','country_code','data_refresh_date','run_refresh_date']],signed_pi.loc[:,['study_code_alias','country_code','data_refresh_date','run_refresh_date']],pages.loc[:,['study_code_alias','country_code','data_refresh_date','run_refresh_date']],crf.loc[:,['study_code_alias','country_code','data_refresh_date','run_refresh_date']],projection.loc[:,['study_code_alias','country_code','data_refresh_date','run_refresh_date']],missing_page.loc[:,['study_code_alias','country_code','data_refresh_date','run_refresh_date']],lab_report.loc[:,['study_code_alias','country_code','data_refresh_date','run_refresh_date']]])

dataset1=combi.drop_duplicates(keep='first')
dataset1=dataset1.sort_values(by=['study_code_alias','country_code','run_refresh_date','data_refresh_date'])

# COMMAND ----------

data_1 = pd.merge(dataset1,open_queries , on=['study_code_alias','country_code','data_refresh_date','run_refresh_date',], how='left')
data1=data_1.loc[:,['study_code_alias','country_code','open_query_count','data_refresh_date','run_refresh_date']]
data_2 = pd.merge(data1,missing_pi , on=['study_code_alias','country_code','data_refresh_date','run_refresh_date'], how='left')
data_2=data_2.loc[:,['study_code_alias','country_code','open_query_count','missing_PI_count','data_refresh_date','run_refresh_date']]
data_3 = pd.merge(data_2,signed_pi , on=['study_code_alias','country_code','data_refresh_date','run_refresh_date'], how='left')

data_3=data_3.loc[:,['study_code_alias','country_code','open_query_count','missing_PI_count','total_signed_count','data_refresh_date','run_refresh_date']]
data_4 = pd.merge(data_3,pages, on=['study_code_alias','country_code','data_refresh_date','run_refresh_date'], how='left')

data_4=data_4.loc[:,['study_code_alias','country_code','open_query_count','missing_PI_count','total_signed_count','total_pages_entered','data_refresh_date','run_refresh_date']]

data_5 = pd.merge(data_4,crf, on=['study_code_alias','country_code','data_refresh_date','run_refresh_date'], how='left')

data_5=data_5.loc[:,['study_code_alias','country_code','open_query_count','missing_PI_count','total_signed_count','total_pages_entered','pending_verification_count','data_refresh_date','run_refresh_date']]

data_6 = pd.merge(data_5,projection, on=['study_code_alias','country_code','data_refresh_date','run_refresh_date'], how='left')
data_6=data_6.loc[:,['study_code_alias','country_code','open_query_count','missing_PI_count','total_signed_count','total_pages_entered','pending_verification_count','Missing_Visits_Count','data_refresh_date','run_refresh_date']]

data_7 = pd.merge(data_6,missing_page, on=['study_code_alias','country_code','data_refresh_date','run_refresh_date'], how='left')
data_7=data_7.loc[:,['study_code_alias','country_code','open_query_count','missing_PI_count','total_signed_count','total_pages_entered','pending_verification_count','Missing_Visits_Count','Missing_Pages_Count','data_refresh_date','run_refresh_date']]

integrated_data= pd.merge(data_7,lab_report, on=['study_code_alias','country_code','data_refresh_date','run_refresh_date'], how='left')
integrated_data=integrated_data.loc[:,['study_code_alias','country_code','open_query_count','missing_PI_count','total_signed_count','total_pages_entered','pending_verification_count','Missing_Visits_Count','Missing_Pages_Count','Lab_Reports_Count','data_refresh_date','run_refresh_date']]


# COMMAND ----------

country_data=spark.sql("""select DISTINCT COUNTRY_CODE as country_code,COUNTRY_DESC as country from tmp_ESB_V_STUDY_COUNTRY """)
#display(country_data)
country_data=country_data.toPandas()
integrated_data= pd.merge(integrated_data,country_data, on=['country_code'], how='left')

# COMMAND ----------

tmp_RegionCountryMapping = rds_table_read('RegionCountryMapping','CAFMART')

# COMMAND ----------

region=spark.sql("""select * from tmp_RegionCountryMapping""")

region=region.toPandas()
region.rename(columns={'COUNTRY_CODE':'country_code','COUNTRY':'country','REGION':'region','Cluster_':'cluster','Sub_Cluster':'sub_cluster'},inplace=True)

integrated_data= pd.merge(integrated_data,region, on=['country_code'], how='left')
integrated_data.rename(columns={'Missing_Visits_Count':'missing_visits_count','Missing_Pages_Count':'missing_pages_count','Lab_Reports_Count':'lab_reports_count','country_x':'country'},inplace=True)
integrated_data=integrated_data.iloc[:,[0,1,12,13,14,15,2,3,4,5,6,7,8,9,10,11]] 

#integrated_data.country.fillna(integrated_data.country_code, inplace=True)
integrated_data.region.fillna('Not Mapped', inplace=True)
integrated_data.country.fillna('Not Mapped', inplace=True)
integrated_data.cluster.fillna('Not Mapped', inplace=True)
integrated_data.sub_cluster.fillna('Not Mapped', inplace=True)
integrated_data=integrated_data.fillna(0)

# COMMAND ----------

#Code to fetch country names where country names is null in CountryRegionMapping file
final_data=integrated_data
null_country_name=integrated_data[integrated_data['country'].isnull()]
null_country_name=null_country_name.loc[:,['country_code']].drop_duplicates()

counrty_name_mapping=spark.sql("""select distinct country_code,country_desc as
                                country from clinical_operations_unified.study_country  """)
country_df=counrty_name_mapping.toPandas()


mapping_for_nulls=null_country_name.merge(country_df,on='country_code',how='left')

final_data = final_data.merge(mapping_for_nulls,on='country_code',how="left")


final_data['country_x'] = final_data['country_x'].fillna(final_data['country_y'])

final_data.drop(["country_y"],inplace=True,axis=1)
final_data.rename(columns={'country_x':'country'},inplace=True)

# COMMAND ----------

spark.conf.set("spark.sql.execution.arrow.enabled", "true")

# COMMAND ----------

final_data['table_refresh_date']=pd.Timestamp.now() 
columns = StructType([StructField('study_code_alias',StringType(), True),
                      StructField('country_code',StringType(), True),
                      StructField('country',StringType(), True),
                      StructField('region',StringType(), True),
                      StructField('cluster',StringType(), True),
                      StructField('sub_cluster',StringType(), True),
                      StructField('open_query_count',DoubleType(), True),
                      StructField('missing_PI_count',DoubleType(), True),
                      StructField('total_signed_count',DoubleType(), True),
                      StructField('total_pages_entered',DoubleType(), True),
                      StructField('pending_verification_count',DoubleType(), True),
                      StructField('missing_visits_count',DoubleType(), True),
                      StructField('missing_pages_count',DoubleType(), True),
                      StructField('lab_reports_count',DoubleType(), True),
                      StructField('data_refresh_date',DateType(), True),
                      StructField('run_refresh_date',DateType(), True), 
                      StructField('table_refresh_date',DateType(), True)                                
                     ])
final_data=spark.createDataFrame(final_data,schema=columns)
# final_data.count()

# COMMAND ----------

secrets = rds_db_screts('CA_TMOMETER')
write_df_into_rds(final_data,'CDO_STUDY_COUNTRY_METRICS_V2','overwrite',secrets)

# COMMAND ----------

# MAGIC %md
# MAGIC ### CDO_STUDY_METRICS

# COMMAND ----------

rds_table_read('CDO_Open_IDRR_Issues_Count','CA_TMOMETER')

# COMMAND ----------



idrr=spark.sql("""select * from tmp_CDO_Open_IDRR_Issues_Count where
DATE(data_refresh_date) in ( select max(DATE(data_refresh_date))from tmp_CDO_Open_IDRR_Issues_Count
 group by run_refresh_date)""")
 
idrr=idrr.toPandas()
idrr['run_refresh_date']=idrr['run_refresh_date'].dt.date

idrr.rename(columns={'Study_Code_alias':'study_code_alias'},inplace=True)
idrr['table_refresh_date']=pd.Timestamp.now() 
idrr=idrr.loc[:,['study_code_alias','number_of_open_issues','data_refresh_date','run_refresh_date','table_refresh_date']]
columns = StructType([StructField('study_code_alias',StringType(), True),
                      StructField('number_of_open_issues',DoubleType(), True),
                      StructField('data_refresh_date',TimestampType(), True),
                      StructField('run_refresh_date',DateType(), True),
                      StructField('table_refresh_date',DateType(), True)                                
                     ])
idrr=spark.createDataFrame(idrr,schema=columns)


# COMMAND ----------

secrets = rds_db_screts('CA_TMOMETER')
write_df_into_rds(idrr,'CDO_STUDY_METRICS','append',secrets)

# COMMAND ----------

# MAGIC %md
# MAGIC ### CDO_IDC_IDB_WEEKS

# COMMAND ----------

rds_table_read('CDO_MILESTONE_RAW_IE_VW_V2','CA_TMOMETER')

# COMMAND ----------

from pyspark.sql.functions import substring,col

# COMMAND ----------

df_planned_idc =spark.sql("""
select study_code_alias, milestone_event_nm, milestone_dt as pIDC
from tmp_CDO_MILESTONE_RAW_IE_VW_V2
where type  = "Planned"
and updated_milestone_name IN ("Data cut off(IDC)")
""")

df_actual_idc = spark.sql("""
select study_code_alias, milestone_event_nm,milestone_dt as aIDC
from tmp_CDO_MILESTONE_RAW_IE_VW_V2
where type = "Actuals"
and updated_milestone_name IN ("Data cut off(IDC)")
""")

df_idc = df_actual_idc.join(df_planned_idc,on = ["study_code_alias","milestone_event_nm"],how = "full")

df_idc = df_idc.withColumn("milestone_event_num", substring(col("milestone_event_nm"), -2, 2))

# COMMAND ----------

df_planned_idb = spark.sql("""
select study_code_alias, milestone_event_nm, milestone_dt as pIDBL
from tmp_CDO_MILESTONE_RAW_IE_VW_V2
where `type` = "Planned"
and updated_milestone_name IN ("iDBL")
""")

df_actual_idb = spark.sql("""
select study_code_alias, milestone_event_nm, milestone_dt as aIDBL
from tmp_CDO_MILESTONE_RAW_IE_VW_V2
where `type` = "Actuals"
and updated_milestone_name IN ("iDBL")
""")

df_idb = df_actual_idb.join(df_planned_idb,on = ["study_code_alias","milestone_event_nm"],how = "full")

df_idb = df_idb.withColumn("milestone_event_num", substring(col("milestone_event_nm"), -2, 2))

# COMMAND ----------

df = df_idc.join(df_idb,on = ["study_code_alias","milestone_event_num"],how = "inner")

df = df.select("study_code_alias","milestone_event_num","aIDC","pIDC","aIDBL","pIDBL")

df.createOrReplaceTempView("df_tbl")

df_vw = df
df_vw= df_vw.withColumn('pIDC to pIDBL(weeks)', datediff('pIDBL','pIDC')/7)

df_vw = df_vw.withColumn('aIDC to pIDBL(weeks)', datediff('pIDBL','aIDC')/7)

df_vw = df_vw.withColumn('aIDC to aIDBL(weeks)', datediff('aIDBL','aIDC')/7)

df_vw = df_vw.withColumn('Flag', F.when(col('aIDC').isNull() | col('pIDC').isNull() | col('aIDBL').isNull() | col('pIDBL').isNull(), 'No').otherwise('Yes'))

df_vw.createOrReplaceTempView("df_vw")

# COMMAND ----------

df_vw=df_vw.withColumn('pIDC to pIDBL(weeks)', F.when(col('pIDC to pIDBL(weeks)') < 0,None).otherwise(F.col('pIDC to pIDBL(weeks)')))
df_vw=df_vw.withColumn('aIDC to pIDBL(weeks)', F.when(col('aIDC to pIDBL(weeks)') < 0,None).otherwise(F.col('aIDC to pIDBL(weeks)')))
df_vw=df_vw.withColumn('aIDC to aIDBL(weeks)', F.when(col('aIDC to aIDBL(weeks)') < 0,None).otherwise(F.col('aIDC to aIDBL(weeks)')))

# COMMAND ----------

df_vw.createOrReplaceTempView("df_vw")
df_vw = df_vw.filter(col("Flag") == "Yes")
df_vw.createOrReplaceTempView("adhoc_df")
df_vw1 = df_vw.groupBy("study_code_alias") \
      .agg(percentile_approx("pIDC to pIDBL(weeks)",0.5).alias("pIDC to pIDBL(weeks Median)"), \
           percentile_approx("aIDC to pIDBL(weeks)",0.5).alias("aIDC to pIDBL(weeks Median)"), \
                percentile_approx("aIDC to aIDBL(weeks)",0.5).alias("aIDC to aIDBL(weeks Median)"))

# COMMAND ----------

df_pandas=df_vw1.toPandas()
df_pandas['data_refresh_date']=pd.Timestamp.now() 
today = date.today()
start = today - timedelta(days=today.weekday())
df_pandas['run_refresh_date']=start

columns = StructType([StructField('study_code_alias',StringType(), True),
                      StructField('pIDC to pIDBL(weeks Median)',DoubleType(), True),
                      StructField('aIDC to pIDBL(weeks Median)',DoubleType(), True),
                      StructField('aIDC to aIDBL(weeks Median)',DoubleType(), True),
                      StructField('data_refresh_date',TimestampType(), True),
                      StructField('run_refresh_date',DateType(), True)                                
                     ])
myres=spark.createDataFrame(df_pandas,schema=columns)

# COMMAND ----------

secrets = rds_db_screts('CA_TMOMETER')
write_df_into_rds(myres,'CDO_IDC_IDB_WEEKS','append',secrets)

# COMMAND ----------

# MAGIC %md
# MAGIC ### CDO_STUDY_COUNTRY_ADHOC_METRICS_V2

# COMMAND ----------

rds_table_read('CDO_Visit_Projection_Tracker_Count','CA_TMOMETER')
rds_table_read('CDO_Missing_Page_Count','CA_TMOMETER')
rds_table_read('CDO_Lab_Reports_Count','CA_TMOMETER')
rds_table_read('RegionCountryMapping','CAFMART')

# COMMAND ----------

projection=spark.sql("""select * from 
  tmp_CDO_Visit_Projection_Tracker_Count where
DATE(data_refresh_date) in ( select max(DATE(data_refresh_date))from tmp_CDO_Visit_Projection_Tracker_Count
 group by run_refresh_date)""")
missing_page=spark.sql("""select * from tmp_CDO_Missing_Page_Count where
DATE(data_refresh_date) in ( select max(DATE(data_refresh_date))from tmp_CDO_Missing_Page_Count
 group by run_refresh_date)""")
lab_report=spark.sql("""select * from tmp_CDO_Lab_Reports_Count where
DATE(data_refresh_date) in ( select max(DATE(data_refresh_date))from tmp_CDO_Lab_Reports_Count
 group by run_refresh_date)""")


projection=projection.toPandas()
missing_page=missing_page.toPandas()
lab_report=lab_report.toPandas()

# COMMAND ----------


projection['run_refresh_date']=projection['run_refresh_date'].dt.date
missing_page['run_refresh_date']=missing_page['run_refresh_date'].dt.date
lab_report['run_refresh_date']=lab_report['run_refresh_date'].dt.date

projection['data_refresh_date']=projection['data_refresh_date'].dt.date
missing_page['data_refresh_date']=missing_page['data_refresh_date'].dt.date
lab_report['data_refresh_date']=lab_report['data_refresh_date'].dt.date


projection.rename(columns={'Study_Code_alias':'study_code_alias','Country_Code':'country_code'},inplace=True)
missing_page.rename(columns={'Study_Code_alias':'study_code_alias','Country_Code':'country_code'},inplace=True)
lab_report.rename(columns={'Study_Code_alias':'study_code_alias','Country_Code':'country_code'},inplace=True)


# COMMAND ----------

combi=pd.concat([projection.loc[:,['study_code_alias','country_code','data_refresh_date','run_refresh_date']],missing_page.loc[:,['study_code_alias','country_code','data_refresh_date','run_refresh_date']],lab_report.loc[:,['study_code_alias','country_code','data_refresh_date','run_refresh_date']]])


data_5=combi.drop_duplicates(keep='first')
data_5=data_5.sort_values(by=['study_code_alias','country_code','run_refresh_date','data_refresh_date'])

# COMMAND ----------

data_6 = pd.merge(data_5,projection, on=['study_code_alias','country_code','data_refresh_date','run_refresh_date'], how='left')

data_6=data_6.loc[:,['study_code_alias','country_code','Missing_Visits_Count','data_refresh_date','run_refresh_date']]


data_7 = pd.merge(data_6,missing_page, on=['study_code_alias','country_code','data_refresh_date','run_refresh_date'], how='left')
data_7=data_7.loc[:,['study_code_alias','country_code','Missing_Visits_Count','Missing_Pages_Count','data_refresh_date','run_refresh_date']]


integrated_data= pd.merge(data_7,lab_report, on=['study_code_alias','country_code','data_refresh_date','run_refresh_date'], how='left')
integrated_data=integrated_data.loc[:,['study_code_alias','country_code','Missing_Visits_Count','Missing_Pages_Count','Lab_Reports_Count','data_refresh_date','run_refresh_date']]


# COMMAND ----------

integrated_data['table_refresh_date']=pd.Timestamp.now() 
columns = StructType([StructField('study_code_alias',StringType(), True),
                      StructField('country_code',StringType(), True),
                      StructField('missing_visits_count',IntegerType(), True),
                      StructField('missing_pages_count',IntegerType(), True),
                      StructField('lab_reports_count',IntegerType(), True),
                      StructField('data_refresh_date',DateType(), True),
                      StructField('run_refresh_date',DateType(), True), 
                      StructField('table_refresh_date',DateType(), True)                                
                     ])
ADHOC_METRICS_V2=spark.createDataFrame(integrated_data,schema=columns)


# COMMAND ----------

secrets = rds_db_screts('CA_TMOMETER')
write_df_into_rds(ADHOC_METRICS_V2,'CDO_STUDY_COUNTRY_ADHOC_METRICS_V2','overwrite',secrets)