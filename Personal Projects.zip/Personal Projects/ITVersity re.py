# Databricks notebook source
# MAGIC %md
# MAGIC ##Interview

# COMMAND ----------

# MAGIC %md
# MAGIC Why Pickle and UnPickle?
# MAGIC
# MAGIC The pickle module is used for implementing binary protocols for serializing and de-serializing a Python object structure. 

# COMMAND ----------

import pickle 
# import unpickle

data =  { 
         'a':'A', 
         'b':2, 
         'c':3.0 
        } 
data_string = pickle.dumps(data) 
print ('PICKLE:', data_string )


# COMMAND ----------

print("The version of Spark Context in the PySpark shell is", sc.version)
print("The Python version of Spark Context in the PySpark shell is", sc.pythonVer)
print("The master of Spark Context in the PySpark shell is", sc.master)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Broadcast

# COMMAND ----------


b = sc.broadcast([1, 2, 3, 4, 5])
b.value


# COMMAND ----------

sc.parallelize([0, 0]).flatMap(lambda x: b.value).collect()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Range

# COMMAND ----------

from pyspark.sql.functions import col, rand

# COMMAND ----------

df= spark.range(1,10,1,10).select(col("id").alias("PK"),rand(10).alias("Attributes"))
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #re.findall
# MAGIC The findall() function returns a list containing all matches.

# COMMAND ----------

import re

# COMMAND ----------

string = 'hello 12 hi 89. .Howdy.. 34 12'
pattern = '12'

# COMMAND ----------

var = re.findall(pattern,string)
print(var)

# COMMAND ----------

help(re.findall)

# COMMAND ----------

string = 'hello 12 hi 89. .Howdy.. 34 12'
pattern = '[18]'
var = re.findall(pattern,string)
# var = re.findall(string,pattern)
print(var)

# COMMAND ----------

string = 'hello 12  hi 89. .Howdy.. 34 12'
pattern = '[h1239]'
result = re.findall(pattern, string)
print(result)

# COMMAND ----------

string = 'hello 12 9621 hi 89. .Howdy.. 34 12'
pattern = '[12569h]+'
result = re.findall(pattern, string)
print(result)
print("Count of the pattern {} into string is : " + str(len(result)))

# COMMAND ----------


# string = 'hello 12 hi 89. .Howdy.. 34 12'
string = 'Hellow 12 hi 12'
pattern = '[12]?'
result = re.findall(pattern, string)
print(result)
print("Count of the pattern {} into string is : " + str(len(result)))
print(str(len(string)))


# COMMAND ----------

string = 'hello 12 hi 89. .Howdy.. 34 12'
pattern = '[12]'
result = re.findall(pattern, string)
print(result)
print("Count of the pattern {} into string is : " + str(len(result)))



# COMMAND ----------

string = 'hello 12 hi 89. .Howdy.. 34 12'
pattern = '[0-9]'
result = re.findall(pattern, string)
print(result)

# COMMAND ----------


string = 'hello 12 hi 89. .Howdy.. 34 12'
pattern = '[0-9]+'
result = re.findall(pattern, string)
print(result)

# COMMAND ----------

string = 'hello 12 hi 89. .Howdy.. 34 12'
pattern = '\d+'
result = re.findall(pattern, string)
print(result)

# COMMAND ----------

# MAGIC %md
# MAGIC #re.search
# MAGIC The search() function searches the string for a match, and returns a Match object if there is a match.
# MAGIC
# MAGIC If there is more than one match, only the first occurrence of the match will be returned:

# COMMAND ----------

help(re.search)

# COMMAND ----------

txt = "The rain in Spain"
pattern = "in"
# pattern = '\s'
# pattern = 'Port'

result = re.search(pattern,txt)
print(result.start())
print(result)


# COMMAND ----------

string = "Python is fun"

# check if 'Python' is at the beginning
match = re.search('\APython', string)

if match:
  print("pattern found inside the string")
else:
  print("pattern not found")  

# COMMAND ----------

import re     

regex = "([A-Za-z]+) (\d+)"     
match = re.search(regex, "Day and Date of Today is Tuesday 12")       
if match != None:   
    print ("The String match at index % s, % s" % (match.start(), match.end()))  
    print ("Full match of Pattern: % s" % (match.group(0)))      
    print ("The Weekday of Today is: % s" % (match.group(1)))      
    print ("The Date of Today is: % s" % (match.group(2)))     
else:   
    print ("The pattern of Python regex does not match with the string of Data imported.")  

# COMMAND ----------

import re     

str1 = "Day and Date of Today is Tuesday 12"
regex = "([A-Za-z]+) ([0-9]+)"     

match = re.search(regex, str1)       
if match != None:   
    print ("The String match at index % s, % s" % (match.start(), match.end()))  
    print ("Full match of Pattern: % s" % (match.group(0)))      
    print ("The Weekday of Today is: % s" % (match.group(1)))      
    print ("The Date of Today is: % s" % (match.group(2)))     
else:   
    print ("The pattern of Python regex does not match with the string of Data imported.")  

# COMMAND ----------

# MAGIC %md
# MAGIC #re.split
# MAGIC The split() function returns a list where the string has been split at each match:
# MAGIC

# COMMAND ----------

txt = "The rain is in the Spain"
pattern = "\s"
result = re.split(pattern,txt)
print(result)


pattern = "in"
result = re.split(pattern,txt,2)
print(result)

# COMMAND ----------

string = 'Twelve:12 Eighty nine:89.'
pattern = '\d+'

result = re.split(pattern, string) 
print(result)

# Output: ['Twelve:', ' Eighty nine:', '.']


# COMMAND ----------

# MAGIC %md
# MAGIC #re.sub
# MAGIC The sub() function REPLACES the matches with the text of your choice:
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC \A	Returns a match if the specified characters are at the beginning of the string	"\AThe"	
# MAGIC
# MAGIC \b	Returns a match where the specified characters are at the beginning or at the end of a word
# MAGIC (the "r" in the beginning is making sure that the string is being treated as a "raw string")	r"\bain"
# MAGIC r"ain\b"

# COMMAND ----------

txt = "The rain in Spain"

pattern = "IN"

result = re.sub("in",pattern, txt, 2)
print(result)

# COMMAND ----------

string ="93 NORTH 9TH STREET, BROOKLYN NY 19219 "
# result = re.sub("9","nine", string, 2)
# result = re.sub("9","nine", string)
# result = re.sub("\d","", string,3)
result = re.sub("\d","", string,3)
print(result)


# COMMAND ----------


# Program to remove all whitespaces

string = 'abc 12\
de 23 \n f45 6\
sandeep \t \n \r \f gutte'

pattern = '\s+'
replace = ''
occurances = 2

new_string = re.sub(pattern, replace, string,occurances) 
print(new_string)

# Output: abc12de23f456


# COMMAND ----------


string = 'abc 12\
de 23 \n f45 6'

pattern = '\s+'
replace = ''

# new_string = re.sub(r'\s+', replace, string, 1) 
new_string = re.sub(pattern, replace, string, 1) 
print(new_string)

# COMMAND ----------


# string = 'abc 12\
# de 23 \n true f45 6'

string = "sandeep she sha rao gutte"

pattern = '\s+'
replace = ''

new_string = re.subn(pattern, replace, string) 
print(new_string)

# COMMAND ----------

import re
new_string = re.sub(r"apple", "orange", string, 1)
print(new_string)

# COMMAND ----------

# MAGIC %md
# MAGIC #Matching Pattern

# COMMAND ----------

txt = "The rain in Spain"
# printing the indexes - (tuples)
x = re.search(r'\bS\w+', txt)
print(x.span())


# COMMAND ----------


# printing the string
txt = "The rain in Spain"
x = re.search(r"\bS\w+", txt)
print(x.string)

# COMMAND ----------

# printing the part of string
txt = "The rain in Spain"
x = re.search(r"\bS\w+", txt)
print(x.group())

# COMMAND ----------

string = '39801 356, 2102 1111'

# Three digit number followed by space followed by two digit number
pattern = '(\d{3}) (\d{2})'

# match variable contains a Match object.
match = re.search(pattern, string)

if match:
  print(match.group())
else:
  print("pattern not found")

# Output: 801 35


# COMMAND ----------

string = '\n and \r are escape sequences.'

result = re.findall(r'[\n\r]', string) 
print(result)

# COMMAND ----------

def calculator(a,b):
  return b+a,b-a,b*a,b/a

print(swap(5,9))

# COMMAND ----------

def swap(a,b):
  return b,a

print(swap(5,9))

# COMMAND ----------

# MAGIC %md
# MAGIC #List Comprehension

# COMMAND ----------

# MAGIC %md
# MAGIC 18. Can you explain any other uses of list comprehension apart from creating new lists?
# MAGIC
# MAGIC List comprehension can be used to perform operations on lists, such as filtering out certain elements or applying a function to every element in a list. It can also be used to create new lists from existing lists, as you mentioned.
# MAGIC
# MAGIC List comprehension is generally considered more efficient than regular for/while loops because it allows you to condense your code down into a single line. This can make your code more readable and easier to debug. Additionally, list comprehension can often run faster than regular for/while loops because it is written in C, which is a compiled language.

# COMMAND ----------

import numpy as np

lst1 = [[1,2,5],[3,4,6],[7,8,9]]
print(type(lst1))

np_lst1 = np.array(lst1)
print(type(np_lst1))
print(np_lst1)


np_lst1_f = np_lst1.flatten()

print(np_lst1_f)

# COMMAND ----------

lst=[]
for i in range(1,51):
    if i%5 == 0:
        lst.append(i)

print(lst)

lst1 = list()
lst1 = [i for i in range(1,51) if i%5 == 0]

print(lst1)

# COMMAND ----------

lst = [1,2,3,4,5,6]

lst1 = map(lambda x: x**2, lst)

print(lst1)


numbers = [1, 2, 3, 4, 5]

squared_numbers = map(lambda x: x**2, numbers)

print(type(squared_numbers))
print(squared_numbers)


for i in squared_numbers:
  print(i)


# COMMAND ----------

# MAGIC %md
# MAGIC #Iterator & Generator
# MAGIC object that allows you to iterate through a data structure, such as a list.
# MAGIC
# MAGIC A generator is a function that returns an object (iterator) which we can iterate over (one value at a time), such as yield

# COMMAND ----------

# MAGIC %md
# MAGIC  Is it possible to use generators instead of map() when writing list comprehensions? If yes, then how?

# COMMAND ----------


a = [5,6,7,8]

def square(a):
  for i in a:
    yield i*i

x = square(a)

print(type(x))


for i in x:
  print(i)



# COMMAND ----------

lst = [x for x in range(1,50)]

print(lst)

# Generators/ class map - need to iterate by for loop
# Iterators you can directly print

# COMMAND ----------

lst = [i**2 for i in range(10) if i % 2 == 0]

print(lst)

# COMMAND ----------

 lst = [x for x in range(101) if x%2==0] 
 print(lst)
 
 lst1 = [x for x in range(0, 101, 2)]
 print(lst1)

# COMMAND ----------

# Tuple creation 
lst1 =[]

for i in range(1,10):
  for j in range(1,10):
    x = [i,j]
    lst1.append(x)

print(lst1)


# COMMAND ----------


lst = [[a, b] for a in range(1, 10) for b in range(1, 10)]
print(lst)

lst = [(a, b) for a in range(1, 10) for b in range(1, 10)]
print(lst)

# COMMAND ----------

  print([i*j for i in range(1, 5) for j in range(1, 4)])
      
  # [1 2 3 1 4 6 3 6 9 4 8 12]
      # 1 1 2 3 1 2 3 1 4 6 3 6 9 4 8 12
      # 2 1 2 3
      # 3 1 2 3
      # 4 1 2 3 

# COMMAND ----------

lst = []
for i in range(1, 5):
  for j in range(1, 4):
    lst.append(i*j)
    # print(i*j)

print(lst)

# COMMAND ----------

if 'E' in [x for x in 'ABCDE']:
  print("The string starts with A")
else:
  print("The string does not start with A")


# COMMAND ----------

sentence = "this is a sentence"

vowels = ['a', 'e', 'i', 'o', 'u']

sentence_without_vowels = [letter for letter in sentence if letter not in vowels]
print(sentence_without_vowels)
print(''.join(sentence_without_vowels))

# COMMAND ----------

sentence = "this is a sentenced"
vowels = ['a','e','i','o','u']

lst = []

# string is immutable object - Everytime it replaces the values- Hence prefer lists

for c in sentence:
  if c not in vowels:
    lst.append(c)
    # string = ''.join(c) 
    # string = ''+c 
    # print(c)

print(lst)

string = ''.join(lst)
print(string)

# COMMAND ----------

lst = [4,6]
sum(lst)

# COMMAND ----------

l=[1,2,3,4,5]
LST = [x&1 for x in l]
print(LST)

# COMMAND ----------

print(6 & 1)
l1=[1,2,3]
l2=[4,5,6]
print([x*y for x in l1 for y in l2])

# COMMAND ----------

s=["pune", "mumbai", "delhi"]
[(w.upper(), len(w)) for w in s]

# COMMAND ----------

# MAGIC %md
# MAGIC #DATAFRAME Operations
# MAGIC

# COMMAND ----------

# DBTITLE 1,customer having highest purchase each day
from pyspark.sql.functions import substring,regexp_replace,regexp_extract
from pyspark.sql import functions as F

data = [("01-01-2019",111,"pen","NY","stationary",10.00),
("01-01-2019",111,"pencil","NY","stationary",40.00),
("01-01-2019",222,"pen","NY","stationary",10.00),
("01-01-2019",333,"pen","NY","stationary",10.00),
("01-01-2019",444,"book","CT","stationary",55.00),
("01-01-2019",222,"pen","NY","stationary",10.00),
("01-02-2019",333,"pen","NY","stationary",10.00),
("01-02-2019",333,"pen","NY","stationary",10.00),
("01-02-2019",111,"slate","NY","stationary",40.00),
("01-02-2019",111,"slate","NY","stationary",40.00),
("01-02-2019",555,"bag","NY","stationary",100.00),
("01-03-2019",444,"pen","CT","stationary",10.00),
("01-03-2019",444,"pencil","CT","stationary",15.00),
("01-03-2019",444,"pencil","CT","stationary",15.00),
("01-03-2019",444,"pen","CT","stationary",10.00),
("01-03-2019",111,"pen","NY","stationary",10.00),
("01-03-2019",111,"pen","NY","stationary",10.00),
("01-04-2019",111,"pen","NY","stationary",10.00),
("01-04-2019",222,"pen","NY","stationary",10.00),
("01-04-2019",333,"pen","NY","stationary",10.00),
("01-04-2019",444,"choco","CT","stationary",50.00),
("01-04-2019",444,"choco","CT","stationary",50.00)
]

columns=["sdate","custid","pname","region","pcategory","price"]

df=spark.createDataFrame(data,columns)
display(df)

# COMMAND ----------

from pyspark.sql.functions import date_format,to_date,col
df = df.withColumn("sdate",to_date(col("sdate"),"mm-dd-yyyy"))
display(df)


# COMMAND ----------

from pyspark.sql.functions import sum,max
from pyspark.sql.window import Window

# Per Day / per customer - Highest purchase he made - 
w = Window.partitionBy(col("sdate"),col("custid")).orderBy(col("sdate"),col("custid").asc())
df = df.withColumn("tot_price",sum(col("price")).over(w))

display(df)

df2  = df.groupBy(col("sdate"))\
          .agg(max(col("tot_price")).alias("highest_per_day_sales_made")).show()


# COMMAND ----------


date_format(TO_DATE(CAST(UNIX_TIMESTAMP(TIME_PERIOD, 'dd-MMM-yy') AS timestamp)),'MMM-yyyy') as YrMth_Mod,

date_format(TO_DATE(CAST(UNIX_TIMESTAMP(TIME_PERIOD, 'dd-MMM-yy') AS timestamp)),'yyMM') as YrMth
FROM tmp_RDI_COMPLIANCE_DATA

# COMMAND ----------

# DBTITLE 1,3rd highest salary of emp-dept details

columns = ["Empid","EmpName","Department"]
data = [(102,"Priya","E-104"),
        (103,"Neha","E-101"),
        (104,"Rahul","E-102")
]

employee = spark.createDataFrame(data,columns)
display(employee)


# COMMAND ----------

columns = ["DeptId", "DeptName"]

data = [
("E-101","HR"),
("E-102","Development"),
("E-103","Hous Keeping"),
("E-104","Sales"),
("E-105","Purchag")
]
department = spark.createDataFrame(data,columns)
display(department)

# COMMAND ----------

columns = ["Empid","salary"]
data = [
  (101,2000),
(102,10000),
(103,5000),
(104,1900),
(105,2300)
]

salary = spark.createDataFrame(data,columns)
display(salary)

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import rank,col
W = Window.orderBy(col("salary").desc())
# salary.withColumn("RN",rank().over(W)).filter(col("RN")==3).show()
salary = salary.withColumn("RN",rank().over(W))
display(salary)

# COMMAND ----------

emp_sal = employee.join(salary,on="Empid",how="fullouter")
display(emp_sal)

# COMMAND ----------

emp = emp_sal.join(department,department.DeptId==emp_sal.Department ,how="fullouter").filter(col("RN")==3)
display(emp)

# COMMAND ----------

# MAGIC %md
# MAGIC #regexp_replace

# COMMAND ----------

from pyspark.sql.functions import substring,regexp_replace,regexp_extract
from pyspark.sql import functions as F

data = [(1,"20200828","Karn-5555-ataka-77"),(2,"20180525","Maha-4144-rashtra-88")]
columns=["id","date","str"]

df=spark.createDataFrame(data,columns)
display(df)

# COMMAND ----------

df.show(truncate=False)

df.withColumn('year', substring('date', 1,4))\
.withColumn('month', substring('date', 5,2))\
.withColumn('day', substring('date', 7,2))\
.withColumn('str1',F.regexp_replace('str', '\d'   , '*'))\
.withColumn('str2',F.regexp_extract('str', '[\d]*'  ,  0 ))\
.withColumn('str4',F.regexp_extract('str', '[\d]+',  0 )).show()



# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT regexp_extract_all('100-200, 300-400', '(\\d+)-(\\d+)', 1)

# COMMAND ----------

df.withColumn('year', substring('date', 1,4))\
    .withColumn('month', substring('date', 5,2))\
    .withColumn('day', substring('date', 7,2)).show()

# COMMAND ----------

# MAGIC %md
# MAGIC #regexp_extract

# COMMAND ----------

from pyspark.sql.functions import substring,regexp_replace,regexp_extract,col
from pyspark.sql import functions as F
data = [(1,"20200828","Karn-5678-ataka-34"),(2,"20180525","Maha-1234-rashtra-56")]
columns=["id","date","milestone_event_nm"]

df_idc=spark.createDataFrame(data,columns)
# df_idc.show()

df_idc = df_idc.withColumn("n1", substring(col("milestone_event_nm"), -2, 2))

df_idc = df_idc.withColumn("n2", substring(col("milestone_event_nm"), 1, 4))

df_idc = df_idc.withColumn("n3", regexp_extract(col("milestone_event_nm"), "\d+",0))
df_idc = df_idc.withColumn("n4", regexp_extract(col("milestone_event_nm"), "(\d)+",1))
df_idc = df_idc.withColumn("n44", regexp_extract(col("milestone_event_nm"),"(\d+)",0))

# df_idc = df_idc.withColumn("n5", regexp_extract(col("milestone_event_nm"), "[\d]+",1))

# df_idc = df_idc.withColumn("n6", regexp_extract(col("milestone_event_nm"), "(\d)+",1))
# df_idc = df_idc.withColumn("n6", regexp_extract(col("milestone_event_nm"), "r(\d)+",1))
# df_idc = df_idc.withColumn("n7", df_idc.milestone_event_nm.substr(1,6))

df_idc.show()

# COMMAND ----------

# MAGIC %md
# MAGIC #regexp_count
# MAGIC The regexp_count function will be available from spark 3.5 onwards
# MAGIC Current version is 3.2.1

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import expr,regexp_count
from pyspark.sql.functions import substring,regexp_replace,regexp_extract,col

df = spark.createDataFrame(
    [("POWER BI PRO+Power BI (free)+AUDIO CONFERENCING+OFFICE 365 ENTERPRISE E5 WITHOUT AUDIO CONFERENCING",)],
    ["assigned_products"])

display(df)
df = df.withColumn('Number_Products_Assigned', F.expr(r"regexp_count(assigned_products, '\\+')"))

df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC #str.replace
# MAGIC

# COMMAND ----------

string = "I have an apple banana,apple jackfruit apple and a pear."
new_string = string.replace("apple", "orange", 2)
print(string)
print(new_string)

# COMMAND ----------

string = "I have an apple banana,apple jackfruit apple and a pear."
# new_string = string.replace("a", "A", 2)
new_string = string.replace("a", "A")
print(new_string)

# COMMAND ----------

# MAGIC %md
# MAGIC #str.find

# COMMAND ----------

string = "I have an apple and a pear."
start = string.find("apple")
print(start)
new_string = string[:start] + "orange" + string[start+5:]
print(new_string)

# COMMAND ----------

# MAGIC %md
# MAGIC # Count of char in PySpark DF col 

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.functions import col

df1 = spark.sql("select 'abc+def+ghi++aaaa' as x") # Sample data
df1.withColumn('substring_count', 
                F.length(col('x')) 
               - F.length(F.regexp_replace(col('x'), '\+', ''))
              ).show()
display(df1)

# COMMAND ----------

spark

# COMMAND ----------

# MAGIC %md
# MAGIC # Permutations

# COMMAND ----------

import itertools  
    
seq = "ABC"  
    
com_seq = itertools.permutations(seq, 2)  
    
for c in com_seq:  
    print(c)  

# COMMAND ----------

# MAGIC %md
# MAGIC #Combinations

# COMMAND ----------

import itertools  
    
seq = "ABC"  
    
com_seq = itertools.combinations(seq, 2)  

print(type(com_seq))

for c in com_seq:  
    print(c)  

# COMMAND ----------

from itertools import combinations_with_replacement  
  
com = combinations_with_replacement(['J', 'a', 'v', 'a', 't', 'p', 'o', 'i', 'n', 't'], 2)  

print(type(com))
  
for c in list(com):  
   print(c)  

# COMMAND ----------

# MAGIC %md
# MAGIC #Upsert

# COMMAND ----------

data = [  (11111 , 'CA', '2020-01-26'),
  (11111 , 'CA', '2020-02-26'),
  (88888 , 'CA', '2020-06-10'),
  (88888 , 'CA', '2020-05-10'),
  (88888 , 'WA', '2020-07-10'),
  (88888 , 'WA', '2020-07-15'),
  (55555 , 'WA', '2020-05-15'),
  (55555 , 'CA', '2020-03-15')
  ]
 
columns = ['attom_id', 'state_code', 'sell_date']
df = spark.createDataFrame(data, columns)
display(df)

# COMMAND ----------

from pyspark.sql.functions import to_date
df =df.withColumn("sell_date",to_date("sell_date","yyyy-MM-dd"))
display(df)

# COMMAND ----------

df = spark.createDataFrame([('a', 1), ('b', 2), ('c', 3)], ["key", "value"])

deltaTable = DeltaTable.replace(sparkSession)
    .tableName("testTable")
    .addColumns(df.schema)
    .execute()