# Databricks notebook source
# MAGIC %md
# MAGIC ###list
# MAGIC

# COMMAND ----------

animals = ['cat', 'dog', 'rabbit']
# animals = ('cat', 'dog', 'rabbit')

wild_animals = ['tiger', 'fox']

# animals.append(wild_animals)
# animals.append("lion")

animals.extend(wild_animals)
# animals.extend("lion")

print('Updated animals list: ', animals)

# COMMAND ----------

import re
text = 'My favorite number is 25.'
print(text.title())


text = '234 k3l2 *43 fun'
print(text.title())

# COMMAND ----------

# Operating System List
systems = ['Windows', 'macOS', 'Linux']
print('Original List:', systems)

systems.reverse()
print('Updated List:', systems)

# COMMAND ----------

# Operating System List
systems = ['Windows', 'macOS', 'Linux']
print('Original List:', systems)

reversed_list = systems[::-1]

print('Updated List:', reversed_list)

# COMMAND ----------

#tupel immutable - df  . CAN OverWrite. CANNOT change.
# animals tuple
animals = ('cat', 'dog', 'rabbit')


wild_animals = ('tiger', 'fox')

animals.join(wild_animals)

print('Updated animals tuple: ', animals)

# COMMAND ----------


data=data = [('James','','Smith','1991-04-01'),
  ('Michael','Rose','','2000-05-19'),
  ('Robert','','Williams','1978-09-05'),
  ('Maria','Anne','Jones','1967-12-01'),
  ('Jen','Mary','Brown','17-02-1980')
]

columns=["firstname","middlename","lastname","dob"]
df=spark.createDataFrame(data,columns)
df.printSchema()
df.show(truncate=False)

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

df1 = df.withColumn('year', split(df['dob'], '-').getItem(0)) \
       .withColumn('month', split(df['dob'], '-').getItem(1)) \
       .withColumn('day', split(df['dob'], '-').getItem(2))
df1.printSchema()
df1.show(truncate=False)

# COMMAND ----------

df = spark.createDataFrame([["Pune-MH"],["Banglore-KA"],["Chennai-TN"]],["loc"])
display(df)

# COMMAND ----------

df=df.withColumn("city",split("loc","-").getItem(0))\
      .withColumn("state",split("loc","-").getItem(1))
display(df)


# COMMAND ----------

df = spark.createDataFrame([["000012340055"],["000435540055"],["000322350055"]],["SKU"])
display(df)


# COMMAND ----------

df=df.withColumn("SKU",df.SKU.cast('int'))
display(df)

# COMMAND ----------

df=df.withColumn("SKU",df.SKU.cast(IntegerType()))
display(df)

# COMMAND ----------

from pyspark.sql.types import IntegerType
df=df.select(col("SKU").cast(IntegerType()))
display(df)

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType

# COMMAND ----------

df=df.withColumn("SKU",F.regexp_replace("SKU",r'0',""))
display(df)

# COMMAND ----------

string = "Python is fun"
print(string.rpartition('is '))
print(string.rpartition('not '))

string = "Python is fun, isn't it"
print(string.rpartition('is'))

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from global_temp.Sandeep_Siv

# COMMAND ----------

random_string = 'this is good    si oo si oo'

# Trailing whitespace are removed
print(random_string.rstrip())

# 'si oo' are not trailing characters so nothing is removed
print(random_string.rstrip('si oo'))

# in 'sid oo', 'd oo' are the trailing characters, 'ood' is removed from the string
# print(random_string.rstrip('sid oo')) website = 'www.programiz.com/' 

# print(website.rstrip('m/.'))



# COMMAND ----------

name = "JoHn CeNa"
print(name.swapcase())


# COMMAND ----------

text = 'bat ball'
replaced_text = text.replace('ba', 'ro')
print(replaced_text)

# COMMAND ----------

text = "program is fun"
print(text.zfill(15))
print(text.zfill(20))
print(text.zfill(10))

# COMMAND ----------

text = "programming is easy"
result = text.startswith(('python', 'programming'))

print(result)

result = text.startswith(('is', 'easy', 'java'))
print(result)

result = text.startswith(('programming', 'easy'), 12, 19)
print(result)

# COMMAND ----------

Strngs ={'E', 'f', 'a', 'i', 'o', 'U', 'a','A'}
print(Strngs)

lst=list(Strngs)
print(lst)
lst1=[]
for i in lst:
  if i.isupper():
    lst1.append(i.lower())
  else:
    lst1.append(i.upper())
    
print(lst1)
    

# COMMAND ----------

# MAGIC %md
# MAGIC ###inter [][]

# COMMAND ----------

a = ["Apple","Orange"]
print(a[-1][1])
print(a[0][1])

# COMMAND ----------

# MAGIC %md
# MAGIC ### collect show take
# MAGIC df.show() : It will show only the content of the dataframe.
# MAGIC
# MAGIC df.collect() : It will show the content and metadata of the dataframe.
# MAGIC
# MAGIC df.take() : shows content and structure/metadata for a limited number of rows for a very large dataset.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Windows 

# COMMAND ----------

simpleData = (("James", "Sales", 3000), \
    ("Michael", "Sales", 4600),  \
    ("Robert", "Sales", 4100),   \
    ("Maria", "Finance", 3000),  \
    ("James", "Sales", 3000),    \
    ("Scott", "Finance", 3300),  \
    ("Jen", "Finance", 3900),    \
    ("Jeff", "Marketing", 3000), \
    ("Kumar", "Marketing", 2000),\
    ("Saif", "Sales", 4100) \
  )
 
columns= ["employee_name", "department", "salary"]
df = spark.createDataFrame(data = simpleData, schema = columns)


# COMMAND ----------

df=df.withColumn("department_new",df.department)
df=df.drop(df.department)
df=df.withColumnRenamed("department_new","department")

# COMMAND ----------

df.show()

# COMMAND ----------

df.collect()

# COMMAND ----------

df.take(4)

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
from pyspark.sql import functions as F
windowSpec  = Window.partitionBy("department").orderBy("salary")

df.withColumn("row_number",F.row_number().over(windowSpec)) \
    .show(truncate=False)


# COMMAND ----------


from pyspark.sql.functions import rank
windowSpec  = Window.partitionBy("department").orderBy("salary")
df.withColumn("rank",rank().over(windowSpec)) \
    .show()


# COMMAND ----------


"""dens_rank"""
from pyspark.sql.functions import dense_rank
windowSpec  = Window.partitionBy("department").orderBy("salary")
df.withColumn("dense_rank",dense_rank().over(windowSpec)) \
    .show()


# COMMAND ----------

from pyspark.sql.functions import dense_rank
windowSpec  = Window.partitionBy("department").orderBy(col("salary").desc())
df.withColumn("dense_rank",dense_rank().over(windowSpec)) \
    .show()

# df.withColumn("dense_rank",dense_rank().over(Window.partitionBy("department").orderBy(col("salary").desc()))) \

# COMMAND ----------



from pyspark.sql.functions import col,avg,sum,min,max,row_number 
from pyspark.sql.window import Window

windowSpec  = Window.partitionBy("department").orderBy("salary")

windowSpecAgg  = Window.partitionBy("department")

df.withColumn("row",row_number().over(windowSpec)) \
  .withColumn("avg", avg(col("salary")).over(windowSpecAgg)) \
  .withColumn("sum", sum(col("salary")).over(windowSpecAgg)) \
  .withColumn("min", min(col("salary")).over(windowSpecAgg)) \
  .withColumn("max", max(col("salary")).over(windowSpecAgg)) \
  .where(col("row")==1).select("department","avg","sum","min","max") \
  .show()


# COMMAND ----------

display(df)

# COMMAND ----------

windowSpecAgg  = Window.partitionBy("department")
df.withColumn("row",row_number().over(windowSpec)) \
.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### distinctCount

# COMMAND ----------


data = [("James", "Sales", 3000),
    ("Michael", "Sales", 4600),
    ("Robert", "Sales", 4100),
    ("Maria", "Finance", 3000),
    ("James", "Sales", 3000),
    ("Scott", "Finance", 3300),
    ("Jen", "Finance", 3900),
    ("Jeff", "Marketing", 3000),
    ("Kumar", "Marketing", 2000),
    ("Saif", "Sales", 4100)
  ]
columns = ["Name","Dept","Salary"]
df2 = spark.createDataFrame(data=data,schema=columns)

df2.distinct().show()
print("Distinct Count: " + str(df.distinct().count()))

# COMMAND ----------

df.createOrReplaceGlobalTempView("San")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from global_temp.San

# COMMAND ----------

df.cache()

# COMMAND ----------

df.persist()

# COMMAND ----------

# Using countDistrinct()
from pyspark.sql.functions import countDistinct
df2=df.select(countDistinct("Dept","Salary").alias("dept_salary"))
df2.show()

print("Distinct Count of Department & Salary: "+ str(df2.collect()[0][0]))

# COMMAND ----------

# MAGIC %md
# MAGIC ### parquet
# MAGIC

# COMMAND ----------

data =[("James ","","Smith","36636","M",3000),
              ("Michael ","Rose","","40288","M",4000),
              ("Robert ","","Williams","42114","M",4000),
              ("Maria ","Anne","Jones","39192","F",4000),
              ("Jen","Mary","Brown","","F",-1)]
columns=["firstname","middlename","lastname","dob","gender","salary"]
df=spark.createDataFrame(data,columns)

# COMMAND ----------

df.write.parquet("dbfs:/user/hive/warehouse/people_san.parquet")


# COMMAND ----------

parDF=spark.read.parquet("dbfs:/user/hive/warehouse/people_san.parquet")
display(parDF)

# COMMAND ----------

df.write.mode('append').parquet("dbfs:/user/hive/warehouse/people_san.parquet")
# df.write.mode('overwrite').parquet("/tmp/output/people.parquet")

# COMMAND ----------

spark.sql("CREATE TEMPORARY VIEW PERSON USING parquet OPTIONS (path \"/user/hive/warehouse/people_san.parquet\")")
spark.sql("SELECT * FROM PERSON").show()

# COMMAND ----------

df.write.partitionBy("gender","salary").mode("overwrite").parquet("user/hive/warehouse/people_san.parquet")

# COMMAND ----------

# MAGIC %fs 
# MAGIC ls "dbfs:/user/hive/warehouse/people_san.parquet"

# COMMAND ----------

parDF2=spark.read.parquet("/user/hive/warehouse/people_san.parquet/gender=M")
parDF2.show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ###JDBC 
# MAGIC
# MAGIC The fetchsize is another option which is used to specify how many rows to fetch at a time, by default it is set to 10.
# MAGIC
# MAGIC You can also select the specific columns with where condition by using the pyspark jdbc query option to read in parallel. Note that you can use either dbtable or query option but not both at a time. Also, when using the query option, you can’t use partitionColumn option.
# MAGIC

# COMMAND ----------

df = spark.read \
    .format("jdbc") \
    .option("driver","com.mysql.cj.jdbc.Driver") \
    .option("url", "jdbc:mysql://localhost:3306/emp") \
    .option("query","select id,age from employee where gender='M'") \
    .option("numPartitions",5) \
    .option("fetchsize", 20) \
    .option("user", "root") \
    .option("password", "root") \
    .load()

# COMMAND ----------

# MAGIC %md
# MAGIC ### reduceBy
# MAGIC PySpark reduceByKey() transformation is used to merge the values of each key using an associative reduce function on PySpark RDD. It is a wider transformation as it shuffles data across multiple partitions and It operates on pair RDD (key/value pair).
# MAGIC
# MAGIC When reduceByKey() performs, the output will be partitioned by either numPartitions or the default parallelism level. The Default partitioner is hash-partition.
# MAGIC
# MAGIC First, let’s create an RDD from the list.

# COMMAND ----------


data = [('Project', 1),
('Gutenberg’s', 1),
('Alice’s', 1),
('Adventures', 1),
('in', 1),
('Wonderland', 1),
('Project', 1),
('Gutenberg’s', 1),
('Adventures', 1),
('in', 1),
('Wonderland', 1),
('Project', 1),
('Gutenberg’s', 1)]

rdd=spark.sparkContext.parallelize(data)


# COMMAND ----------

rdd2=rdd.reduceByKey(lambda a,b: a+b)
for element in rdd2.collect():
    print(element)

# COMMAND ----------

# MAGIC %md
# MAGIC ### lag

# COMMAND ----------

simpleData = (("James", "Sales", 3000), \
    ("Michael", "Sales", 4600),  \
    ("Robert", "Sales", 4100),   \
    ("Maria", "Finance", 3000),  \
    ("James", "Sales", 3000),    \
    ("Scott", "Finance", 3300),  \
    ("Jen", "Finance", 3900),    \
    ("Jeff", "Marketing", 3000), \
    ("Kumar", "Marketing", 2000),\
    ("Saif", "Sales", 4100) \
  )
columns= ["employee_name", "department", "salary"]

# Create DataFrame
df = spark.createDataFrame(data = simpleData, schema = columns)
df.show(truncate=False)

# COMMAND ----------

from pyspark.sql.window import Window
windowSpec  = Window.partitionBy("department").orderBy("salary")

# COMMAND ----------

from pyspark.sql.functions import lag    
df.withColumn("lag",lag("salary",1,default=0000).over(windowSpec)) \
      .show()

# COMMAND ----------

# MAGIC %md
# MAGIC ###lead
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import lead  
from pyspark.sql.window import Window
windowSpec  = Window.partitionBy("department").orderBy("salary")
df.withColumn("LEAD",lead("salary",1,default=5555).over(windowSpec)).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ###Cumulative sum
# MAGIC

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import lead  
from pyspark.sql import   functions as F
windowSpec  = Window.partitionBy("department").orderBy("salary")
df.withColumn('cum_sum', F.sum('salary').over(windowSpec)).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ###running total

# COMMAND ----------

students =[(4,'sravan',23,'PHP','Testing'),
           (4,'sravan',23,'PHP','Testing'),
           (46,'mounika',22,'.NET','HTML'),
           (4,'deepika',21,'Oracle','HTML'),
           (46,'mounika',22,'Oracle','Testing'),
           (12,'chandrika',22,'Hadoop','C#'),
           (12,'chandrika',22,'Oracle','Testing'),
           (4,'sravan',23,'Oracle','C#'),
           (4,'deepika',21,'PHP','C#'),
           (46,'mounika',22,'.NET','Testing')
              ]
 
dataframe_obj = spark.createDataFrame ( students,['subject_id','name','age','technology1','technology2'])
 
print("----------Actual DataFrame----------")
dataframe_obj.show()

# COMMAND ----------

from pyspark.sql.functions import datediff,col,Column
from pyspark.sql import functions as F
from pyspark.sql.functions import lead,lag,avg
partition  = Window.partitionBy("technology1")
windowSpec  = Window.partitionBy("technology1").orderBy("subject_id")

dataframe_obj.withColumn ("SUM",F.sum(col("subject_id")).over(partition))\
.withColumn ("AVG",F.avg(col("subject_id")).over(partition))\
.withColumn ("MAX",F.max(col("subject_id")).over(partition))\
.withColumn ("MIN",F.min(col("subject_id")).over(partition))\
.withColumn ("LEAD",lead("subject_id",1,default=5555).over(windowSpec))\
.withColumn ("LAG",lag("subject_id",1,default=5555).over(windowSpec))\
.show()

# COMMAND ----------

# MAGIC %run /Users/GUTTESA1@novartis.net/Final_Adhoc_automate_SAN

# COMMAND ----------

df_san_employee=rds_table_read('SAN_EMPLOYEE','RDI')

# COMMAND ----------

# MAGIC %sql
# MAGIC with CTE as(
# MAGIC select *,
# MAGIC sum(SALARY) over (PARTITION by DEPARTMENT_ID order by EMPID) as running_total,
# MAGIC sum(SALARY) over (PARTITION by DEPARTMENT_ID) as sum_all,
# MAGIC ROW_NUMBER() over(order by EMPID) as rownumber,
# MAGIC RANK() over(order by EMPID) as rnak,
# MAGIC DENSE_RANK() over(order by EMPID) as denserank
# MAGIC FROM CA_RDI.SAN_EMPLOYEE
# MAGIC ) select * from CTE 
# MAGIC  where denserank = 8
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###Bank Balance
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from default.transaction_san

# COMMAND ----------

df=spark.sql("select * from  default.transaction_san")

# COMMAND ----------

from pyspark.sql.functions import when
from pyspark.sql import functions as F
 
df.withColumn("AmountMod", F.when(df.CRDR == 'CR', df["AMOUNT"]=df["AMOUNT"]*1)
              .otherwise(df["AMOUNT"]=df["AMOUNT"]*-1)
             ).show()

# F.when(df_wp_single_cur.study_code_alias.isNotNull(), 'Yes').otherwise('No'))

#  case when C.cohort_name!='null' then 'Yes'
#                     else 'No' end as cohort

# When case statement is not working for the  df["AMOUNT"]=df["AMOUNT"]*1 column updation \
#use to follow below approach

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select TRANSDATE,ACCNO,CRDR,AMOUNT,sum(AMT) over(partition by ACCNO order by TRANSDATE ) as running
# MAGIC from 
# MAGIC (
# MAGIC select TRANSDATE,ACCNO,CRDR,AMOUNT,(AMOUNT*multiFactor) as AMT from
# MAGIC (
# MAGIC select TRANSDATE,ACCNO,CRDR,AMOUNT,
# MAGIC case when CRDR == 'CR' then 1
# MAGIC else -1 
# MAGIC end as multiFactor 
# MAGIC from default.transaction_san
# MAGIC )A
# MAGIC )B

# COMMAND ----------

# MAGIC %md
# MAGIC ### Map vs Flatmap

# COMMAND ----------

# MAGIC %md
# MAGIC --
# MAGIC map() – Spark map() transformation applies a function to each row in a DataFrame/Dataset and returns the new transformed Dataset.
# MAGIC flatMap() – Spark flatMap() transformation flattens the DataFrame/Dataset after applying the function on every element and returns a new transformed Dataset. The returned Dataset will return more rows than the current DataFrame. It is also referred to as a one-to-many transformation function. This is one of the major differences between flatMap() and map()
# MAGIC Key points
# MAGIC
# MAGIC Both map() & flatMap() returns Dataset (DataFrame=Dataset[Row]).
# MAGIC Both these transformations are narrow meaning they do not result in Spark Data Shuffle.
# MAGIC flatMap() results in redundant data on some columns.
# MAGIC One of the use cases of flatMap() is to flatten column which contains arrays, list, or any nested collection(one cell with one value).
# MAGIC map() always return the same size/records as in input DataFrame whereas flatMap() returns many records for each record (one-many).
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Unfortunately, PySpark DataFame doesn’t have flatMap() transformation however, DataFrame has explode() SQL function that is used to flatten the column. Below is a complete example.

# COMMAND ----------


data = ["Project Gutenberg’s",
        "Alice’s Adventures in Wonderland",
        "Project Gutenberg’s",
        "Adventures in Wonderland",
        "Project Gutenberg’s"]
rdd=spark.sparkContext.parallelize(data)
for element in rdd.collect():
    print(element)


# COMMAND ----------


rdd2=rdd.flatMap(lambda x: x.split(" "))
for element in rdd2.collect():
    print(element)


# COMMAND ----------

# MAGIC %md
# MAGIC Explode does the same task as of flatmap() does

# COMMAND ----------

import pyspark
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName('pyspark-by-examples').getOrCreate()

arrayData = [
        ('James',['Java','Scala'],{'hair':'black','eye':'brown'}),
        ('Michael',['Spark','Java',None],{'hair':'brown','eye':None}),
        ('Robert',['CSharp',''],{'hair':'red','eye':''}),
        ('Washington',None,None),
        ('Jefferson',['1','2'],{})]
df = spark.createDataFrame(data=arrayData, schema = ['name','knownLanguages','properties'])

from pyspark.sql.functions import explode
df2 = df.select(df.name,explode(df.knownLanguages))
df2.printSchema()
df2.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Note1: DataFrame doesn’t have map() transformation to use with DataFrame hence you need to convert DataFrame to RDD first.
# MAGIC Note2: If you have a heavy initialization use PySpark mapPartitions() transformation instead of map(), as with mapPartitions() heavy initialization executes only once for each partition instead of every record.

# COMMAND ----------

#map
from pyspark.sql import SparkSession
spark = SparkSession.builder.master("local[1]") \
    .appName("SparkByExamples.com").getOrCreate()

data = ["Project","Gutenberg’s","Alice’s","Adventures",
"in","Wonderland","Project","Gutenberg’s","Adventures",
"in","Wonderland","Project","Gutenberg’s"]

rdd=spark.sparkContext.parallelize(data)

# COMMAND ----------

rdd2=rdd.map(lambda x: (x,1))
for element in rdd2.collect():
    print(element)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Scenario Based

# COMMAND ----------

data =[
(1,'SS',12,1234,"10/12/2022",None),
(2,'SS',12,1234,"10/12/2022","HYD"),
(3,'SS',12,1234,"10/12/2022","DEL"),
(4,'SS',12,1234,"10/12/2022","BLR"),
(5,'SS',12,1234,"10/12/2022","BLR"),
(6,'SS',12,1234,"10/12/2022","BLR"),
(7,'SS',12,1234,"10/12/2022","HYD"),
(8,'SS',12,1234,None,"PUN")
]
columns=["id","name","dept","code","jdate","city"]
df=spark.createDataFrame(data,columns)

display(df)

# COMMAND ----------

df=df.na.fill(value="BOMBAY")
df=df.na.fill(value="9999-12-31",subset=["jdate"])
display(df)

# COMMAND ----------

from pyspark.sql.functions import regexp_replace

# df=df.withColumn("city",regexp_replace(df.city,"BLR","BANGLORE"))

df=df.withColumn("city",regexp_replace(df.city,"BLR","MUMBAI"))

display(df)


# COMMAND ----------

import re

s="Sandeep Shesharao. Gutte"

# COMMAND ----------

re.findall("\w+",s)

# COMMAND ----------

re.findall("(?:[\w+]+\s)(\w+[.]?)(?:\s\w+)",s)

# ?: find and replace
# ? find zero or more pattern values

# COMMAND ----------

re.findall("[\w+]+$",s)

# COMMAND ----------

r="Oct 30, 1991[a]"

# COMMAND ----------

re.findall("\w{1,3}\s\d{1,2}[,]\s\d{1,4}",r)

#{} curley braces for matching the pattern

# COMMAND ----------

r="32 years, 67daysApril 30, 1991"

re.findall("(\d{1,2})(?:\s)(?:\w+)",r)

# COMMAND ----------

# MAGIC %md
# MAGIC ###WordCount

# COMMAND ----------

dbutils.fs.put("dbfs:/user/hive/warehouse/wordFile.txt","""The change is the only constant thing in nature.
The change is the only constant thing in nature.
The change is the only constant thing in nature.
The Nature is great.
The Nature is great.
The one and only Prakruti.""")

# COMMAND ----------

# MAGIC %fs 
# MAGIC ls  "dbfs:/user/hive/warehouse/wordFile.txt"
# MAGIC head  "dbfs:/user/hive/warehouse/wordFile.txt"

# COMMAND ----------

rdd=sc.textFile("dbfs:/user/hive/warehouse/wordFile.txt")

# COMMAND ----------

rdd1=rdd.flatMap(lambda x: x.lower().split())
rdd2=rdd1.map(lambda x: (x,1))
rdd3=rdd2.reduceByKey(lambda x,y: (x+y))
rdd4=rdd3.sortByKey()
rdd5=rdd4.map(lambda x:(x[1],x[0]))
rdd6=rdd5.sortByKey(False)
rdd6.collect()

df=spark.createDataFrame(rdd6,["count","word"])
display(df)

# COMMAND ----------

df.show()

# COMMAND ----------

rdd6.take(2)

# COMMAND ----------

# default num of partitions for rdd
# //RDD
# rdd.getNumPartitions()
# rdd.partitions.length()
# rdd.partitions.size()

# // For DataFrame, convert to RDD first
# df.rdd.getNumPartitions
# df.rdd.partitions.length
# df.rdd.partitions.size

# COMMAND ----------

# MAGIC %md
# MAGIC ###Swap 

# COMMAND ----------

data =[
(1,'SS',12,1234,"10/12/2022",None),
(2,'SS',12,1234,"10/12/2022","HYD"),
(3,'SS',12,1234,"10/12/2022","DEL"),
(4,'SS',12,1234,"10/12/2022","BLR"),
(5,'SS',12,1234,"10/12/2022","BLR"),
(6,'SS',12,1234,"10/12/2022","BLR"),
(7,'SS',12,1234,"10/12/2022","HYD"),
(8,'SS',12,1234,None,"PUN")
]
columns=["id","name","dept","code","jdate","city"]
df=spark.createDataFrame(data,columns)

display(df)

# COMMAND ----------

df.createOrReplaceTempView("tmp_df")

# COMMAND ----------

# MAGIC %sql
# MAGIC update tmp_df
# MAGIC set name="Sandeep"
# MAGIC where id =5
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Swapping of the alternate row id's.
# MAGIC this can happen in databse and delta table in databricks.
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- select id,name
# MAGIC -- from tmp_df
# MAGIC
# MAGIC update tmp_df
# MAGIC set  id =
# MAGIC      case when id%2 == 0
# MAGIC      then id=id-1
# MAGIC      else 
# MAGIC      then id=id+1
# MAGIC      end
# MAGIC
# MAGIC
# MAGIC -- UPDATE tmp_df 
# MAGIC -- SET    id = name,
# MAGIC --        name = id; 
# MAGIC
# MAGIC
# MAGIC