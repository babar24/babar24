# Databricks notebook source
max_date=spark.sql("""show partitions odh_horizon_reporting_dm_landing.v_wp_single_current""").rdd.flatMap(lambda x:x).map(lambda x : x.replace("tran_date=","")).max()

partition_where = max_date.replace("/"," and ")

print(partition_where)


# COMMAND ----------

# MAGIC %md
# MAGIC #####Libraries - Magic Command
# MAGIC

# COMMAND ----------

# MAGIC %run CAFDB/cafdb_publish/notebook/common/common_ingestion_util

# COMMAND ----------

from pyspark.sql.types import StructField, StructType, StringType, IntegerType,DateType
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import functions as F
from pyspark.sql.window import Window
import pandas as pd
from pyspark.sql.functions import datediff,col,Column
import py4j
import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
import warnings
from pandas.core.common import SettingWithCopyWarning
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)

# COMMAND ----------

def rds_db_screts(rds_db_name):

  if rds_db_name == 'CPP':
    scope_key = "f1_cafdb_cpp_publish"
  elif rds_db_name == 'FLAIR':
    scope_key = "f1_cafdb_flair_publish"
  elif rds_db_name == 'CAFMART':
    scope_key = "f1_cafdb_cafmart_publish"
  elif rds_db_name == 'GDOLT':
    scope_key = "f1_cafdb_gdolt_publish"
  elif rds_db_name == 'ADHOC':
    scope_key = "f1_cafdb_adhoc_publish"
  elif rds_db_name == 'CAFDB':
    scope_key = "f1_cafdb_publish"
  elif rds_db_name == 'RDI':
    scope_key = "f1_cafdb_rdi_publish"
  else:
    scope_key = "f1_super_cafdb_publish"
  secrets_key = "rds_cafdb"
  driver = "org.postgresql.Driver"
  secrets = {"jdbcUsername": dbutils.secrets.get(scope=scope_key, key=secrets_key+"_user_name"),
               "jdbcPassword": dbutils.secrets.get(scope=scope_key, key=secrets_key+"_password"),
               "jdbcUrl": dbutils.secrets.get(scope=scope_key, key=secrets_key+"_jdbc_url")
              }
  return secrets

# COMMAND ----------

# MAGIC %fs
# MAGIC ls "dbfs:/user/hive/warehouse/emp_san_data/"

# COMMAND ----------

df =  spark.read.format("delta")\
  .load("dbfs:/user/hive/warehouse/emp_san_data")
df.createOrReplaceTempView("tmp_emp_san_data")

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from tmp_emp_san_data

# COMMAND ----------

# spark.conf.get('spark.sql.shuffle.partitions')
# spark.conf.set('spark.sql.shuffle.partitions', '20')

# spark.conf.get('spark.sql.autoBroadcastJoinThreshold')
# 10485760/1024/1024

# spark.conf.get('spark.sql.batchsize')

# spark.catalog.clearCache()
# spark.conf.get("spark.memory.chauffeur")

# fetchsize
# batchsize
# print(spark.conf.get("spark.sql.files.minPartitionNum"))

# spark.default.parallelism
# spark.conf.get("spark.default.parallelism","300")

# COMMAND ----------

from platform import python_version
print(python_version())

# COMMAND ----------

# MAGIC %fs
# MAGIC
# MAGIC ls dbfs:/user/hive/warehouse/emp_san_data

# COMMAND ----------

import pyspark
from pyspark.sql import SparkSession
spark = SparkSession.builder.master("local[1]") \
                    .appName('SparkByExamples.com') \
                    .getOrCreate()

print("First SparkContext:");
print("APP Name :"+spark.sparkContext.appName);
print("Master :"+spark.sparkContext.master);

sparkSession2 = SparkSession.builder \
      .master("local[1]") \
      .appName("SparkByExample-test") \
      .getOrCreate();

print("Second SparkContext:")
print("APP Name :"+sparkSession2.sparkContext.appName);
print("Master :"+sparkSession2.sparkContext.master);

sparkSession3 = SparkSession.newSession

print("Second SparkContext:")
print("APP Name :"+sparkSession3.sparkContext.appName);
print("Master :"+sparkSession3.sparkContext.master);

# COMMAND ----------

print("Number of partitions in fileRDD is", spark_data.getNumPartitions())

# COMMAND ----------

numb = range(1, 100)

spark_data = sc.parallelize(numb)

spark_data.take(5)

# COMMAND ----------

words = sc.parallelize (
   ["scala", 
   "java", 
   "hadoop", 
   "spark", 
   "akka",
   "spark vs hadoop", 
   "pyspark",
   "pyspark and spark"]
)
words_filter = words.filter(lambda x: 'spark' in x)
counts = words_filter.count()
print ("Number of elements filtered  -> %i" % (counts))


# COMMAND ----------


# Print my_list in the console
print("Input list is", my_list)

# Square all numbers in my_list
squared_list_lambda = list(map(lambda x: x**2, my_list))

# Print the result of the map function
print("The squared numbers are", squared_list_lambda)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Concat_ws
# MAGIC -- Convert array of strings to strings

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT CONCAT_WS("**", "SQL", "Tutorial", "is", "fun!") AS ConcatenatedString;

# COMMAND ----------

columns = ["name","languagesAtSchool","currentState"]

data = [("James,,Smith",["Java","Scala","C++"],"CA"), \
    ("Michael,Rose,",["Spark","Java","C++"],"NJ"), \
    ("Robert,,Williams",["CSharp","VB"],"NV")]

df = spark.createDataFrame(data=data,schema=columns)
df.printSchema()
df.show(truncate=False)

# COMMAND ----------

from pyspark.sql.functions import col, concat_ws
df2 = df.withColumn("languagesAtSchool",concat_ws(",",col("languagesAtSchool")))
df2.printSchema()
df2.show(truncate=False)


# COMMAND ----------


df.createOrReplaceTempView("ARRAY_STRING")
spark.sql("select name, concat_ws(',',languagesAtSchool) as languagesAtSchool," + \
    " currentState from ARRAY_STRING") \
    .show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### DataFrame Creation 
# MAGIC
# MAGIC 4 Methods of dataframe creation
# MAGIC

# COMMAND ----------


columns = ["language","users_count"]
data = [("Java", "20000"), ("Python", "100000"), ("Scala", "3000")]

# COMMAND ----------

# spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()
# rdd = spark.sparkContext.parallelize(data)

rdd = sc.parallelize(data)

# COMMAND ----------

dfFromRDD1 = rdd.toDF()
dfFromRDD1 = rdd.toDF(columns)
dfFromRDD1.printSchema()

# COMMAND ----------

dfFromRDD2 = spark.createDataFrame(rdd).toDF(*columns)

# COMMAND ----------

from pyspark.sql.types import Row
rowData = map(lambda x: Row(*x), data) 
dfFromData3 = spark.createDataFrame(rowData,columns)
display(dfFromData3)

# COMMAND ----------

data2 = [("James","","Smith","36636","M",3000),
    ("Michael","Rose","","40288","M",4000),
    ("Robert","","Williams","42114","M",4000),
    ("Maria","Anne","Jones","39192","F",4000),
    ("Jen","Mary","Brown","","F",-1)
  ]

schema = StructType([
    StructField("firstname",StringType(),True), 
    StructField("middlename",StringType(),True),
    StructField("lastname",StringType(),True),
    StructField("id", StringType(), True), 
    StructField("gender", StringType(), True),
    StructField("salary", IntegerType(), True)
  ])
 
df = spark.createDataFrame(data=data2,schema=schema)
df.printSchema()
df.show(truncate=False)

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### EmptyRdd
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Parallelize
# MAGIC

# COMMAND ----------

rdd=spark.sparkContext.parallelize([11,2,3,4,5])

# COMMAND ----------

rdd=sc.parallelize([11,2,3,4,5])

# COMMAND ----------



rddCollect = rdd.collect()
print("Number of Partitions: "+str(rdd.getNumPartitions()))
print("Action: First element: "+str(rdd.first()))
print(rddCollect)

emptyRDD = spark.sparkContext.emptyRDD()
emptyRDD2 = rdd=spark.sparkContext.parallelize([])

print(""+str(emptyRDD2.isEmpty()))

# COMMAND ----------

from pyspark.sql import SparkSession
spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()

emptyRDD = spark.sparkContext.emptyRDD()
print(emptyRDD)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Read EXCEL
# MAGIC

# COMMAND ----------

dfs1 = spark.read.format("com.crealytics.spark.excel") \
  .option("location", "s3a://prdpath/pre_landing/cafdb/rdi/NDR_ALLOCATION.xlsx") \
  .option("useHeader", "true") \
  .option("Header", "true") \
  .option("treatEmptyValuesAsNulls", "false") \
  .option("inferSchema", "true") \
  .option("addColorColumns", "false") \
  .load("s3a://prdpath/pre_landing/cafdb/rdi/NDR_ALLOCATION.xlsx")
schema = dfs1.schema.json()

# COMMAND ----------

print(schema)

# COMMAND ----------

schema = Custom_Schema().get_schema_from_json("/dbfs/FileStore/tables/NDR_ALLOCATION.json")

source_name_path = "s3a://novartisrs3aprdief1prelanding001/pre_landing/cafdb/rdi/NDR_ALLOCATION.xlsx"

dfs1 = spark.read.format("com.crealytics.spark.excel") \
.option("location", source_name_path) \
.option("header", "true") \
.option("useHeader", "true") \
.option("Header", "true") \
.option("treatEmptyValuesAsNulls", "false") \
.option("inferSchema", "true") \
.option("addColorColumns", "false") \
.schema(schema) \
.load("s3a://novartisrs3aprdief1prelanding001/pre_landing/cafdb/rdi/NDR_ALLOCATION.xlsx")
display(dfs1)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Read CSV
# MAGIC

# COMMAND ----------

# MAGIC %fs
# MAGIC ls "dbfs:/user/hive/warehouse/emp_san_data"

# COMMAND ----------

# df=spark.read.csv("dbfs:/user/hive/warehouse/emp_san_data/")
df=spark.read.parquet("s3a://novartisrs3aprdief1unified001/unified/clinical_operations/study_event")

df.createOrReplaceTempView("Employee")

# COMMAND ----------

path ="dbfs:/user/hive/warehouse/emp_san_data.csv"
df = spark.read.csv(
    path,
    schema=None,
    sep=None,
    encoding=None,
    quote=None,
    escape=None,
    comment=None,
    header=None,
    inferSchema=None,
    ignoreLeadingWhiteSpace=None,
    ignoreTrailingWhiteSpace=None,
    nullValue=None,
    nanValue=None,
    positiveInf=None,
    negativeInf=None,
    dateFormat=None,
    timestampFormat=None,
    maxColumns=None,
    maxCharsPerColumn=None,
    maxMalformedLogPerPartition=None,
    mode=None,
    columnNameOfCorruptRecord=None,
    multiLine=None,
    charToEscapeQuoteEscaping=None,
    samplingRatio=None,
    enforceSchema=None,
    emptyValue=None,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Read JSON
# MAGIC

# COMMAND ----------

import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType,StructField, StringType, IntegerType

spark = SparkSession.builder.master("local[1]") \
                    .appName('SparkByExamples.com') \
                    .getOrCreate()

data = [("James","","Smith","36636","M",3000),
    ("Michael","Rose","","40288","M",4000),
    ("Robert","","Williams","42114","M",4000),
    ("Maria","Anne","Jones","39192","F",4000),
    ("Jen","Mary","Brown","","F",-1)
  ]

schema = StructType([ \
    StructField("firstname",StringType(),True), \
    StructField("middlename",StringType(),True), \
    StructField("lastname",StringType(),True), \
    StructField("id", StringType(), True), \
    StructField("gender", StringType(), True), \
    StructField("salary", IntegerType(), True) \
  ])
 
df = spark.createDataFrame(data=data,schema=schema)
df.printSchema()
df.show(truncate=False)


# COMMAND ----------

structureData = [
    (("James","","Smith"),"36636","M",3100),
    (("Michael","Rose",""),"40288","M",4300),
    (("Robert","","Williams"),"42114","M",1400),
    (("Maria","Anne","Jones"),"39192","F",5500),
    (("Jen","Mary","Brown"),"","F",-1)
  ]
structureSchema = StructType([
        StructField('name', StructType([
             StructField('firstname', StringType(), True),
             StructField('middlename', StringType(), True),
             StructField('lastname', StringType(), True)
             ])),
         StructField('id', StringType(), True),
         StructField('gender', StringType(), True),
         StructField('salary', IntegerType(), True)
         ])

df2 = spark.createDataFrame(data=structureData,schema=structureSchema)
df2.printSchema()
df2.show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### map
# MAGIC
# MAGIC Note1: DataFrame doesn’t have map() transformation.
# MAGIC To use with DataFrame hence you need to convert DataFrame to RDD first.
# MAGIC
# MAGIC rdd2=df.rdd.map(lambda x: 
# MAGIC     (x.firstname+","+x.lastname,x.gender,x.salary*2)
# MAGIC     )
# MAGIC
# MAGIC mapPartitions() – This is exactly the same as map(); the difference being, Spark mapPartitions() provides a facility to do heavy initializations (for example Database connection) once for each partition instead of doing it on every DataFrame row. This helps the performance of the job when you dealing with heavy-weighted initialization on larger datasets
# MAGIC

# COMMAND ----------


data = ["Project",
"Gutenberg’s",
"Alice’s",
"Adventures",
"in",
"Wonderland",
"Project",
"Gutenberg’s",
"Adventures",
"in",
"Wonderland",
"Project",
"Gutenberg’s"]

# rdd=spark.sparkContext.parallelize(data)
rdd=sc.parallelize(data)

rdd2=rdd.map(lambda x: (x,1))
for element in rdd2.collect():
    print(element)


# COMMAND ----------

    
data = [('James','Smith','M',30),
  ('Anna','Rose','F',41),
  ('Robert','Williams','M',62), 
]

columns = ["firstname","lastname","gender","salary"]
df = spark.createDataFrame(data=data, schema = columns)
df.show()

rdd2=df.rdd.map(lambda x: 
    (x[0]+","+x[1],x[2],x[3]*2)
    )  
df2=rdd2.toDF(["name","gender","new_salary"]   )
df2.show()

#Referring Column Names
rdd2=df.rdd.map(lambda x: 
    (x["firstname"]+","+x["lastname"],x["gender"],x["salary"]*2)
    ) 

#Referring Column Names
rdd2=df.rdd.map(lambda x: 
    (x.firstname+","+x.lastname,x.gender,x.salary*2)
    ) 

def func1(x):
    firstName=x.firstname
    lastName=x.lastname
    name=firstName+","+lastName
    gender=x.gender.lower()
    salary=x.salary*2
    return (name,gender,salary)

rdd2=df.rdd.map(lambda x: func1(x))


# COMMAND ----------

data = ["Project","Gutenberg’s","Alice’s","Adventures","in","Wonderland","Project","Gutenberg’s","Adventures","in","Wonderland","Project","Gutenberg’s"]

rdd=sc.parallelize(data)

rdd2=rdd.map(lambda x: (x,1))

for element in rdd2.collect():
    print(element)


# COMMAND ----------

    
data = [('James','Smith','M',30),
  ('John','Rose','F',41),
  ('Robert','Williams','M',62), 
]

columns = ["firstname","lastname","gender","salary"]
df = spark.createDataFrame(data=data, schema = columns)
df.show()

#converts DataFrame to rdd for rdd-Map function to apply
rdd2=df.rdd.map(lambda x: 
    (x[0]+","+x[1],x[2],x[3]*2)
    )  
#Conver back to DataFrame
df2=rdd2.toDF(["name","gender","new_salary"])
df2.show()

# COMMAND ----------

#Referring Column Names
rdd2=df.rdd.map(lambda x: 
    (x["firstname"]+","+x["lastname"],x["gender"],x["salary"]*2)
    ) 
print(rdd2.collect())

#Referring Column Names
rdd2=df.rdd.map(lambda x: 
    (x.firstname+","+x.lastname,x.gender,x.salary*2)
    ) 
print(rdd2.collect())

# COMMAND ----------


def func1(x):
    firstName=x.firstname
    lastName=x.lastname
    name=firstName+","+lastName
    gender=x.gender.lower()
    salary=x.salary*2
    return (name,gender,salary)

rdd2=df.rdd.map(lambda x: func1(x))


# COMMAND ----------

df.filter(df.firstname.startswith("J")).show()

# COMMAND ----------

input = ['one','two','three','four','five','six']
s=""
j=0
for i in input:
    j+=1
    s+=''.join(i)+'#'+str(j)+":"
print(s)

# COMMAND ----------

 temp_c = [10, 3, -5, 25, 1, 9, 29, -10, 5]
 temp_K = list(map(lambda x: x + 273.15, temp_c))
 list(temp_K)

# COMMAND ----------

# MAGIC %md
# MAGIC #####flatMap()
# MAGIC
# MAGIC is a transformation operation that flattens the RDD/DataFrame (array/map DataFrame columns) after applying the function on every element and returns a new PySpark RDD/DataFrame

# COMMAND ----------

data = ["Project Gutenberg’s",
        "Alice’s Adventures in Wonderland",
        "Project Gutenberg’s",
        "Adventures in Wonderland",
        "Project Gutenberg’s"]
rdd=sc.parallelize(data)
for element in rdd.collect():
    print(element)


# COMMAND ----------


rdd2=rdd.flatMap(lambda x: x.split(" "))
for element in rdd2.collect():
    print(element)


# COMMAND ----------

# MAGIC %md
# MAGIC #####Pivot & UnPivot
# MAGIC
# MAGIC Pivot is nothing but the rows to column conversion aand unPivot is reverse

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Multiple Rows to Multiple Column
# MAGIC
# MAGIC Transpose rows to columns or columns to rows

# COMMAND ----------

df = sqlContext.createDataFrame([
("a", 1, "m1"), ("a", 1, "m2"), ("a", 2, "m3"),
("a", 3, "m4"), ("b", 4, "m1"), ("b", 1, "m2"),
("b", 2, "m3"), ("c", 3, "m1"), ("c", 4, "m3"),
("c", 5, "m4"), ("d", 6, "m1"), ("d", 1, "m2"),
("d", 2, "m3"), ("d", 3, "m4"), ("d", 4, "m5"),
("e", 4, "m1"), ("e", 5, "m2"), ("e", 1, "m3"),
("e", 1, "m4"), ("e", 1, "m5")], 
("Col", "cnt", "major"))
display(df)

# COMMAND ----------

reshaped_df = df.groupby('Student_id').pivot('Major_subject').max('marks').fillna(0).sort("Student_id")
display(reshaped_df)

# COMMAND ----------

reshaped_df = df.groupby('Col').pivot('major').max('cnt').fillna(0).sort("Col")
display(reshaped_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Unpivot PySpark DataFrame
# MAGIC Unpivot is a reverse operation, we can achieve by rotating column values into rows values. PySpark SQL doesn't have unpivot function hence will use the stack() function.

# COMMAND ----------

from pyspark.sql.functions import expr
 
unpivotexpr= "stack(5,'M1',m1,'M2',m2,'M3',m3,'M4',m4,'M5',m5) as (major,cnt)"

original_df=reshaped_df.select("Col",expr(unpivotexpr)).where("cnt != 0")

display(original_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Another use case example

# COMMAND ----------

df = spark.createDataFrame([("G",4,2,None),("H",None,4,5)],list("AXYZ"))
display(df)

# COMMAND ----------

unpivotExpr="stack(3,'x',x,'y',y,'z',z) as (cln,val)"

df_or=df.select("A",expr(unpivotExpr)).filter("val is not null")

display(df_or)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### multiple Rows to single column - 

# COMMAND ----------

data = [('James','Java'),
  ('James','Python'),
  ('James','Python'),
  ('Anna','PHP'),
  ('Anna','Javascript'),
  ('Maria','Java'),
  ('Maria','C++'),
  ('James','Scala'),
  ('Anna','PHP'),
  ('Anna','HTML')
]
df = spark.createDataFrame(data,schema=["name","languages"])
display(df)

df.createOrReplaceTempView("students")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Array Join 

# COMMAND ----------

from pyspark.sql.functions import array_join, collect_list,col
from pyspark.sql.functions import col
friends_DF = spark.createDataFrame(
    [
        ('jacques', 'nicolas'),
        ('jacques', 'georges'),
        ('jacques', 'francois'),
        ('bob', 'amelie'),
        ('bob', 'zoe'),
    ],
    schema=['username', 'friend'],
)

display(friends_DF)

friends1=friends_DF.groupBy("username").agg(array_join(collect_list("friend"),delimiter=", ").alias("new_columne_name"))
display(friends1)

# COMMAND ----------

friends_DF\
.orderBy('friend', ascending=False)\
.groupBy('username')\
.agg(
    array_join(
        collect_list('friend'),
        delimiter='~!~',
    ).alias('friends')
)\
.show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Array Zip

# COMMAND ----------

from pyspark.sql.functions import arrays_zip
from pyspark.sql.types import Row

df = spark.createDataFrame([(([1, 2, 3], [2, 3, 4]))], ['vals1', 'vals2'])
df.select(arrays_zip(df.vals1, df.vals2).alias('zipped')).collect()
[Row(zipped=[Row(vals1=1, vals2=2), Row(vals1=2, vals2=3), Row(vals1=3, vals2=4)])]

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Single Rows to column / column too rows

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Explode 1
# MAGIC from pyspark.sql.functions import explode
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import explode

arrayData = [
        ('James',['Java','Scala'],{'hair':'black','eye':'brown'}),
        ('Michael',['Spark','Java',None],{'hair':'brown','eye':None}),
        ('Robert',['CSharp',''],{'hair':'red','eye':''}),
        ('Washington',None,None),
        ('Jefferson',['1','2'],{})]
df = spark.createDataFrame(data=arrayData, schema = ['name','knownLanguages','properties'])
display(df)


# COMMAND ----------

df2 = df.select(df.name,explode(df.knownLanguages))
df3 = df.select(df.name,explode(df.properties))

# df4 = df.select(df.name,df.properties,explode(df.knownLanguages))

df2.printSchema()
df2.show()

df3.printSchema()
df3.show()

# COMMAND ----------

df=df2.join(df3,on="name",how="inner")
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Explode Outer

# COMMAND ----------

import spark.implicits._
val arrayData = Seq(
    Row("James",List("Java","Scala"),Map("hair"->"black","eye"->"brown")),
    Row("Michael",List("Spark","Java",null),Map("hair"->"brown","eye"->null)),
    Row("Robert",List("CSharp",""),Map("hair"->"red","eye"->"")),
    Row("Washington",null,null),
    Row("Jefferson",List(),Map())
    )

    val arraySchema = new StructType()
      .add("name",StringType)
      .add("knownLanguages", ArrayType(StringType))
      .add("properties", MapType(StringType,StringType))

    val df = spark.createDataFrame(spark.sparkContext.parallelize(arrayData),arraySchema)
    df.printSchema()
    df.show(false)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Explode Reverse 
# MAGIC
# MAGIC from pyspark.sql.functions import collect_set

# COMMAND ----------

from pyspark.sql import Row
from pyspark.sql.functions import collect_set
rdd = spark.sparkContext.parallelize([Row(user='Bob', word='hello'),
                                      Row(user='Bob', word='world'),
                                      Row(user='Mary', word='Have'),
                                      Row(user='Mary', word='a'),
                                      Row(user='Mary', word='nice'),
                                      Row(user='Mary', word='day')])
df = spark.createDataFrame(rdd)
display(df)

group_user = df.groupBy('user').agg(collect_set('word').alias('words'))
display(group_user)


# COMMAND ----------

data = [('James','Java'),
  ('James','Python'),
  ('James','Python'),
  ('Anna','PHP'),
  ('Anna','Javascript'),
  ('Maria','Java'),
  ('Maria','C++'),
  ('James','Scala'),
  ('Anna','PHP'),
  ('Anna','HTML')
]
df = spark.createDataFrame(data,schema=["name","languages"])
df.printSchema()
df.show()

# COMMAND ----------

from pyspark.sql.functions import collect_list,collect_set

df1=df.groupBy("name").agg(collect_list("languages").alias("list_of_languages"))
df2=df.groupBy("name").agg(collect_set("languages").alias("set_of_languages"))
display(df1)
display(df2)

# COMMAND ----------

# MAGIC %sql
# MAGIC select "1" as id, "a" as source_field
# MAGIC union all
# MAGIC select "1" as id, "b" as source_field
# MAGIC union all
# MAGIC select "1" as id, "b" as source_field

# COMMAND ----------

# MAGIC %sql
# MAGIC with temp as (
# MAGIC select "1" as idd, "a" as source_field
# MAGIC union all
# MAGIC select "1" as idd, "b" as source_field
# MAGIC union all 
# MAGIC select "1" as idd, "b" as source_field
# MAGIC )
# MAGIC select idd, GROUP_CONCAT(source_field)
# MAGIC from temp
# MAGIC group by idd

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Collect First Count
# MAGIC

# COMMAND ----------

data={1:'a',2:'b',3:'c',33:'cc',313:'kk',131:'ll'}
rdd11=sc.parallelize(data)

print(rdd11.collect())
print(rdd11.first())
print(rdd11.count())


# COMMAND ----------

from pyspark.sql.functions import create_map,lit

df = spark.createDataFrame(
    [('A',), ('E',), ('INVALID',)],
    ['col1']
)
dic = {'A': 'S', 'B': 'S', 'E': 'NS'}

map_col = create_map([lit(x) for i in dic.items() for x in i])
df = df.withColumn('col2', map_col[col('col1')])

df.show()

# COMMAND ----------

# dict={1:'a',2:'b',3:'c',33:'cc',313:'kk',131:'ll'}
# outDict={3:'c',33:'cc',313:'kk'}

  new_num = filter(lambda number[i]: number[i] + "#i", number)
    print(new_num)
    i=0
    for i in number:
        s1= ' '.(join(number[i]))+'#'+str('i')
    print(s1)

    rdd=sc.parallelize(data)

rdd2=rdd.map(lambda x: (x,1))
for element in rdd2.collect():
    print(element)

# COMMAND ----------

# MAGIC %md
# MAGIC #####MapTYpe
# MAGIC

# COMMAND ----------


from pyspark.sql.types import StructField, StructType, StringType, MapType
schema = StructType([
    StructField('name', StringType(), True),
    StructField('properties', MapType(StringType(),StringType()),True)
])


# COMMAND ----------

# MAGIC %md
# MAGIC #####  RDD to PysparkDF Convert
# MAGIC

# COMMAND ----------

import pyspark
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()

dept = [("Finance",10),("Marketing",20),("Sales",30),("IT",40)]
rdd = spark.sparkContext.parallelize(dept)

df = rdd.toDF()
df.printSchema()
df.show(truncate=False)

deptColumns = ["dept_name","dept_id"]
df2 = rdd.toDF(deptColumns)
df2.printSchema()
df2.show(truncate=False)

deptDF = spark.createDataFrame(rdd, schema = deptColumns)
deptDF.printSchema()
deptDF.show(truncate=False)

from pyspark.sql.types import StructType,StructField, StringType
deptSchema = StructType([       
    StructField('dept_name', StringType(), True),
    StructField('dept_id', StringType(), True)
])

deptDF1 = spark.createDataFrame(rdd, schema = deptSchema)
deptDF1.printSchema()
deptDF1.show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### PysparkDF to PandasDF
# MAGIC

# COMMAND ----------

import pyspark
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()

data = [("James","","Smith","36636","M",60000),
        ("Michael","Rose","","40288","M",70000),
        ("Robert","","Williams","42114","",400000),
        ("Maria","Anne","Jones","39192","F",500000),
        ("Jen","Mary","Brown","","F",0)]

columns = ["first_name","middle_name","last_name","dob","gender","salary"]
pysparkDF = spark.createDataFrame(data = data, schema = columns)
pysparkDF.printSchema()
pysparkDF.show(truncate=False)

# COMMAND ----------

pandasDF = pysparkDF.toPandas()
print(pandasDF)

# COMMAND ----------

# MAGIC %md
# MAGIC #####PandasDF to PysparkDF
# MAGIC

# COMMAND ----------


import pandas as pd    
data = [['Scott', 50], ['Jeff', 45], ['Thomas', 54],['Ann',34]] 
  
# Create the pandas DataFrame 
pandasDF = pd.DataFrame(data, columns = ['Name', 'Age']) 
  
# print dataframe. 
print(pandasDF)


sparkDF=spark.createDataFrame(pandasDF) 
sparkDF.printSchema()
sparkDF.show()

#sparkDF=spark.createDataFrame(pandasDF.astype(str)) 
from pyspark.sql.types import StructType,StructField, StringType, IntegerType
mySchema = StructType([ StructField("First Name", StringType(), True)\
                       ,StructField("Age", IntegerType(), True)])

sparkDF2 = spark.createDataFrame(pandasDF,schema=mySchema)
sparkDF2.printSchema()
sparkDF2.show()

# Enable Apache Arrow to convert Pandas to PySpark DataFrame
spark.conf.set("spark.sql.execution.arrow.enabled","true")
sparkDF2=spark.createDataFrame(pandasDF) 
sparkDF2.printSchema()
sparkDF2.show()

#Convert PySpark DataFrame to Pandas
pandasDF2=sparkDF2.select("*").toPandas
print(pandasDF2)



# COMMAND ----------

rdd = spark.sparkContext.parallelize(range(0,20))
print("From local[5] : "+str(rdd.getNumPartitions()))

# COMMAND ----------

spark.conf.get("spark.sql.shuffle.partitions")

# COMMAND ----------

spark.conf.get("spark.default.parallelism")

# COMMAND ----------


spark.conf.set("spark.default.parallelism",100)
# sqlContext.setConf("spark.default.parallelism", "100")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### RDD

# COMMAND ----------


# Create spark session with local[5]
rdd = spark.sparkContext.parallelize(range(0,20))
print("From local[5] : "+str(rdd.getNumPartitions()))

# Use parallelize with 6 partitions
rdd1 = spark.sparkContext.parallelize(range(0,25), 6)
print("parallelize : "+str(rdd1.getNumPartitions()))

rddFromFile = spark.sparkContext.textFile("dbfs:/user/hive/warehouse/emp_san_data",10)
print("TextFile : "+str(rddFromFile.getNumPartitions()))

# COMMAND ----------

rdd1.saveAsTextFile("dbfs:/user/hive/warehouse/san_temp_partition")

# COMMAND ----------

rdd2 = rdd1.repartition(4)
print("Repartition size : "+str(rdd2.getNumPartitions()))
rdd2.saveAsTextFile("/tmp/re-partition")

# COMMAND ----------

# Using coalesce()
rdd3 = rdd1.coalesce(4)
print("Repartition size : "+str(rdd3.getNumPartitions()))

# COMMAND ----------

spark.conf.get("spark.sql.shuffle.partitions")

# COMMAND ----------

# MAGIC %fs rm  "dbfs:/user/hive/warehouse/san_temp_partition"

# COMMAND ----------

# MAGIC %md
# MAGIC #####DF coalesce repartition
# MAGIC
# MAGIC

# COMMAND ----------

# DBTITLE 1,DF by default df 8 partitions
import pyspark
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName('SparkByExamples.com') \
        .master("local[5]").getOrCreate()

df=spark.range(0,20)
print(df.rdd.getNumPartitions())

# COMMAND ----------

df2 = df.repartition(9)
print(df2.rdd.getNumPartitions())

# COMMAND ----------

# DataFrame coalesce
df3 = df.coalesce(2)
print(df3.rdd.getNumPartitions())

# COMMAND ----------

# Default shuffle partition count
df4 = df.groupBy("id").count()
print(df4.rdd.getNumPartitions())

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Date Dim

# COMMAND ----------

import pandas as pd
dt_from = pd.date_range(start='1/1/1980', end='12/31/2050', freq='MS')
dt_to   = pd.date_range(start='1/1/1980', end='12/31/2050', freq='M')
df = pd.DataFrame({'from':dt_from, 'to':dt_to,'no_of_days':(dt_to-dt_from).days})

sparkDF=spark.createDataFrame(df) 
sparkDF.createOrReplaceTempView("date_dim")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from date_dim

# COMMAND ----------

# MAGIC %md
# MAGIC ##### arrow enabled
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC
# MAGIC pandasDF = pd.DataFrame(data, columns = ['Name', 'Age']) 
# MAGIC
# MAGIC sparkDF=spark.createDataFrame(pandasDF) 
# MAGIC
# MAGIC ###### Pyspark to Pandas Conversion
# MAGIC
# MAGIC pandasDF2=sparkDF2.select("*").toPandas

# COMMAND ----------

import pandas as pd    
data = [['Scott', 50], ['Jeff', 45], ['Thomas', 54],['Ann',34]] 
  
# Create the pandas DataFrame 
pandasDF = pd.DataFrame(data, columns = ['Name', 'Age']) 
  
# print(pandasDF)

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .master("local[1]") \
    .appName("SparkByExamples.com") \
    .getOrCreate()

sparkDF=spark.createDataFrame(pandasDF) 
display(sparkDF)

# COMMAND ----------

from pyspark.sql.types import StructType,StructField, StringType, IntegerType
mySchema = StructType([ StructField("First Name", StringType(), True)\
                       ,StructField("Age", IntegerType(), True)])

sparkDF2 = spark.createDataFrame(pandasDF,schema=mySchema)

spark.conf.set("spark.sql.execution.arrow.enabled","true")
spark.conf.set("spark.sql.execution.arrow.pyspark.fallback.enabled","true")

pandasDF2=sparkDF2.select("*").toPandas
print(pandasDF2)

test=spark.conf.get("spark.sql.execution.arrow.enabled")
print(test)

test123=spark.conf.get("spark.sql.execution.arrow.pyspark.fallback.enabled")
print(test123)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Add months
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import col,expr

data=[("2019-01-23",1),("2019-06-24",2),("2019-09-20",3)]

spark.createDataFrame(data).toDF("date","increment") \
    .select(col("date"),col("increment"), \
      expr("add_months(to_date(date,'yyyy-MM-dd'),cast(increment as int))").alias("inc_date")) \
    .show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Add-New-Column.

# COMMAND ----------

data = [('James','Smith','M',3000),
  ('Anna','Rose','F',4100),
  ('Robert','Williams','M',6200), 
]

columns = ["firstname","lastname","gender","salary"]
df = spark.createDataFrame(data=data, schema = columns)
df.show()


# COMMAND ----------

if 'salary1' not in df.columns:
    print("aa")
    
# Add new constanct column
from pyspark.sql.functions import lit
df.withColumn("bonus_percent", lit(0.3)) \
  .show()


#Add column from existing column
df.withColumn("bonus_amount", df.salary*0.3) \
  .show()

#Add column by concatinating existing columns
from pyspark.sql.functions import concat_ws
df.withColumn("name", concat_ws(",","firstname",'lastname')) \
  .show()

#Add current date
from pyspark.sql.functions import current_date
df.withColumn("current_date", current_date()) \
  .show()


from pyspark.sql.functions import when
df.withColumn("grade", \
   when((df.salary < 4000), lit("A")) \
     .when((df.salary >= 4000) & (df.salary <= 5000), lit("B")) \
     .otherwise(lit("C")) \
  ).show()
    
# Add column using select
df.select("firstname","salary", lit(0.3).alias("bonus")).show()
df.select("firstname","salary", lit(df.salary * 0.3).alias("bonus_amount")).show()
df.select("firstname","salary", current_date().alias("today_date")).show()




# COMMAND ----------


#Add columns using SQL
df.createOrReplaceTempView("PER")
spark.sql("select firstname,salary, '0.3' as bonus from PER").show()
spark.sql("select firstname,salary, salary * 0.3 as bonus_amount from PER").show()
spark.sql("select firstname,salary, current_date() as today_date from PER").show()
spark.sql("select firstname,salary, " +
          "case salary when salary < 4000 then 'A' "+
          "else 'B' END as grade from PER").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Aggregate Functions

# COMMAND ----------


import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.functions import approx_count_distinct,collect_list
from pyspark.sql.functions import collect_set,sum,avg,max,countDistinct,count
from pyspark.sql.functions import first, last, kurtosis, min, mean, skewness
from pyspark.sql.functions import stddev, stddev_samp, stddev_pop, sumDistinct
from pyspark.sql.functions import variance,var_samp,  var_pop

spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()

simpleData = [("James", "Sales", 3000),
    ("Michael", "Sales", 4600),
    ("Robert", "Sales", 4100),
    ("Maria", "Finance", 3000),
    ("James", "Sales", 3000),
    ("Scott", "Finance", 3300),
    ("Jen", "Finance", 3900),
    ("Jeff", "Marketing", 3000),
    ("Kumar", "Marketing", 2000),
    ("Saif", "Sales", 4100)
  ]
schema = ["employee_name", "department", "salary"]
  
  
df = spark.createDataFrame(data=simpleData, schema = schema)
df.printSchema()
df.show(truncate=False)


# COMMAND ----------


print("approx_count_distinct: " + \
      str(df.select(approx_count_distinct("salary")).collect()[0][0]))
print("avg: " + str(df.select(avg("salary")).collect()[0][0]))

df.select(collect_list("salary")).show(truncate=False)

df.select(collect_set("salary")).show(truncate=False)

df2 = df.select(countDistinct("department", "salary"))
df2.show(truncate=False)
print("Distinct Count of Department &amp; Salary: "+str(df2.collect()[0][0]))

print("count: "+str(df.select(count("salary")).collect()[0]))
df.select(first("salary")).show(truncate=False)
df.select(last("salary")).show(truncate=False)
df.select(kurtosis("salary")).show(truncate=False)
df.select(max("salary")).show(truncate=False)
df.select(min("salary")).show(truncate=False)
df.select(mean("salary")).show(truncate=False)
df.select(skewness("salary")).show(truncate=False)
df.select(stddev("salary"), stddev_samp("salary"), \
    stddev_pop("salary")).show(truncate=False)
df.select(sum("salary")).show(truncate=False)
df.select(sumDistinct("salary")).show(truncate=False)
df.select(variance("salary"),var_samp("salary"),var_pop("salary")) \
  .show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Array-string

# COMMAND ----------

import pyspark
from pyspark.sql import SparkSession
spark = SparkSession.builder.master("local[1]") \
                    .appName('SparkByExamples.com') \
                    .getOrCreate()

columns = ["name","languagesAtSchool","currentState"]
data = [("James,,Smith",["Java","Scala","C++"],"CA"), \
    ("Michael,Rose,",["Spark","Java","C++"],"NJ"), \
    ("Robert,,Williams",["CSharp","VB"],"NV")]

df = spark.createDataFrame(data=data,schema=columns)
df.printSchema()
df.show(truncate=False)


# COMMAND ----------

# MAGIC %md
# MAGIC  concat_ws("-",col("languagesAtSchool"))  -- the - is separator or delimiter
# MAGIC

# COMMAND ----------


from pyspark.sql.functions import col, concat_ws
df2 = df.withColumn("languagesAtSchool",   concat_ws("-",col("languagesAtSchool")))
df2.printSchema()
df2.show(truncate=False)


df.createOrReplaceTempView("ARRAY_STRING")
spark.sql("select name, concat_ws(',',languagesAtSchool) as languagesAtSchool,currentState from ARRAY_STRING").show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Array-Ops types
# MAGIC

# COMMAND ----------


from pyspark.sql import SparkSession
from pyspark.sql.types import StringType, ArrayType,StructType,StructField
spark = SparkSession.builder \
                    .appName('SparkByExamples.com') \
                    .getOrCreate()


arrayCol = ArrayType(StringType(),False)

data = [
 ("James,,Smith",["Java","Scala","C++"],["Spark","Java"],"OH","CA"),
 ("Michael,Rose,",["Spark","Java","C++"],["Spark","Java"],"NY","NJ"),
 ("Robert,,Williams",["CSharp","VB"],["Spark","Python"],"UT","NV")
]

schema = StructType([ 
    StructField("name",StringType(),True), 
    StructField("languagesAtSchool",ArrayType(StringType()),True), 
    StructField("languagesAtWork",ArrayType(StringType()),True), 
    StructField("currentState", StringType(), True), 
    StructField("previousState", StringType(), True) 
  ])

df = spark.createDataFrame(data=data,schema=schema)
df.printSchema()
df.show()


# COMMAND ----------


from pyspark.sql.functions import explode
from pyspark.sql.functions import split
from pyspark.sql.functions import array
from pyspark.sql.functions import array_contains

df.select(df.name,explode(df.languagesAtSchool)).show()
df.select(split(df.name,",").alias("nameAsArray")).show()
df.select(df.name,array(df.currentState,df.previousState).alias("States")).show()
df.select(df.name,array_contains(df.languagesAtSchool,"Java")
    .alias("array_contains")).show()

# COMMAND ----------

# MAGIC %md
# MAGIC #####Broadcast

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC states = {"NY":"New York", "CA":"California", "FL":"Florida"}
# MAGIC
# MAGIC broadcastStates = sc.broadcast(states)
# MAGIC
# MAGIC broadcastStates = spark.sparkContext.broadcast(states)
# MAGIC

# COMMAND ----------


states = {"NY":"New York", "CA":"California", "FL":"Florida"}

broadcastStates = spark.sparkContext.broadcast(states)

data = [("James","Smith","USA","CA"),
    ("Michael","Rose","USA","NY"),
    ("Robert","Williams","USA","CA"),
    ("Maria","Jones","USA","FL")
  ]

columns = ["firstname","lastname","country","state"]
df = spark.createDataFrame(data = data, schema = columns)
df.printSchema()
df.show(truncate=False)


# COMMAND ----------

def state_convert(code):
    return broadcastStates.value[code]

# COMMAND ----------

result = df.rdd.map(lambda x: (x[0],x[1],x[2],state_convert(x[3]))).toDF(columns)
result.show(truncate=False)

filteDf= df.where((df['state'].isin(broadcastStates.value)))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Pyspark-Type Casting-column
# MAGIC
# MAGIC string to boolean
# MAGIC
# MAGIC df_dcn=df_dcn.withColumn("DCN_Priority_Flag",   lit("Y").cast(StringType()))
# MAGIC
# MAGIC Wrong Date format for last row= interpreted as NULL

# COMMAND ----------


simpleData = [("James",34,"2006-01-01","true","M",3000.60),
    ("Michael",33,"1980-01-10","true","F",3300.80),
    ("Robert",37,"06-01-1992","false","M",5000.50)
  ]

columns = ["firstname","age","jobStartDate","isGraduated","gender","salary"]
df = spark.createDataFrame(data = simpleData, schema = columns)
df.printSchema()
df.show(truncate=False)


# COMMAND ----------


from pyspark.sql.functions import col
from pyspark.sql.types import StringType,BooleanType,DateType

df2 = df.withColumn("age",col("age").cast(StringType())) \
    .withColumn("isGraduated",col("isGraduated").cast(BooleanType())) \
    .withColumn("jobStartDate",col("jobStartDate").cast(DateType()))
df2.printSchema()

df3 = df2.selectExpr("cast(age as int) age",
    "cast(isGraduated as string) isGraduated",
    "cast(jobStartDate as string) jobStartDate")
df3.printSchema()
df3.show(truncate=False)

df3.createOrReplaceTempView("CastExample")
df4 = spark.sql("SELECT STRING(age),BOOLEAN(isGraduated),DATE(jobStartDate) from CastExample")
df4.printSchema()
df4.show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Change -String-Double

# COMMAND ----------


from pyspark.sql import SparkSession
from pyspark.sql.types import DoubleType, IntegerType
# Create SparkSession
spark = SparkSession.builder \
          .appName('SparkByExamples.com') \
          .getOrCreate()

simpleData = [("James","34","true","M","3000.6089"),
    ("Michael","33","true","F","3300.8067"),
    ("Robert","37","false","M","5000.5034")
  ]

columns = ["firstname","age","isGraduated","gender","salary"]
df = spark.createDataFrame(data = simpleData, schema = columns)
df.printSchema()
df.show(truncate=False)


# COMMAND ----------


from pyspark.sql.functions import col,round,expr
df.withColumn("salary",df.salary.cast('double')).printSchema()    
df.withColumn("salary",df.salary.cast(DoubleType())).printSchema()    
df.withColumn("salary",col("salary").cast('double')).printSchema()    

# df.withColumn("salary",round(df.salary.cast(DoubleType()),2)).show(truncate=False).printSchema()    
df.selectExpr("firstname","isGraduated","cast(salary as double) salary").printSchema()    

df.createOrReplaceTempView("CastExample")
spark.sql("SELECT firstname,isGraduated,DOUBLE(salary) as salary from CastExample").printSchema()


#df.select("firstname",expr(df.age),"isGraduated",col("salary").cast('float').alias("salary")).show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### collect

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC
# MAGIC deptDF.collect() returns Array of Row type.
# MAGIC
# MAGIC deptDF.collect()[0] returns the first element in an array (1st row).
# MAGIC
# MAGIC deptDF.collect[0][0] returns the value of the first row & first column.

# COMMAND ----------

import pyspark
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()

dept = [("Finance",10), 
    ("Marketing",20), 
    ("Sales",30), 
    ("IT",40)   ]
deptColumns = ["dept_name","dept_id"]
deptDF = spark.createDataFrame(data=dept, schema = deptColumns)
deptDF.printSchema()
deptDF.show(truncate=False)


# COMMAND ----------


dataCollect = deptDF.collect()

print(dataCollect)

dataCollect2 = deptDF.select("dept_name").collect()
print(dataCollect2)

for row in dataCollect:
    print(row['dept_name'] + "," +str(row['dept_id']))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Column-Functions

# COMMAND ----------

from pyspark.sql import SparkSession
spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()

data=[("James","Bond","100",None),
      ("Ann","Varsa","200",'F'),
      ("Tom Cruise","XXX","400",''),
      ("Tom Brand",None,"400",'M')] 
columns=["fname","lname","id","gender"]
df=spark.createDataFrame(data,columns)

# COMMAND ----------

#alias
from pyspark.sql.functions import expr
df.select(df.fname.alias("first_name"), \
          df.lname.alias("last_name"), \
          expr(" fname ||','|| lname").alias("fullName") \
   ).show()

#asc, desc
df.sort(df.fname.asc()).show()
df.sort(df.fname.desc()).show()


# COMMAND ----------

#cast
df.select(df.fname,df.id.cast("int")).printSchema()

#between
df.filter(df.id.between(100,300)).show()

#contains
df.filter(df.fname.contains("Cruise")).show()

#startswith, endswith()
df.filter(df.fname.startswith("T")).show()
df.filter(df.fname.endswith("Cruise")).show()

#eqNullSafe

#isNull & isNotNull
df.filter(df.lname.isNull()).show()
df.filter(df.lname.isNotNull()).show()

#like , rlike
df.select(df.fname,df.lname,df.id) \
  .filter(df.fname.like("%om")) 

#over

#substr
df.select(df.fname.substr(1,2).alias("substr")).show()

#when & otherwise
from pyspark.sql.functions import when
df.select(df.fname,df.lname,when(df.gender=="M","Male") \
              .when(df.gender=="F","Female") \
              .when(df.gender==None ,"") \
              .otherwise(df.gender).alias("new_gender") \
    ).show()

#isin
li=["100","200"]
df.select(df.fname,df.lname,df.id) \
  .filter(df.id.isin(li)) \
  .show()


# COMMAND ----------


from pyspark.sql.types import StructType,StructField,StringType,ArrayType,MapType
data=[(("James","Bond"),["Java","C#"],{'hair':'black','eye':'brown'}),
      (("Ann","Varsa"),[".NET","Python"],{'hair':'brown','eye':'black'}),
      (("Tom Cruise",""),["Python","Scala"],{'hair':'red','eye':'grey'}),
      (("Tom Brand",None),["Perl","Ruby"],{'hair':'black','eye':'blue'})]

schema = StructType([
        StructField('name', StructType([
            StructField('fname', StringType(), True),
            StructField('lname', StringType(), True)])),
        StructField('languages', ArrayType(StringType()),True),
        StructField('properties', MapType(StringType(),StringType()),True)
     ])
df=spark.createDataFrame(data,schema)
df.printSchema()
#getItem()
df.select(df.languages.getItem(1)).show()

df.select(df.properties.getItem("hair")).show()

#getField from Struct or Map
df.select(df.properties.getField("hair")).show()

df.select(df.name.getField("fname")).show()

#dropFields
#from pyspark.sql.functions import col
#df.withColumn("name1",col("name").dropFields(["fname"])).show()

#withField
#from pyspark.sql.functions import lit
#df.withColumn("name",df.name.withField("fname",lit("AA"))).show()

#from pyspark.sql import Row
#from pyspark.sql.functions import lit
#df = spark.createDataFrame([Row(a=Row(b=1, c=2))])
#df.withColumn('a', df['a'].withField('b', lit(3))).select('a.b').show()
        
#from pyspark.sql import Row
#from pyspark.sql.functions import col, lit
#df = spark.createDataFrame([
#Row(a=Row(b=1, c=2, d=3, e=Row(f=4, g=5, h=6)))])
#df.withColumn('a', df['a'].dropFields('b')).show()

# COMMAND ----------

from pyspark.sql import SparkSession,Row
spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()

data=[("James",23),("Ann",40)]
df=spark.createDataFrame(data).toDF("name.fname","gender")
df.printSchema()
df.show()

from pyspark.sql.functions import col
df.select(col("`name.fname`")).show()
df.select(df["`name.fname`"]).show()
df.withColumn("new_col",col("`name.fname`").substr(1,2)).show()
df.filter(col("`name.fname`").startswith("J")).show()
new_cols=(column.replace('.', '_') for column in df.columns)
df2 = df.toDF(*new_cols)
df2.show()


# Using DataFrame object
df.select(df.gender).show()
df.select(df["gender"]).show()
#Accessing column name with dot (with backticks)
df.select(df["`name.fname`"]).show()

#Using SQL col() function
from pyspark.sql.functions import col
df.select(col("gender")).show()
#Accessing column name with dot (with backticks)
df.select(col("`name.fname`")).show()

#Access struct column
data=[Row(name="James",prop=Row(hair="black",eye="blue")),
      Row(name="Ann",prop=Row(hair="grey",eye="black"))]
df=spark.createDataFrame(data)
df.printSchema()

df.select(df.prop.hair).show()
df.select(df["prop.hair"]).show()
df.select(col("prop.hair")).show()
df.select(col("prop.*")).show()

# Column operators
data=[(100,2,1),(200,3,4),(300,4,4)]
df=spark.createDataFrame(data).toDF("col1","col2","col3")
df.select(df.col1 + df.col2).show()
df.select(df.col1 - df.col2).show() 
df.select(df.col1 * df.col2).show()
df.select(df.col1 / df.col2).show()
df.select(df.col1 % df.col2).show()

df.select(df.col2 > df.col3).show()
df.select(df.col2 < df.col3).show()
df.select(df.col2 == df.col3).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Explode 2
# MAGIC
# MAGIC creating new columns with explode by mapping keys of properties map
# MAGIC
# MAGIC with explode you can create new rows/columns
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Convert-MAP-to-COLUMN
# MAGIC
# MAGIC df3=df.rdd.map(lambda x:(x.name,x.properties["hair"],x.properties["eye"])).toDF(["name","hair","eye"])
# MAGIC

# COMMAND ----------

from pyspark.sql import SparkSession
spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()

dataDictionary = [
        ('James',{'hair':'black','eye':'brown'}),
        ('Michael',{'hair':'brown','eye':None}),
        ('Robert',{'hair':'red','eye':'black'}),
        ('Washington',{'hair':'grey','eye':'grey'}),
        ('Jefferson',{'hair':'brown','eye':''})
        ]

df = spark.createDataFrame(data=dataDictionary, schema = ['name','properties'])
display(df)

# COMMAND ----------

df3=df.rdd.map(lambda x:(x.name,x.properties["hair"],x.properties["eye"])).toDF(["name","hair","eye"])
df3.printSchema()
df3.show()

df.withColumn("hair",df.properties.getItem("hair")) \
  .withColumn("eye",df.properties.getItem("eye")) \
  .drop("properties") \
  .show()

df.withColumn("hair",df.properties["hair"]) \
  .withColumn("eye",df.properties["eye"]) \
  .drop("properties") \
  .show()

# COMMAND ----------

from pyspark.sql.functions import explode,map_keys,col
keysDF = df.select(explode(map_keys(df.properties))).distinct()
keysList = keysDF.rdd.map(lambda x:x[0]).collect()
keyCols = list(map(lambda x: col("properties").getItem(x).alias(str(x)), keysList))
df.select(df.name, *keyCols).show()

# COMMAND ----------

from pyspark.sql.functions import explode,map_keys,col

keysDF = df.select(explode(map_keys(df.properties))).distinct()
keysList = keysDF.rdd.map(lambda x:x[0]).collect()
keyCols = list(map(lambda x: col("properties").getItem(x).alias(str(x)), keysList))
df.select(df.name, *keyCols).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Convert COLUMN-to-MAP

# COMMAND ----------


from pyspark.sql import SparkSession
from pyspark.sql.types import StructType,StructField, StringType, IntegerType

spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()
data = [ ("36636","Finance",3000,"USA"), 
    ("40288","Finance",5000,"IND"), 
    ("42114","Sales",3900,"USA"), 
    ("39192","Marketing",2500,"CAN"), 
    ("34534","Sales",6500,"USA") ]
schema = StructType([
     StructField('id', StringType(), True),
     StructField('dept', StringType(), True),
     StructField('salary', IntegerType(), True),
     StructField('location', StringType(), True)
     ])

df = spark.createDataFrame(data=data,schema=schema)
df.printSchema()
df.show(truncate=False)


# COMMAND ----------

# MAGIC %md
# MAGIC #####Create_Map

# COMMAND ----------


#Convert scolumns to Map
from pyspark.sql.functions import col,lit,create_map
df = df.withColumn("propertiesMap",create_map(
        lit("salary"),col("salary"),
        lit("location"),col("location")
        )).drop("salary","location")
df.printSchema()
df.show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ##### Count Vs countDistinct
# MAGIC

# COMMAND ----------

from pyspark.sql import SparkSession
spark = SparkSession.builder \
         .appName('SparkByExamples.com') \
         .getOrCreate()

data = [("James", "Sales", 3000),
    ("Michael", "Sales", 4600),
    ("Robert", "Sales", 4100),
    ("Maria", "Finance", 3000),
    ("James", "Sales", 3000),
    ("Scott", "Finance", 3300),
    ("Jen", "Finance", 3900),
    ("Jeff", "Marketing", 3000),
    ("Kumar", "Marketing", 2000),
    ("Saif", "Sales", 4100)
  ]
columns = ["Name","Dept","Salary"]
df = spark.createDataFrame(data=data,schema=columns)
df.distinct().show()
print("Distinct Count: " + str(df.distinct().count()))

# COMMAND ----------


# Using countDistrinct() -- james and jeff are duplicate
from pyspark.sql.functions import countDistinct

df2=df.select(countDistinct("Dept","Salary"))
df2.show()

print("Distinct Count of Department &amp; Salary: "+ str(df2.collect()[0][0]))

df.createOrReplaceTempView("PERSON")
spark.sql("select distinct(count(*)) from PERSON").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Distinct
# MAGIC
# MAGIC PySpark distinct() function is used to drop/remove the duplicate rows (all columns) from DataFrame and dropDuplicates() is used to drop rows based on selected (one or multiple) columns

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Drop

# COMMAND ----------


# Import pySpark
from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# Create SparkSession
spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()

# Prepare Data
data = [("James", "Sales", 3000), \
    ("Michael", "Sales", 4600), \
    ("Robert", "Sales", 4100), \
    ("Maria", "Finance", 3000), \
    ("James", "Sales", 3000), \
    ("Scott", "Finance", 3300), \
    ("Jen", "Finance", 3900), \
    ("Jeff", "Marketing", 3000), \
    ("Kumar", "Marketing", 2000), \
    ("Saif", "Sales", 4100) \
  ]

# Create DataFrame
columns= ["employee_name", "department", "salary"]
df = spark.createDataFrame(data = data, schema = columns)
df.printSchema()
df.show(truncate=False)


# COMMAND ----------

distinctDF = df.distinct()
print("Distinct count: "+str(distinctDF.count()))
distinctDF.show(truncate=False)


# COMMAND ----------

df2 = df.dropDuplicates()
print("Distinct count: "+str(df2.count()))
df2.show(truncate=False)

# COMMAND ----------

dropDisDF = df.dropDuplicates(["department","salary"])
print("Distinct count of department & salary : "+str(dropDisDF.count()))
dropDisDF.show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### File Traversal
# MAGIC

# COMMAND ----------

import os
from datetime import datetime
path = '/dbfs/projects/cafdb/config/sql/publish/final_queries/'

fdpaths = [path+"/"+fd for fd in os.listdir(path)]
print(" file_path " + " create_date " + " modified_date ")
for fdpath in fdpaths:
  statinfo = os.stat(fdpath)
  create_date = datetime.fromtimestamp(statinfo.st_ctime)
  modified_date = datetime.fromtimestamp(statinfo.st_mtime)
  print(fdpath, create_date, modified_date)

# COMMAND ----------

# MAGIC %md
# MAGIC #####ROW

# COMMAND ----------

from pyspark.sql import Row
row=Row("James",40)
print(row[0] +","+str(row[1]))
# print(row)
# type(row)

# COMMAND ----------


from pyspark.sql import SparkSession, Row

row=Row("James",40)
print(row[0] +","+str(row[1]))
row2=Row(name="Alice", age=11)
print(row2.name)

Person = Row("name", "age")
p1=Person("James", 40)
p2=Person("Alice", 35)
print(p1.name +","+p2.name)

#PySpark Example
spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()

data = [Row(name="James,,Smith",lang=["Java","Scala","C++"],state="CA"), 
    Row(name="Michael,Rose,",lang=["Spark","Java","C++"],state="NJ"),
    Row(name="Robert,,Williams",lang=["CSharp","VB"],state="NV")]

#RDD Example 1
rdd=spark.sparkContext.parallelize(data)
collData=rdd.collect()
print(collData)
for row in collData:
    print(row.name + "," +str(row.lang))

# RDD Example 2
Person=Row("name","lang","state")
data = [Person("James,,Smith",["Java","Scala","C++"],"CA"), 
    Person("Michael,Rose,",["Spark","Java","C++"],"NJ"),
    Person("Robert,,Williams",["CSharp","VB"],"NV")]
rdd=spark.sparkContext.parallelize(data)
collData=rdd.collect()
print(collData)
for person in collData:
    print(person.name + "," +str(person.lang))

#DataFrame Example 1
columns = ["name","languagesAtSchool","currentState"]
df=spark.createDataFrame(data)
df.printSchema()
df.show()

collData=df.collect()
print(collData)
for row in collData:
    print(row.name + "," +str(row.lang))
    
#DataFrame Example 2
columns = ["name","languagesAtSchool","currentState"]
df=spark.createDataFrame(data).toDF(*columns)
df.printSchema()


# COMMAND ----------

# MAGIC %md
# MAGIC #####Select

# COMMAND ----------


import pyspark
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()

data = [("James","Smith","USA","CA"),
    ("Michael","Rose","USA","NY"),
    ("Robert","Williams","USA","CA"),
    ("Maria","Jones","USA","FL")
  ]

columns = ["firstname","lastname","country","state"]
df = spark.createDataFrame(data = data, schema = columns)
df.show(truncate=False)

df.select("firstname").show()

df.select("firstname","lastname").show()

#Using Dataframe object name
df.select(df.firstname,df.lastname).show()

# Using col function
from pyspark.sql.functions import col
df.select(col("firstname"),col("lastname")).show()

data = [(("James",None,"Smith"),"OH","M"),
        (("Anna","Rose",""),"NY","F"),
        (("Julia","","Williams"),"OH","F"),
        (("Maria","Anne","Jones"),"NY","M"),
        (("Jen","Mary","Brown"),"NY","M"),
        (("Mike","Mary","Williams"),"OH","M")
        ]

from pyspark.sql.types import StructType,StructField, StringType        
schema = StructType([
    StructField('name', StructType([
         StructField('firstname', StringType(), True),
         StructField('middlename', StringType(), True),
         StructField('lastname', StringType(), True)
         ])),
     StructField('state', StringType(), True),
     StructField('gender', StringType(), True)
     ])

df2 = spark.createDataFrame(data = data, schema = schema)
df2.printSchema()
df2.show(truncate=False) # shows all columns

df2.select("name").show(truncate=False)
df2.select("name.firstname","name.lastname").show(truncate=False)
df2.select("name.*").show(truncate=False)


# COMMAND ----------

a1=df2.collect()
print(a1)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Join
# MAGIC

# COMMAND ----------


emp = [(1,"Smith",-1,"2018","10","M",3000), \
    (2,"Rose",1,"2010","20","M",4000), \
    (3,"Williams",1,"2010","10","M",1000), \
    (4,"Jones",2,"2005","10","F",2000), \
    (5,"Brown",2,"2010","40","",-1), \
      (6,"Brown",2,"2010","50","",-1) \
  ]
empColumns = ["emp_id","name","superior_emp_id","year_joined", \
       "emp_dept_id","gender","salary"]

empDF = spark.createDataFrame(data=emp, schema = empColumns)
# empDF.printSchema()
empDF.show(truncate=False)

dept = [("Finance",10), \
    ("Marketing",20), \
    ("Sales",30), \
    ("IT",40) \
  ]
deptColumns = ["dept_name","dept_id"]
deptDF = spark.createDataFrame(data=dept, schema = deptColumns)
# deptDF.printSchema()
deptDF.show(truncate=False)


# COMMAND ----------

empDF.join(deptDF,empDF.emp_dept_id ==  deptDF.dept_id,"leftanti") \
     .show(truncate=False)


# outer, full, fullouter, full_outer
# left, leftouter, left_outer
# right, rightouter, right_outer
# anti, leftanti, left_anti
# semi, leftsemi, left_semi

# COMMAND ----------

empDF.join(deptDF,empDF.emp_dept_id ==  deptDF.dept_id,"inner") \
     .show(truncate=False)


# COMMAND ----------

# MAGIC %md
# MAGIC #####withColumn
# MAGIC

# COMMAND ----------


import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit
from pyspark.sql.types import StructType, StructField, StringType,IntegerType

spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()

data = [('James','','Smith','1991-04-01','M',3000),
  ('Michael','Rose','','2000-05-19','M',4000),
  ('Robert','','Williams','1978-09-05','M',4000),
  ('Maria','Anne','Jones','1967-12-01','F',4000),
  ('Jen','Mary','Brown','1980-02-17','F',-1)
]

columns = ["firstname","middlename","lastname","dob","gender","salary"]
df = spark.createDataFrame(data=data, schema = columns)
df.printSchema()
df.show(truncate=False)

df2 = df.withColumn("salary",col("salary").cast("Integer"))
df2.printSchema()
df2.show(truncate=False)

df3 = df.withColumn("salary",col("salary")*100)
df3.printSchema()
df3.show(truncate=False) 

df4 = df.withColumn("CopiedColumn",col("salary")* -1)
df4.printSchema()

df5 = df.withColumn("Country", lit("USA"))
df5.printSchema()

df6 = df.withColumn("Country", lit("USA")) \
   .withColumn("anotherColumn",lit("anotherValue"))
df6.printSchema()

df.withColumnRenamed("gender","sex") \
  .show(truncate=False) 
  
df4.drop("CopiedColumn") \
.show(truncate=False) 


# COMMAND ----------

# MAGIC %md
# MAGIC ##### When /case statement
# MAGIC
# MAGIC

# COMMAND ----------

data = [('James','Smith','M',3000),('Anna','Rose','F',4100),
  ('Robert','Williams','NA',6200),(None,'Rob','F',6200) 
]

columns = ["firstname","lastname","gender","salary"]
df = spark.createDataFrame(data=data, schema = columns)
df.show()

df2=df.withColumn("salary", df.salary*3)
df2.show()


# COMMAND ----------


from pyspark.sql.functions import when

df3 = df.withColumn("gender", when(df.gender == "M","Male") \
      .when(df.gender == "F","Female") \
      .otherwise(df.gender))
df3.show()

df4=df.withColumn("salary",df.salary.cast("String"))
df4.printSchema()
df4.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Where / filter

# COMMAND ----------


from pyspark.sql.types import StructType,StructField 
from pyspark.sql.types import StringType, IntegerType, ArrayType
data = [
    (("James","","Smith"),["Java","Scala","C++"],"OH","M"),
    (("Anna","Rose",""),["Spark","Java","C++"],"NY","F"),
    (("Julia","","Williams"),["CSharp","VB"],"OH","F"),
    (("Maria","Anne","Jones"),["CSharp","VB"],"NY","M"),
    (("Jen","Mary","Brown"),["CSharp","VB"],"NY","M"),
    (("Mike","Mary","Williams"),["Python","VB"],"OH","M")
 ]
        
schema = StructType([
     StructField('name', StructType([
        StructField('firstname', StringType(), True),
        StructField('middlename', StringType(), True),
         StructField('lastname', StringType(), True)
     ])),
     StructField('languages', ArrayType(StringType()), True),
     StructField('state', StringType(), True),
     StructField('gender', StringType(), True)
 ])

df = spark.createDataFrame(data = data, schema = schema)
df.printSchema()
df.show(truncate=False)


# COMMAND ----------

df.filter( (df.state  == "OH") & (df.gender  == "M") ).show(truncate=False)

# COMMAND ----------

li=["OH","CA","DE"]
df.filter(df.state.isin(li)).show()

# COMMAND ----------

df.filter(~df.state.isin(li)).show()
df.filter(df.state.isin(li)==False).show()

# COMMAND ----------

# Using startswith
df.filter(df.state.startswith("N")).show()

#using endswith
df.filter(df.state.endswith("H")).show()

#contains
df.filter(df.state.contains("H")).show()

# COMMAND ----------

from pyspark.sql.functions import array_contains
df.filter(array_contains(df.languages,"Java")) \
    .show(truncate=False) 


# COMMAND ----------


data2 = [(2,"Michael Rose"),(3,"Robert Williams"),
     (4,"Rames Rose"),(5,"Rames rose")
  ]
df2 = spark.createDataFrame(data = data2, schema = ["id","name"])

df2.filter(df2.name.like("%rose%")).show()

df2.filter(df2.name.rlike("(?i)^*rose$")).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Groupby

# COMMAND ----------


simpleData = [("James","Sales","NY",90000,34,10000),
    ("Michael","Sales","NY",86000,56,20000),
    ("Robert","Sales","CA",81000,30,23000),
    ("Maria","Finance","CA",90000,24,23000),
    ("Raman","Finance","CA",99000,40,24000),
    ("Scott","Finance","NY",83000,36,19000),
    ("Jen","Finance","NY",79000,53,15000),
    ("Jeff","Marketing","CA",80000,25,18000),
    ("Kumar","Marketing","NY",91000,50,21000)
  ]

schema = ["employee_name","department","state","salary","age","bonus"]
df = spark.createDataFrame(data=simpleData, schema = schema)
df.printSchema()
df.show(truncate=False)

# COMMAND ----------

df.groupBy("department").sum("salary").show(truncate=False)

# COMMAND ----------

df.groupBy("department").count().show(truncate=False)

# COMMAND ----------

df.groupBy("department","state") \
    .sum("salary","bonus") \
    .show(truncate=False)

# COMMAND ----------

from pyspark.sql.functions import sum,avg,max
df.groupBy("department") \
    .agg(sum("salary").alias("sum_salary"), \
      avg("salary").alias("avg_salary"), \
      sum("bonus").alias("sum_bonus"), \
      max("bonus").alias("max_bonus")) \
    .where(col("sum_bonus") >= 50000) \
    .show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### sort

# COMMAND ----------

# MAGIC %md
# MAGIC #####order by
# MAGIC

# COMMAND ----------

simpleData = [("James","Sales","NY",90000,34,10000), \
    ("Michael","Sales","NY",86000,56,20000), \
    ("Robert","Sales","CA",81000,30,23000), \
    ("Maria","Finance","CA",90000,24,23000), \
    ("Raman","Finance","CA",99000,40,24000), \
    ("Scott","Finance","NY",83000,36,19000), \
    ("Jen","Finance","NY",79000,53,15000), \
    ("Jeff","Marketing","CA",80000,25,18000), \
    ("Kumar","Marketing","NY",91000,50,21000) \
  ]
columns= ["employee_name","department","state","salary","age","bonus"]
df = spark.createDataFrame(data = simpleData, schema = columns)
df.printSchema()
display(df)


# COMMAND ----------

dfSort=df.sort(df.state,df.salary).groupBy(df.state).agg(sum(df.salary))
dfSort.show()

# COMMAND ----------

df.sort("department","state").show(truncate=False)
df.sort(col("department"),col("state")).show(truncate=False)

# COMMAND ----------

df.orderBy("department","state").show(truncate=False)
df.orderBy(col("department"),col("state")).show(truncate=False)

# COMMAND ----------

df.sort(df.department.asc(),df.state.desc()).show(truncate=False)
df.sort(col("department").asc(),col("state").desc()).show(truncate=False)
df.orderBy(col("department").asc(),col("state").desc()).show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### PIVOT

# COMMAND ----------

# Implementing the Pivot() function and Stack() function in Databricks in PySpark	

sample_data = [("Banana",1000,"USA"), ("Carrots",1500,"USA"), ("Beans",1600,"USA"), 	
      ("Orange",2000,"USA"),("Orange",2000,"USA"),("Banana",400,"China"), 
      ("Carrots",1200,"China"),("Beans",1500,"China"),("Orange",4000,"China"),
      ("Banana",2000,"Canada"),("Carrots",2000,"Canada"),("Beans",2000,"Mexico")]	


sample_columns= ["Product","Amount","Country"]	

dataframe = spark.createDataFrame(data = sample_data, schema = sample_columns)	

dataframe.printSchema()	

dataframe.show(truncate=False)	


# COMMAND ----------

# Using the pivot() function	

pivot_DataFrame = dataframe.groupBy("Product").pivot("Country").sum("Amount")	
display(pivot_DataFrame)

# COMMAND ----------

pivot_DataFrame2 = dataframe.groupBy("Product","Country").sum("Amount").groupBy("Product").pivot("Country")   .sum("sum(Amount)")	

display(pivot_DataFrame2)

# COMMAND ----------

# Using stack() function to unpivot	
from pyspark.sql.functions import *
unpivot_Expr = "stack(2, 'China', China, 'Mexico', Mexico) as (Country,Total)"	

unpivot_DataFrame = pivot_DataFrame2.select("Product", expr(unpivot_Expr)).where("Total is not null")	

unpivot_DataFrame.show(truncate=False)	

# COMMAND ----------

# MAGIC %md
# MAGIC #####Unpivot
# MAGIC -- run allabove code to see pivot unpivot
# MAGIC

# COMMAND ----------

unPivotExpr = "stack(3,"Canada","canada","China","china","India","india") as ("Country","amount")"



unpivot_DataFrame = pivot_DataFrame2.select("Product", expr(unpivot_Expr)).where("Total is not null")	


# COMMAND ----------

# MAGIC %md
# MAGIC #####union
# MAGIC
# MAGIC Dataframe union() – union() method of the DataFrame is used to merge two DataFrame’s of the same structure/schema. If schemas are not the same it returns an error.
# MAGIC
# MAGIC DataFrame unionAll() – unionAll() is deprecated since Spark “2.0.0” version and replaced with union().
# MAGIC

# COMMAND ----------

simpleData = [("James","Sales","NY",90000,34,10000), \
    ("Michael","Sales","NY",86000,56,20000), \
    ("Robert","Sales","CA",81000,30,23000), \
    ("Maria","Finance","CA",90000,24,23000) \
  ]

columns= ["employee_name","department","state","salary","age","bonus"]
df = spark.createDataFrame(data = simpleData, schema = columns)

df.show(truncate=False)


# COMMAND ----------


simpleData2 = [("James","Sales","NY",90000,34,10000), \
    ("Maria","Finance","CA",90000,24,23000), \
    ("Jen","Finance","NY",79000,53,15000), \
    ("Jeff","Marketing","CA",80000,25,18000), \
    ("Kumar","Marketing","NY",91000,50,21000) \
  ]
columns2= ["employee_name","department","state","salary","age","bonus"]

df2 = spark.createDataFrame(data = simpleData2, schema = columns2)

df2.show(truncate=False)


# COMMAND ----------

# unionDF = df.union(df2)
# unionDF.show(truncate=False)

disDF = df.union(df2).distinct()
disDF.show(truncate=False)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC #####UDF
# MAGIC
# MAGIC UDF for Camel Case

# COMMAND ----------

columns = ["Seqno","Name"]
data = [("1", "john jones"),
    ("2", "tracey smith"),
    ("3", "amy sanders")]

df = spark.createDataFrame(data=data,schema=columns)

df.show(truncate=False)


# COMMAND ----------

def convertCase(str):
    resStr=""
    arr = str.split(" ")
    for x in arr:
       resStr= resStr + x[0:1].upper() + x[1:len(x)] + " "
    return resStr 


# COMMAND ----------

from pyspark.sql.functions import col, udf
from pyspark.sql.types import StringType

# Converting function to UDF 
convertUDF = udf(lambda z: convertCase(z)) 

# COMMAND ----------

df.select(col("Seqno"), \
    convertUDF(col("Name")).alias("Name") ) \
   .show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Window
# MAGIC

# COMMAND ----------

simpleData = (("James", "Sales", 3000), \
    ("Michael", "Sales", 4600),  \
    ("Robert", "Sales", 4100),   \
    ("Maria", "Finance", 3000),  \
    ("James", "Sales", 3000),    \
    ("Scott", "Finance", 3300),  \
    ("Jen", "Finance", 3900),    \
    ("Jeff", "Marketing", 3000), \
    ("Kumar", "Marketing", 2000),\
    ("Saif", "Sales", 4100) \
)
columns= ["employee_name", "department", "salary"]
df = spark.createDataFrame(data = simpleData, schema = columns)
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### lead Lag
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import lag,lead 
from pyspark.sql.window import Window

windowSpec=Window.partitionBy("department").orderBy("salary")

df.withColumn("lag",lag("salary",1).over(windowSpec))\
  .withColumn("lead",lead("salary",1).over(windowSpec))\
  .show()

df.withColumn("lag",lag("salary",1,5555).over(windowSpec))\
  .withColumn("lead",lead("salary",1,5555).over(windowSpec))\
  .show()

# COMMAND ----------

from pyspark.sql.functions import row_number
df=df.withColumn("lag",lag("salary",1,5555).over(windowSpec))\
  .withColumn("lead",lead("salary",1,5555).over(windowSpec))\
  .withColumn("rownum",row_number().over(Window.orderBy("salary")))


# COMMAND ----------

df.write.format("delta").saveAsTable("San_employee_1")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls "dbfs:/user/hive/warehouse/san_employee"

# COMMAND ----------

# MAGIC %md
# MAGIC #####Swap alternate values in column
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select *, case when rownum%2==0
# MAGIC                then lag(employee_name,1) over (order by salary)
# MAGIC                else lead(employee_name,1)over (order by salary)
# MAGIC                end as altername
# MAGIC from san_employee_1
# MAGIC
# MAGIC -- desc extended San_employee

# COMMAND ----------


from pyspark.sql.window import Window
from pyspark.sql.functions import row_number

windowSpec  = Window.partitionBy("department").orderBy("salary")

df.withColumn("row_number",row_number().over(windowSpec)) \
    .show(truncate=False)

from pyspark.sql.functions import rank
df.withColumn("rank",rank().over(windowSpec)) \
    .show()

from pyspark.sql.functions import dense_rank
df.withColumn("dense_rank",dense_rank().over(windowSpec)) \
    .show()

from pyspark.sql.functions import percent_rank
df.withColumn("percent_rank",percent_rank().over(windowSpec)) \
    .show()
    
from pyspark.sql.functions import ntile
df.withColumn("ntile",ntile(2).over(windowSpec)) \
    .show()

from pyspark.sql.functions import cume_dist    
df.withColumn("cume_dist",cume_dist().over(windowSpec)) \
   .show()




# COMMAND ----------

from pyspark.sql.functions import col,avg,sum,min,max,row_number 

windowSpecAgg  = Window.partitionBy("department")

df.withColumn("row",row_number().over(windowSpec)) \
  .withColumn("avg", avg(col("salary")).over(windowSpecAgg)) \
  .withColumn("sum", sum(col("salary")).over(windowSpecAgg)) \
  .withColumn("min", min(col("salary")).over(windowSpecAgg)) \
  .withColumn("max", max(col("salary")).over(windowSpecAgg)) \
  .where(col("row")==1).select("department","avg","sum","min","max") \
  .show()

# COMMAND ----------

# MAGIC %md
# MAGIC #####Date
# MAGIC

# COMMAND ----------


inputData = [("2019-07-01 12:01:19",            "07-01-2019 12:01:19",             "07-01-2019",            "01-Jul-2019",
            "2019-07-01",            "2019/07/01",            "01/07/2019" 
            )]
columns=["timestamp_1","timestamp_2","timestamp_3","timestamp_4","timestamp_5","timestamp_6","timestamp_7"]
df=spark.createDataFrame(data = inputData,schema = columns)
display(df)

# COMMAND ----------

from pyspark.sql.functions import unix_timestamp,col
df2 = df.select( 
      unix_timestamp(col("timestamp_1")).alias("timestamp_1"), 
      unix_timestamp(col("timestamp_2"),"MM-dd-yyyy HH:mm:ss").alias("timestamp_2"), 
      unix_timestamp(col("timestamp_3"),"MM-dd-yyyy").alias("timestamp_3"), 
      unix_timestamp(col("timestamp_4"),"dd-MMM-yyyy").alias("timestamp_4"), 
      unix_timestamp(col("timestamp_5"),"yyyy-MM-dd").alias("timestamp_5"), 
      unix_timestamp(col("timestamp_6"),"yyyy/MM/dd").alias("timestamp_6"), 
      unix_timestamp(col("timestamp_7"),"dd/MM/yyyy").alias("timestamp_7")
   )
display(df2)

# COMMAND ----------

from pyspark.sql.functions import from_unixtime

df3=df2.select(
    from_unixtime(col("timestamp_1"),"yyyy-MM-dd HH:mm:ss").alias("timestamp_1"),
    from_unixtime(col("timestamp_2"),"yyyy-MM-dd HH:mm:ss").alias("timestamp_2"),
    from_unixtime(col("timestamp_3"),"yyyy-MM-dd").alias("timestamp_3"),
    from_unixtime(col("timestamp_4"),"yyyy-MM-dd").alias("timestamp_4"),
    from_unixtime(col("timestamp_5"),"yyyy-MM-dd").alias("timestamp_5"),
    from_unixtime(col("timestamp_6"),"yyyy-MM-dd").alias("timestamp_6"),
    from_unixtime(col("timestamp_7"),"yyyy-MM-dd").alias("timestamp_7"),
  )
display(df3)


# COMMAND ----------

from pyspark.sql.functions import to_date
df4=df3.select(
    to_date(col("timestamp_1"),"yyyy-MM-dd HH:mm:ss").alias("timestamp_1"),
    to_date(col("timestamp_2"),"yyyy-MM-dd HH:mm:ss").alias("timestamp_2"),
    to_date(col("timestamp_3"),"yyyy-MM-dd").alias("timestamp_3"),
    to_date(col("timestamp_4"),"yyyy-MM-dd").alias("timestamp_4"),
    to_date(col("timestamp_5"),"yyyy-MM-dd").alias("timestamp_5"),
    to_date(col("timestamp_6"),"yyyy-MM-dd").alias("timestamp_6"),
    to_date(col("timestamp_7"),"yyyy-MM-dd").alias("timestamp_7")
  )
display(df4)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Collections and Tuples
# MAGIC
# MAGIC Let's quickly recap about Collections and Tuples in Python. We will primarily talk about collections and tuples that comes as part of Python standard library such as `list`, `set`, `dict` and `tuple`.
# MAGIC
# MAGIC * Group of elements with length and index - `list`
# MAGIC * Group of unique elements - `set`
# MAGIC * Group of key value pairs - `dict`
# MAGIC * While list, set and dict contain group of homogeneous elements, tuple contains group of heterogeneous elements.
# MAGIC * We can consider list, set and dict as a table in a database and tuple as a row or record in a given table.
# MAGIC * Typically we create list of tuples or set of tuples and dict is nothing but collection of tuples with 2 elements and key is unique.
# MAGIC * We typically use Map Reduce APIs to process the data in collections. There are also some pre-defined functions such as `len`, `sum`, `min`, `max` etc for aggregating data in collections.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Limitations of Pandas
# MAGIC
# MAGIC We can use Pandas for data processing. It provides rich APIs to read data from different sources, process the data and then write it to different targets.
# MAGIC
# MAGIC * Pandas works well for light weight data processing.
# MAGIC * Pandas is typically single threaded, which means only one process take care of processing the data.
# MAGIC * As data volume grows, the processing time might grow exponentially and also run into resource contention.
# MAGIC * It is not trivial to use distributed processing using Pandas APIs. We will end up struggling with multi threading rather than business logic.
# MAGIC * There are Distributed Computing Frameworks such as Hadoop Map Reduce, Spark etc to take care of data processing at scale on multi node Hadoop or Spark Clusters.
# MAGIC * Both Hadoop Map Reduce and Spark comes with Distributed Computing Frameworks as well as APIs.
# MAGIC
# MAGIC **Pandas is typically used for light weight Data Processing and Spark is used for Data Processing at Scale.**

# COMMAND ----------

data2 = [(2,"Michael Rose"),(3,"Robert Williams"),
     (4,"Rames Rose"),(5,"Rames rose")
  ]
df2 = spark.createDataFrame(data = data2, schema = ["id","name"]).show()


# COMMAND ----------

dbutils.data.summarize(df2)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Fib
# MAGIC

# COMMAND ----------

def fib(n):
    a,b = 0,1
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return (fib(n-1)+fib(n-2))
        
# 0 1 1 2 3 5 8 13 

n = 8
sum=0
for i in range(n):
    for j in range(i+1):
        # print(fib(j),end = " ")
        sum = fib(j)
        print(sum,end = " ")
    print("")
    

# COMMAND ----------

n=4
for i in range(n,0,-1):
  for j in range(i,0,-1):
    print(i,j)
  print("")

# COMMAND ----------

def fib(n):
    a,b = 0,1
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return (fib(n-1)+fib(n-2))
        
# 0 1 1 2 3 5 8 13 

n = 8
sum=0
for i in range(n):
    for j in range(i+1):
        # print(fib(j),end = " ")
        sum = fib(j)
        print(sum,end = " ")
    print("")
    

# COMMAND ----------

def fib(n):
    a,b = 0,1
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return (fib(n-1)+fib(n-2))
n=4
for i in range(n):
    for j in range(i+1):
        # print(j,end = " ")
        print(fib(j))
    print("") 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Star Pattern

# COMMAND ----------

def pypart(n):
    myList = []
    for i in range(1,n+1):
        myList.append("*"*i)
    print("\n".join(myList))
 
# Driver Code
n = 5
pypart(n)

# COMMAND ----------

my_list =["","",None]

if my_list[0] and my_list[2]:
  print("january")
elif len(my_list) > 1 :
  print("2024")
else:
  print("ww3")



# COMMAND ----------


rows = 5

for i in range(1,rows+1):
  print(" "*(rows-i),end=" ")
  print("*"*i)

# COMMAND ----------

