# Databricks notebook source
# MAGIC %md
# MAGIC #get_close_matches

# COMMAND ----------

import difflib as dl

words = ['hello', 'Hallo', 'hi', 'house', 'key', 'screen', 'hallo', 'question', 'format']

print(dl.get_close_matches('Hello', words))


# COMMAND ----------

# MAGIC %md
# MAGIC #udf

# COMMAND ----------

from pyspark.sql.types import IntegerType
from pyspark.sql.functions import udf, array
sum_cols = udf(lambda arr: sum(arr), IntegerType())
df = spark.createDataFrame([(101, 1, 16),(102, 1, 36),(103, 4, 52)], ['ID', 'A', 'B']).withColumn('Result', sum_cols(array('A', 'B')))


display(df)

# COMMAND ----------



# COMMAND ----------

from pyspark.sql.types import IntegerType
from pyspark.sql.functions import udf

def sum(x, y):
    return x + y

sum_cols = udf(sum, IntegerType())

a=spark.createDataFrame([(101, 1, 16),(102, 1, 36),(103, 4, 52)], ['ID', 'A', 'B'])
a.show()
a.withColumn('Result', sum_cols('A', 'B')).show()

# COMMAND ----------

@f.udf(DoubleType())
def get_max_row_with_None(*cols):
    if all(x is None for x in cols):
        return None
    else:
        return float(max(x for x in cols if x is not None))

sdf = df.withColumn(
    "max_rule", 
    get_max_row_with_None(*[df[col] for col in df.columns if col in rules])
)

# COMMAND ----------

from pyspark.sql import SparkSession
spark = ( SparkSession\
  .builder\
  .appName("Sandeep-Spark")\
  .master("local")\
  .getOrCreate()
)
spark

# COMMAND ----------

# MAGIC %md
# MAGIC ##SparkContext

# COMMAND ----------

# Disable AQE and Broadcast join

spark.conf.set("spark.sql.adaptive.enabled", False)
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", False)
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

# COMMAND ----------

# The value of default parallelism depends on the number of cores available of the excutors/nodes.

spark.sparkContext.defaultParallelism

# COMMAND ----------

spark.executor.cores

# COMMAND ----------

spark.executor.memory

# COMMAND ----------

spark.conf.get("spark.sql.shuffle.partitions")

# COMMAND ----------


spark.conf.get("spark.yarn.executor.memoryOverhead")

# COMMAND ----------

executor-memory

# COMMAND ----------


df_1 = spark.range(4, 200, 2)
df_2 = spark.range(2, 200, 4)

# COMMAND ----------

df_1.rdd.getNumPartitions()

# COMMAND ----------

df_2.rdd.getNumPartitions()

# COMMAND ----------


df_3 = df_1.repartition(5)
df_4 = df_2.repartition(7)

# COMMAND ----------

df_3.rdd.getNumPartitions()

# COMMAND ----------

df_4.rdd.getNumPartitions()

# COMMAND ----------

df_joined = df_3.join(df_4, on="id")

# COMMAND ----------

df_sum = df_joined.selectExpr("sum(id) as total_sum")

# COMMAND ----------

df_sum.show()

# COMMAND ----------

spark.conf.get("spark.sql.shuffle.partitions")

# COMMAND ----------

df_union = df_sum.union(df_4)
df_union.show()

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

sandeep.stop()

# COMMAND ----------

spark.conf.get("spark.driver.cores") 

# COMMAND ----------

spark.driver.cores

# COMMAND ----------

rdd = sc.parallelize(range(16))
rdd.collect()

# COMMAND ----------

help(sc.parallelize)

# COMMAND ----------

rdd.getNumPartitions()

# COMMAND ----------

spark.conf.get("spark.default.")

# COMMAND ----------



# COMMAND ----------

l = list(range(0,11,2))
print(l)

# COMMAND ----------



# COMMAND ----------

rdd.glom().collect()

# COMMAND ----------

# rdd1 = rdd.coalesce(8,True)  # default it works for only decreasing no of partitions
# rdd1 = rdd.coalesce(8)  # default it works for only decreasing no of partitions

     

# COMMAND ----------

# rdd2 = rdd.repartition(8) # it works for increasing/decreasing no of partitions
rdd2 = rdd.repartition(4) # it works for increasing/decreasing no of partitions

# COMMAND ----------

# rdd1.glom().collect()
rdd2.glom().collect()

# COMMAND ----------

print('original rdd : ',rdd.glom().collect())
print('coalesce 2 : ',rdd1.glom().collect())
print('repartition 2  : ',rdd2.glom().collect())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Word Count - PySpark

# COMMAND ----------

str = "india,cricket,football,usa,,football,usa,india,football,usa,india,cricket,football,usa"


# COMMAND ----------

dbutils.fs.put("dbfs:/user/hive/warehouse/multiDelimiter.txt","1,A,20,21|31|21|33\n"
"2,B,23,22|33|41|43\n"
"3,C,22,51|61|31|43\n"
"4,D,24,24|34|25|38"
)

# COMMAND ----------

df = spark.read.format("csv").load("dbfs:/user/hive/warehouse/multiDelimiter.txt")

# COMMAND ----------

from pyspark.sql.functions import explode,col
# from pyspark.sql.types import col
df = df.withColumn("exploding",col["_c3"].explode())
display(df)

# COMMAND ----------

dbutils.fs.ls("dbfs:/user/hive/warehouse/wordCount_san.csv")

# COMMAND ----------

rdd = sc.textFile("dbfs:/user/hive/warehouse/wordCount_san.csv")


# COMMAND ----------

# type(rdd.collect())

rdd1 = rdd.flatMap(lambda x : x.split(",")).map(lambda x: (x,1)).reduceByKey(lambda x,y :(x+y) )

# COMMAND ----------

rdd1.collect()

# COMMAND ----------

rdd2 = rdd.flatMap(lambda x: x.split(",")).map(lambda x: (x, 1)).groupByKey().mapValues(sum)
rdd2.collect()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Word Count - Python

# COMMAND ----------

str = "india,cricket,football,usa,,football,usa,india,football,usa,india,cricket,football,usa"

# COMMAND ----------

lst = str.split(",")
ch={}
for i in lst:
  if i in ch:
    ch[i]+=1
  else:
    ch[i]=1

print(ch)

# COMMAND ----------

max_ch =  max(ch.values())
print(max_ch)

# COMMAND ----------

s = "initsinitintintinnnn"
ch = {}
for i in s:
    if i in ch.keys():
        ch[i] += 1
    else:
        ch[i] = 1

max_chr = max(ch, key=ch.get)
print(ch)
print(max_chr)


# COMMAND ----------

emp_data = [
    ["001","101","John Doe","30","Male","50000","2015-01-01"],
    ["002","101","Jane Smith","25","Female","45000","2016-02-15"],
    ["003","102","Bob Brown","35","Male","55000","2014-05-01"],
    ["004","102","Alice Lee","28","Female","48000","2017-09-30"],
    ["005","103","Jack Chan","40","Male","60000","2013-04-01"],
    ["006","103","Jill Wong","32","Female","52000","2018-07-01"],
    ["007","101","James Johnson","42","Male","70000","2012-03-15"],
    ["008","102","Kate Kim","29","Female","51000","2019-10-01"],
    ["009","103","Tom Tan","33","Male","58000","2016-06-01"],
    ["010","104","Lisa Lee","27","Female","47000","2018-08-01"],
    ["011","104","David Park","38","Male","65000","2015-11-01"],
    ["012","105","Susan Chen","31","Female","54000","2017-02-15"],
    ["013","106","Brian Kim","45","Male","75000","2011-07-01"],
    ["014","107","Emily Lee","26","Female","46000","2019-01-01"],
    ["015","106","Michael Lee","37","Male","63000","2014-09-30"],
    ["016","107","Kelly Zhang","30","Female","49000","2018-04-01"],
    ["017","105","George Wang","34","Male","57000","2016-03-15"],
    ["018","104","Nancy Liu","29","Female","50000","2017-06-01"],
    ["019","103","Steven Chen","36","Male","62000","2015-08-01"],
    ["020","102","Grace Kim","32","Female","53000","2018-11-01"]
]

emp_schema = "employee_id string, department_id string, name string, age string, gender string, salary string, hire_date string"
# Cre

# COMMAND ----------

# MAGIC %md
# MAGIC # Multiply every list element

# COMMAND ----------

list_1 =[1,2,3]
list_1*3

# COMMAND ----------

list_1 = [1,2,3]
list_2 =[]
for i in list_1:
    x=i*3
    list_2.append(x)
print(list_2)


# COMMAND ----------

# MAGIC %md
# MAGIC # Move 0 to the end of the list 

# COMMAND ----------

list = [1,0,2,0,4,6]

for i in list:
  if i==0:
    list.remove(i)
    list.append(i)
  else:
    pass

print(list)

# COMMAND ----------

# MAGIC %md
# MAGIC #President problem

# COMMAND ----------

list = [1,2,3,4,5,6,7,8,9,10]

1,3,5,7,9

# COMMAND ----------

my_list = [1, 2, 3, 4, 5]  
my_list = [x for x in my_list if x >= 2 and x <= 4]  
print(my_list)


# COMMAND ----------

lst1 =[5,2,7,9,3,1,4,71,55,44,66]

lst1 = [i for i in lst1 if i>= 4 and i<= 55]

print(lst1)

# COMMAND ----------

for i in range(3):
  for j in range(3):
    print(i,j)

# COMMAND ----------

# lst = {i,j for i in range(3) for j in range(3)}

# lst = [i+j for i in range(3) for j in range(3)]
lst = [(i,j) for i in range(3) for j in range(3)]

lst = {i,j for i in range(3) for j in range(3)}

lst 

# COMMAND ----------

# MAGIC %md
# MAGIC #Capitalize first Char

# COMMAND ----------

str ="sandeep gutte"

str.title()


# COMMAND ----------

str.capitalize()

# COMMAND ----------

def capitalizeWord(str):
   result=""
   words = str.split(" ")
   for word in words:
      result= result + word[0:1].upper() + word[1:len(word)] + " "
   return result

# COMMAND ----------

str ="sandeep gutte"
print(capitalizeWord(str))

# COMMAND ----------

# MAGIC %md
# MAGIC #Pattern Printing 

# COMMAND ----------

rw=5

#for row in range(1,rw+1):
ch = 64

for row in range(rw+1,0,-1):
	for col in range(1,row+1):
    		ch = ch+1
    		print("{0}".format(chr(ch)),end= " ")
	print()
    

# COMMAND ----------

rw=4

#for row in range(1,rw+1):
ch = 64

for row in range(0,rw+1,1):
	for col in range(rw+1,0,-1):
    		ch = ch+1
    		print("{0}".format(chr(ch)),end= " ")
	print()
    

# COMMAND ----------

# MAGIC %md
# MAGIC #Reverse String 

# COMMAND ----------

String = 'Sandeep Gutte'
print(String[::-1])

# print(String[start:stop:step])


# COMMAND ----------

str = "Sandeep Gutte"

s = "".join(reversed(str))

print(s)

print(str.split())

# COMMAND ----------

# MAGIC %md
# MAGIC # NaN

# COMMAND ----------

import pandas as pd
import numpy as np

student_dict = {"name": ["Joe", "Sam", np.nan, "Harry"], 
                "age": [np.nan, np.nan, np.nan, np.nan],
                "sex": [np.nan, np.nan, np.nan, np.nan],
                "age": [np.nan, np.nan, np.nan, np.nan],
                "marks": [85.10, np.nan, np.nan, 91.54]}

student_df = pd.DataFrame(student_dict)
display(student_df)


# COMMAND ----------

student_df = student_df.dropna(axis='columns', how='all')

display(student_df)

# COMMAND ----------

type(student_df)

df = spark.createDataFrame(student_df)

# COMMAND ----------

# df = df.dropna( how='all')
df = df.dropna(thresh=2, subset=("name","age","sex","marks"))
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC # set immutability

# COMMAND ----------

# Converting the list to a set
lst1 = [5, 2, 7, 9, 3, 1, 44, 71, 55, 44, 66]
set1 = set(lst1)
print(set1)

# Creating a set with immutable elements
set1 = {1, 2, 3, "JavaTpoint", 20.5, 14}
print(type(set1))

# Creating a set with mutable elements
set2 = {1, 2, 3, ("Javatpoint", 4)}
print(type(set2))

# COMMAND ----------

# MAGIC %md
# MAGIC # isnotnull

# COMMAND ----------

    input_data = [("Shivansh", "Data Scientist", "Noida",None,None),
                  (None, "Software Developer", None,None,None),
                  ("Swati", "Data Analyst", "Hyderabad","A","B"),
                  (None, None, "Noida",None,None),
                  ("Arpit", "Android Developer", "Banglore",None,None),
                  (None, None, None,None,None)]
     
    schema = ["Name", "Job Profile", "City", "ABC", "XYZ"]
 
    df = spark.createDataFrame( input_data, schema)
 
    df.show()
    df = df.filter(df["Job Profile"].isNotNull())

    # df.show()


# COMMAND ----------

import pandas
df_pd = df.toPandas()
display(df_pd)

df_pd = df_pd.dropna(axis=0, thresh=4, how="all") 
display(df_pd)

# COMMAND ----------

# df.dropna(axis = 1, how='all')
# df = df.dropna(axis=1, how='all')







# COMMAND ----------

from pyspark.sql.functions import col, when, count
df2 = df.select([count(when(~col(c).contains('None') & \
                            ~col(c).contains('NULL') & \
                            (col(c) != ' ' ) & \
                            ~col(c).isNull(), c 
                           )).alias(c)
                    for c in df.columns])
df2.show()

# COMMAND ----------

from pyspark.sql.functions import col
print(df.filter(col("Name").isNotNull() & col("Job Profile").isNotNull() & col("City").isNotNull()).count())

# COMMAND ----------

from pyspark.sql.functions import col,isnan,when,count
schema=["Name", "Job Profile", "City"]
df.select([count(when(isnan(c) | col(c).isNull() , c)).alias(c) for c in schema]
   ).show()

# COMMAND ----------

# MAGIC %md
# MAGIC #Dynamic Column Name

# COMMAND ----------

    from pyspark.sql.functions import col
    input_data = [("Shivansh", "Data Scientist", "Noida","M",10000),
                  ("Sandeep", "Software Developer", None,"M",20000),
                  ("Swati", "Data Analyst", "Hyderabad","F",40000),
                  ("Suchita", "Data Engineer", "Noida","F",50000),
                  ("Arpit", "Android Developer", "Banglore","M",30000),
                  ("Rani", "Spark Developer", "Pune","F",80000)]
     
    schema = ["Name", "Job Profile", "City", "Gender", "Salary"]
 
    df = spark.createDataFrame( input_data, schema)
    df.show()
    
    df=df.filter(col("City")!='Null')
    df.show()

# COMMAND ----------

from pyspark.sql.functions import lower ,col
df = df.withColumn("Job Profile", lower(col("Job Profile")))
display(df)

# COMMAND ----------

    input_data = [("Shivansh", "scientist", "Noida","M",10000),
                  ("Sandeep", "developer", None,"M",20000),
                  ("Swati", "analyst", "Hyderabad","F",40000),
                  ("Suchita", "engineer", "Noida","F",50000),
                  ("Arpit", "developer", "Banglore","M",30000),
                  ("Rani", "developer", "Pune","F",80000)]
     
    schema = ["Name", "Job Profile", "City", "Gender", "Salary"]
 
    df1 = spark.createDataFrame( input_data, schema)
    df1.show()
    

# COMMAND ----------

# MAGIC %md
# MAGIC #spark_partition_id

# COMMAND ----------


# spark.conf.set("spark.sql.sources.partitionOverwriteMode", "STATIC")
# Check the mode for Partition Overwrite # dynamic #
print(spark.conf.get("spark.sql.sources.partitionOverwriteMode"))

# COMMAND ----------

from pyspark.sql.functions import to_date
_data = [
    ["ORD1001", "P003", 70, "01-21-2022", "01-30-2022"],
    ["ORD1004", "P033", 12, "01-24-2022", "01-30-2022"],
    ["ORD1005", "P036", 10, "01-20-2022", "01-30-2022"],
    ["ORD1002", "P016", 2, "01-10-2022", "01-30-2022"],
    ["ORD1003", "P012", 6, "01-10-2022", "01-30-2022"],
]
_cols = ["order_id", "prod_id", "qty", "order_date", "insert_date"]

df = spark.createDataFrame(data=_data, schema=_cols)
df = df.withColumn("order_date", to_date("order_date" ,"MM-dd-yyyy"))\
  .withColumn("insert_date", to_date("insert_date" ,"MM-dd-yyyy"))
df.printSchema()
df.show()

# COMMAND ----------

df.repartition("order_date") \
    .write \
    .format("parquet") \
    .partitionBy("order_date") \
    .mode("overwrite") \
    .save("dbfs:/user/hive/warehouse/san_orders/")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls "dbfs:/user/hive/warehouse/san_orders/"

# COMMAND ----------

print(df.rdd.getNumPartitions())


# COMMAND ----------

df = spark.read.format("parquet").load("dbfs:/user/hive/warehouse/san_orders/order_date=2022-01-10/")
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------



# COMMAND ----------

from pyspark.sql.functions import spark_partition_id,count
df = spark.read.format("parquet").load("dbfs:/user/hive/warehouse/san_orders/")
df=df.withColumn("Partition_id",spark_partition_id())
display(df)

# df1=df.withColumn("Partition_id",spark_partition_id()).groupBy("Partition_id").count()
# display(df1)


# COMMAND ----------

display(df)

# COMMAND ----------

df2=df.groupBy("Partition_id")\
  .agg(count("order_date").alias("Record_count"))

# COMMAND ----------

df = df.join(df2)
display(df)

# COMMAND ----------

from pyspark.sql.functions import spark_partition_id,count,groupBy
# df = spark.read.format("parquet").load("dbfs:/user/hive/warehouse/san_orders/")
df.withColumn("Number_of_records",spark_partition_id()).groupBy(spark_partition_id()).agg(count()).show()
df.withColumn("partitionId", spark_partition_id()).groupBy("partitionId").count().show()
display(df)