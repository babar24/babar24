# Databricks notebook source
# MAGIC %md
# MAGIC ### Log_Table

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table log_table

# COMMAND ----------

# MAGIC %sql
# MAGIC create table log_table(
# MAGIC   Log_Id int,
# MAGIC   Log_no integer
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into log_table values(1,1);
# MAGIC insert into log_table values(2,2);
# MAGIC insert into log_table values(3,1);
# MAGIC insert into log_table values(4,3);
# MAGIC insert into log_table values(5,3);
# MAGIC insert into log_table values(6,3);
# MAGIC insert into log_table values(7,4);
# MAGIC insert into log_table values(8,5);

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC delete from  log_table 
# MAGIC where Log_Id=1 and Log_no =4

# COMMAND ----------

# MAGIC %sql 
# MAGIC desc extended default.log_table

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from default.log_table
# MAGIC order by Log_Id 

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select Log_Id, Log_no, lead(log_no) over (Order by log_no) as Next_Log_no
# MAGIC from log_table
# MAGIC order by log_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Emp

# COMMAND ----------

spark

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC DROP TABLE Emp;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE or REPLACE TABLE Emp (
# MAGIC   empno    Int,
# MAGIC   ename    STRING,
# MAGIC   job      STRING,
# MAGIC   mgr      Int,
# MAGIC   hiredate DATE,
# MAGIC   sal      Float,
# MAGIC   comm     Float,
# MAGIC   deptno   Int
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- INSERT INTO emp VALUES (7369,'SMITH','CLERK',7902,'1980-12-17',800,NULL,20);
# MAGIC -- INSERT INTO emp VALUES (7499,'ALLEN','SALESMAN',7698,'1981-2-20',1600,300,30);
# MAGIC -- INSERT INTO emp VALUES (7521,'WARD','SALESMAN',7698,'1981-2-22',1250,500,30);
# MAGIC -- INSERT INTO emp VALUES (7566,'JONES','MANAGER',7839,'1981-2-4',2975,NULL,20);
# MAGIC -- INSERT INTO emp VALUES (7654,'MARTIN','SALESMAN',7698,'1981-9-28',1250,1400,30);
# MAGIC -- INSERT INTO emp VALUES (7698,'BLAKE','MANAGER',7839,'1981-1-5',2850,NULL,30);
# MAGIC -- INSERT INTO emp VALUES (7782,'CLARK','MANAGER',7839,'1981-6-9',2450,NULL,10);
# MAGIC -- INSERT INTO emp VALUES (7788,'SCOTT','ANALYST',7566,'1987-7-13',3000,NULL,20);
# MAGIC -- INSERT INTO emp VALUES (7839,'KING','PRESIDENT',NULL,'1981-11-17',5000,NULL,10);
# MAGIC -- INSERT INTO emp VALUES (7844,'TURNER','SALESMAN',7698,'1981-8-9',1500,0,30);
# MAGIC -- INSERT INTO emp VALUES (7876,'ADAMS','CLERK',7788,'1987-7-13',1100,NULL,20);
# MAGIC -- INSERT INTO emp VALUES (7900,'JAMES','CLERK',7698,'1981-12-3',950,NULL,30);
# MAGIC -- INSERT INTO emp VALUES (7902,'FORD','ANALYST',7566,'1981-12-3',3000,NULL,20);
# MAGIC -- INSERT INTO emp VALUES (7934,'MILLER','CLERK',7782,'1982-1-23',1300,NULL,10);

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Duplicate entries 
# MAGIC
# MAGIC select empno,ename,count(*)
# MAGIC from Emp
# MAGIC group by empno,ename
# MAGIC having count(*) > 1

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from Emp

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Employee Id and Name of the Manager
# MAGIC select A.empno,A.ename,B.empno,B.ename
# MAGIC from Emp A 
# MAGIC Left join Emp B 
# MAGIC On A.mgr = B.empno

# COMMAND ----------

# MAGIC %sql
# MAGIC -- lead,lag
# MAGIC select empno,ename,sal,lead(sal) over(order by deptno) as lead_val
# MAGIC from Emp 

# COMMAND ----------

# MAGIC %md
# MAGIC ### Overlapping Event

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create table default.contest(
# MAGIC   c_id int,
# MAGIC   start_date date,
# MAGIC   end_date date
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC desc extended contest

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC insert into contest values(1,"2015-02-01","2015-02-04");
# MAGIC insert into contest values(2,"2015-02-02","2015-02-05");
# MAGIC insert into contest values(3,"2015-02-03","2015-02-07");
# MAGIC insert into contest values(4,"2015-02-04","2015-02-06");
# MAGIC insert into contest values(5,"2015-02-06","2015-02-09");
# MAGIC insert into contest values(6,"2015-02-08","2015-02-10");
# MAGIC insert into contest values(7,"2015-02-10","2015-02-11");
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from contest 

# COMMAND ----------

# MAGIC %sql
# MAGIC with cte1 as(
# MAGIC select c_id,start_date,end_date,row_number() over (order by c_id,start_date) as rn 
# MAGIC from contest
# MAGIC )select * from cte1;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from cte1

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE employee_record_san (employee_number INT ,manager_employee_number INT);

# COMMAND ----------

# MAGIC %sql 
# MAGIC insert into employee_record_san values( 404,NULL);
# MAGIC insert into employee_record_san values( 1014,1019);
# MAGIC insert into employee_record_san values( 1011,1019);
# MAGIC insert into employee_record_san values( 1010,1003);
# MAGIC insert into employee_record_san values( 1001,1003);
# MAGIC insert into employee_record_san values( 1004,1003);
# MAGIC insert into employee_record_san values( 1012,1004);
# MAGIC insert into employee_record_san values( 1002,1004);
# MAGIC insert into employee_record_san values( 1015,1004);
# MAGIC insert into employee_record_san values( 1003,404);
# MAGIC insert into employee_record_san values( 1019,404);
# MAGIC insert into employee_record_san values( 1016,404);
# MAGIC insert into employee_record_san values( 1008,1019);
# MAGIC insert into employee_record_san values( 1006,1019);
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from employee_record_san

# COMMAND ----------

# MAGIC %sql 
# MAGIC WITH CTE_Recursive AS 
# MAGIC (
# MAGIC   select er.employee_number from employee_record er
# MAGIC   where er.manager_employee_number = 404
# MAGIC   UNION ALL
# MAGIC   select emprec.employee_number from CTE_Recursive crec
# MAGIC   inner join employee_record emprec
# MAGIC   on crec.employee_number = emprec.manager_employee_number
# MAGIC )select * from CTE_Recursive order by employee_number

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manager ID

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create table default.emp_san
# MAGIC (
# MAGIC emp_id int,
# MAGIC emp_name varchar(50),
# MAGIC mgr_id int
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC desc extended default.emp_san

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- insert into default.emp_san values(100,"Mark",103);
# MAGIC -- insert into default.emp_san values(101,"John",104);
# MAGIC -- insert into default.emp_san values(102,"Maria",103);
# MAGIC insert into default.emp_san values(103,"Tom",null);
# MAGIC -- insert into default.emp_san values(104,"David",103);
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from  default.emp_san

# COMMAND ----------

# MAGIC %md
# MAGIC ##Self Join
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select A.Emp_id,A.emp_name, A.mgr_id,coalesce(B.emp_name,"BOSS") as mgr_name
# MAGIC from default.emp_san A 
# MAGIC left join default.emp_san B 
# MAGIC on A.mgr_id = B.emp_id

# COMMAND ----------

# MAGIC %md
# MAGIC ##Lead Lag

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create table default.san_stud
# MAGIC (
# MAGIC stud_name varchar(50),
# MAGIC total_marks int,
# MAGIC yr int
# MAGIC )

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- insert into default.san_stud values("Rahul",90,2010);
# MAGIC -- insert into default.san_stud values("Sanjay",80,2010)
# MAGIC -- insert into default.san_stud values("Mohan",70,2010)
# MAGIC
# MAGIC
# MAGIC -- insert into default.san_stud values("Rahul",90,2011);
# MAGIC -- insert into default.san_stud values("Sanjay",85,2011)
# MAGIC -- insert into default.san_stud values("Mohan",65,2011)
# MAGIC
# MAGIC
# MAGIC -- insert into default.san_stud values("Rahul",80,2012);
# MAGIC -- insert into default.san_stud values("Sanjay",90,2012)
# MAGIC insert into default.san_stud values("Mohan",90,2012)
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from default.san_stud
# MAGIC order by yr,stud_name

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from (
# MAGIC   select 
# MAGIC     stud_name, 
# MAGIC     total_marks, 
# MAGIC     yr, 
# MAGIC     lag(total_marks, 1) over(partition by stud_name order by yr) as prev_marks
# MAGIC from default.san_stud

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC with ctes1 as (
# MAGIC   select 
# MAGIC     stud_name, 
# MAGIC     total_marks, 
# MAGIC     yr, 
# MAGIC     lag(total_marks, 1) over(partition by stud_name order by yr) as prev_marks
# MAGIC   from default.san_stud
# MAGIC )select * from ctes1
# MAGIC where total_marks >= prev_marks

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC   select 
# MAGIC     stud_name, 
# MAGIC     total_marks, 
# MAGIC     yr, 
# MAGIC     lead(total_marks) over(partition by stud_name order by yr desc ) as prev_marks
# MAGIC   from default.san_stud

# COMMAND ----------

# MAGIC %md
# MAGIC ###consecutive mark/salary hike in 3 yeards

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT * 
# MAGIC FROM default.san_stud
# MAGIC ORDER BY yr

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select stud_name,count(*) from (
# MAGIC   select 
# MAGIC     stud_name, 
# MAGIC     total_marks, 
# MAGIC     yr, 
# MAGIC     lead(total_marks) over(partition by stud_name order by yr desc ) as prev_marks
# MAGIC   from default.san_stud
# MAGIC )where total_marks >= prev_marks
# MAGIC group by stud_name
# MAGIC Having count(*) >= 2

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select stud_name,total_marks,yr,
# MAGIC lead(total_marks,1) over(partition by stud_name order by yr ) as Next_yr
# MAGIC from default.san_stud
# MAGIC order by yr

# COMMAND ----------

# MAGIC %md
# MAGIC ### N Consecutive records 

# COMMAND ----------

# MAGIC %sql
# MAGIC create table default.weather
# MAGIC (
# MAGIC id int,
# MAGIC city varchar(50),
# MAGIC temperature int,
# MAGIC day date
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into weather values 
# MAGIC -- (1, 'London', -1,'2021-01-01');
# MAGIC -- (2, 'London', -2,'2021-01-02');
# MAGIC -- (3, 'London', 4, '2021-01-03');
# MAGIC -- (4, 'London', 1, '2021-01-04');
# MAGIC -- (5, 'London', -2,'2021-01-05');
# MAGIC -- (6, 'London', -5,'2021-01-06');
# MAGIC -- (7, 'London', -7,'2021-01-07');
# MAGIC -- (8, 'London', 5, '2021-01-08');

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from  default.weather
# MAGIC order by id 

# COMMAND ----------

# DBTITLE 1,with ID as PK
# MAGIC %sql
# MAGIC
# MAGIC with CTE as (
# MAGIC   select id,city,temperature,day,
# MAGIC   row_number() over (order by day ) as RN ,
# MAGIC   id -(row_number() over (order by day )) as diff
# MAGIC   from default.weather 
# MAGIC   where temperature < 0
# MAGIC   ),
# MAGIC   CTE2 AS (
# MAGIC     SELECT * ,count(*) over (partition by diff) AS CNT 
# MAGIC     FROM CTE
# MAGIC   )
# MAGIC SELECT * FROM CTE2 
# MAGIC WHERE CNT >=3
# MAGIC

# COMMAND ----------

spark.sql("""
select  city,temperature from  default.weather
order by id 
""").createOrReplaceTempView("vw_weather")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * 
# MAGIC from vw_weather

# COMMAND ----------

# DBTITLE 1,without ID as PK
# MAGIC %sql
# MAGIC
# MAGIC with CTE1 AS (
# MAGIC   SELECT city,temperature,
# MAGIC   row_number() over () AS id
# MAGIC   FROM vw_weather
# MAGIC ),
# MAGIC   CTE as (
# MAGIC   select id,city,temperature,
# MAGIC   id -(row_number() over (order by id )) as diff
# MAGIC   from CTE1 
# MAGIC   where temperature < 0
# MAGIC   ),
# MAGIC   CTE2 AS (
# MAGIC     SELECT * ,count(*) over (partition by diff) AS CNT 
# MAGIC     FROM CTE
# MAGIC   )
# MAGIC SELECT * FROM CTE2 
# MAGIC WHERE CNT >=3
# MAGIC

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ##hanker ranks 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### List

# COMMAND ----------


nums = [3,2,3,2,3]
val = 3
# nums = [0,1,2,3,0,4,2,2,2,]
# val = 2

print(len(nums))

for i in nums:
    if i == val:
        nums.remove(i)
        nums.append(" ")
    else:
        pass

print(nums)

# COMMAND ----------


# nums = [3,2,3,2,3]
# val = 3
nums = [0,1,2,3,0,4,2,2,2,]
val = 2

length = len(nums)

for i in range(0,length):
    if nums[i] == val:
        nums.remove(nums[i])
        print(nums[i])
        nums.append("_")
    else:
        pass

print(nums)

# COMMAND ----------


nums = [0,1,2,2,3,0,4,2,2,2,]
val = 2

length = len(nums)

for k,v in enumerate(nums):
    if v == val:
        nums.remove(v)
        nums.insert(k,"_")
    else:
        pass

print(nums)
count = 0
for i in nums:
  if i != "_":
    count+=1

print(count)


# COMMAND ----------

nums = [0,1,2,2,3,0,4,2,2,2,]
val = 2

length = len(nums)

for i in nums:
    if i == val:
        nums.append(" ")
        nums.remove(i)  
    else:
        pass

print(nums)

# COMMAND ----------

a = ['a', 'b', 'c', 'd','e']
# a.pop()

for k,v in enumerate(a):
  print(k,v)
  if k%2==0:
    a.remove(v)
    a.insert(k,'X')

print(a)

# COMMAND ----------

# MAGIC %md
# MAGIC ###sql
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create table default.cinema(
# MAGIC   seat_id integer,
# MAGIC   free integer
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- insert into default.cinema values(1,1);
# MAGIC -- insert into default.cinema values(2,0);
# MAGIC -- insert into default.cinema values(3,1);
# MAGIC -- insert into default.cinema values(4,1);
# MAGIC insert into default.cinema values(5,1);

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select concat(A.seat_id,",",A.seat_id+1,",",A.seat_id+2) as seats
# MAGIC from (
# MAGIC select seat_id,free,
# MAGIC lead(free,1) over (order by seat_id) as lead_1,
# MAGIC lead(free,2) over (order by seat_id) as lead_2
# MAGIC from default.cinema 
# MAGIC )A
# MAGIC where A.free = 1 and A.lead_1 = 1 and A.lead_2 = 1

# COMMAND ----------

# MAGIC %sql
# MAGIC select  seat_id,free,
# MAGIC lead(free,1) over (order by seat_id) as lead_1
# MAGIC from default.cinema 

# COMMAND ----------

# MAGIC %md
# MAGIC ## complex Queries

# COMMAND ----------

# MAGIC %md
# MAGIC ### fetch all the duplicate records

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create table default.Activity
# MAGIC (
# MAGIC   player_id integer,
# MAGIC   device_id integer,
# MAGIC   event_date date,
# MAGIC   games_played integer
# MAGIC )
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- insert into default.activity values(1,2,'2016-03-01',5);
# MAGIC insert into default.activity values(1,2,'2016-03-02',6);
# MAGIC -- insert into default.activity values(2,3,'2017-06-25',1);
# MAGIC -- insert into default.activity values(3,1,'2016-03-02',0);
# MAGIC -- insert into default.activity values(3,4,'2018-07-03',5);
# MAGIC
# MAGIC -- delete from default.activity 
# MAGIC -- where event_date = '2016-05-02'

# COMMAND ----------

# MAGIC %md
# MAGIC Write a query to report the device that is first logged in for each player

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * 
# MAGIC from default.activity 
# MAGIC order by player_id

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select *  from (
# MAGIC select *,
# MAGIC dense_rank() over(partition by device_id order by event_date) as  rn,
# MAGIC rank() over(partition by player_id order by event_date ) as RR
# MAGIC from default.activity 
# MAGIC order by player_id
# MAGIC )A
# MAGIC where RR = 1 and rn = 1
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Players logged in for atleast 2 consecutive days

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * 
# MAGIC from default.activity 
# MAGIC order by player_id

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC select * from (
# MAGIC SELECT *,
# MAGIC min(event_date) OVER (PARTITION BY player_id ) as min_event_date
# MAGIC FROM default.activity
# MAGIC order by player_id
# MAGIC ) A 
# MAGIC where event_date = A.min_event_date +1
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC with cte_a as (
# MAGIC   select count(distinct player_id ) as nb_players
# MAGIC   from default.activity a
# MAGIC   join (
# MAGIC     select player_id,min(event_date) as first_login_date 
# MAGIC     from default.activity
# MAGIC     group by player_id
# MAGIC     )t
# MAGIC     on a.player_id = t.player_id
# MAGIC     and a.event_date =t.first_login_date +1 
# MAGIC ),
# MAGIC cte2 as (
# MAGIC    select count(distinct player_id) as totl_plaers
# MAGIC    from activity
# MAGIC )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pattern Printing 

# COMMAND ----------

def pypart(n):
	for i in range(0, n):
		for j in range(0, i+1):
			print("* ",end="")
		print("\r")

n = 5
pypart(n)


# COMMAND ----------

def pypart(n):
	for i in range(0, n):
		for j in range(0, i+1):
			print("i ",end="")
		print("\r")

n = 5
pypart(n)


# COMMAND ----------

# MAGIC %md
# MAGIC # Consecutive Transactions

# COMMAND ----------

# MAGIC %md
# MAGIC Write an SQL query to find the total number of customers who made at least 2 transactions on consecutive days, 
# MAGIC and for each of those customers, find the total number of days they made consecutive transactions. 
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC create table default.Transactions(
# MAGIC TransactionId int,
# MAGIC CustomerId int,
# MAGIC TransactionDate date,
# MAGIC Amount double
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC -- insert into table default.Transactions values(1,101,"2023-01-01",100.0)
# MAGIC -- insert into table default.Transactions values(2,101,"2023-01-02",150.0)
# MAGIC -- insert into table default.Transactions values(3,101,"2023-01-03",200.0)
# MAGIC -- insert into table default.Transactions values(4,202,"2023-01-01",50.00)
# MAGIC -- insert into table default.Transactions values(5,202,"2023-01-02",60.00)
# MAGIC -- insert into table default.Transactions values(6,303,"2023-01-01",30.00)
# MAGIC -- insert into table default.Transactions values(7,303,"2023-01-02",35.00)
# MAGIC -- insert into table default.Transactions values(8,303,"2023-01-03",40.00)
# MAGIC insert into table default.Transactions values(9,303,"2023-01-05",45.00)

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH CTE1 AS (
# MAGIC   SELECT *, DENSE_RANK() OVER (PARTITION BY CustomerId ORDER BY TransactionDate) AS RNK 
# MAGIC   FROM default.Transactions
# MAGIC ),
# MAGIC CTE2 AS (
# MAGIC   SELECT *, DATE_ADD(CAST(CTE1.TransactionDate AS TIMESTAMP),- CTE1.RNK) AS TRS_DATE
# MAGIC   FROM CTE1 
# MAGIC ),
# MAGIC CTE3 AS (
# MAGIC   SELECT CTE2.CustomerId,CTE2.TRS_DATE,COUNT(*)
# MAGIC   FROM CTE2
# MAGIC   GROUP BY CTE2.CustomerId,CTE2.TRS_DATE
# MAGIC   HAVING COUNT(*) >=2
# MAGIC )
# MAGIC SELECT * FROM CTE3

# COMMAND ----------

# MAGIC %md
# MAGIC # SORT List of tuples
# MAGIC

# COMMAND ----------

# DBTITLE 1,by using dataframe.sort
from pyspark.sql.types import StructType,StructField, StringType, IntegerType
from pyspark.sql import SparkSession

students = [("Alice", 160), ("Bob", 155), ("Charlie", 175), ("David", 150)]

schema = StructType([
    StructField("Name", StringType(), True),
    StructField("Height", IntegerType(), True)
])


# COMMAND ----------

df = spark.createDataFrame(students,schema)

# COMMAND ----------

display(df)

# COMMAND ----------

df = df.sort("Height")
display(df)

# COMMAND ----------

# DBTITLE 1,By list.sort(key=lambda x:x[1])
students = [("Alice", 160), ("Bob", 155), ("Charlie", 175), ("David", 150)]
print(type(students))
students.sort(key=lambda x:x[1])
print(students)

# COMMAND ----------

sample = [(1, 0, 0), (4, 1, 2), (4, 2, 5), (1, 2, 1)]
sample.sort(reverse = True)
print(sample)

# COMMAND ----------

# MAGIC %md
# MAGIC # Collect List
# MAGIC

# COMMAND ----------

# MAGIC %sql 
# MAGIC create table default.Fruits (
# MAGIC 	CUS_NAME varchar(50),
# MAGIC 	FRUIT varchar(50)
# MAGIC 	)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- insert into default.Fruits values ("amit","apple");
# MAGIC -- insert into default.Fruits values ("amit","orange");
# MAGIC -- insert into default.Fruits values ("bharat","apple");
# MAGIC insert into default.Fruits values ("bharat","banana");
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from default.Fruits

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC select CUS_NAME,name 
# MAGIC from default.Fruits 
# MAGIC where (FRUIT = "apple" and  FRUIT = "orange")
# MAGIC group by CUS_NAME
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC with cte1 as (
# MAGIC select CUS_NAME,collect_list(FRUIT) as fruits
# MAGIC from default.Fruits 
# MAGIC group by CUS_NAME
# MAGIC )
# MAGIC SELECT * FROM cte1

# COMMAND ----------

spark

# COMMAND ----------

from pyspark.sql import SparkSession
sandeep = SparkSession.builder \
      .master("local[1]") \
      .appName("SparkByExamples.com") \
      .getOrCreate()
sandeep

# COMMAND ----------

dataList = [("Java", 20000), ("Python", 100000), ("Scala", 3000)]
rdd=sandeep.sparkContext.parallelize(dataList)

# COMMAND ----------

rdd.collect()

# COMMAND ----------

rdd.take(2)

# COMMAND ----------

dataList = [("Sandeep", 20000), ("Swati", 100000), ("Vaishnavi", 3000)]
rdd=spark.sparkContext.parallelize(dataList)

# COMMAND ----------

# MAGIC %md
# MAGIC #Recursive Factorial

# COMMAND ----------

def factorial(n):
  if n == 1:
    return 1
  else:
    return n * factorial(n-1)

n=5
print(factorial(n))

# COMMAND ----------

# MAGIC %md
# MAGIC #Recursive Fibonacci

# COMMAND ----------

def fib(n):
  if n == 1 or n ==2:
    return 1
  else:
    return fib(n-1)+fib(n-2)
  
print(fib(7))


# COMMAND ----------

# MAGIC %md
# MAGIC #Recursive Sumation Nested List

# COMMAND ----------

def sumList(lst):
  total=0
  for element in lst:
    if type(element) == type([]):
      total = total + sumList(element)
    else:
      total = total + element
  return total

lst =[1,2,3,[4,5],6,[7,8]]
print(sumList(lst))

# COMMAND ----------

# MAGIC %md
# MAGIC #Recursive List Sort

# COMMAND ----------

def listSort(lst):
  swap = 0
  for i in range(0,len(lst)):
    for j in range(i+1,len(lst)):
      if lst[i] > lst[j] :
        swap = lst[j]
        lst[j]=lst[i]
        lst[i]=swap
  return lst

lst = [1,4,2,3,6,5]
print(listSort(lst))

# COMMAND ----------

lst =['1', '2', '3', '4', '5']
print("input list elements: ",lst)
cnt=0
for i in range(0,len(lst),1):
    for j in range(i+1,len(lst),1):
        if lst[i] < lst[j]:
            swap = lst[j]
            lst[j]=lst[i]
            lst[i]=swap
            cnt+=1
print("Output list elements: ",lst)
print(cnt)