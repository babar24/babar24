# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC Given a zero-based permutation nums (0-indexed), build an array ans of the same length where ans[i] = nums[nums[i]] for each 0 <= i < nums.length and return it.
# MAGIC
# MAGIC A zero-based permutation nums is an array of distinct integers from 0 to nums.length - 1 (inclusive).
# MAGIC
# MAGIC  
# MAGIC
# MAGIC Example 1:
# MAGIC
# MAGIC Input: nums = [0,2,1,5,3,4]
# MAGIC Output: [0,1,2,4,5,3]
# MAGIC Explanation: The array ans is built as follows: 
# MAGIC ans = [nums[nums[0]], nums[nums[1]], nums[nums[2]], nums[nums[3]], nums[nums[4]], nums[nums[5]]]
# MAGIC     = [nums[0], nums[2], nums[1], nums[5], nums[3], nums[4]]
# MAGIC     = [0,1,2,4,5,3]
# MAGIC Example 2:
# MAGIC
# MAGIC Input: nums = [5,0,1,2,3,4]
# MAGIC Output: [4,5,0,1,2,3]
# MAGIC Explanation: The array ans is built as follows:
# MAGIC ans = [nums[nums[0]], nums[nums[1]], nums[nums[2]], nums[nums[3]], nums[nums[4]], nums[nums[5]]]
# MAGIC     = [nums[5], nums[0], nums[1], nums[2], nums[3], nums[4]]
# MAGIC     = [4,5,0,1,2,3]
# MAGIC  
# MAGIC
# MAGIC Constraints:
# MAGIC
# MAGIC 1 <= nums.length <= 1000
# MAGIC 0 <= nums[i] < nums.length
# MAGIC The elements in nums are distinct.
# MAGIC  
# MAGIC
# MAGIC Follow-up: Can you solve it without using an extra space (i.e., O(1) memory)?
# MAGIC

# COMMAND ----------

nums = int(input())
lst = []

for i in range(0, len(nums)):
  lst.append(nums[nums[i]])

print(lst)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC
# MAGIC Given an integer array nums of length n, you want to create an array ans of length 2n where ans[i] == nums[i] and ans[i + n] == nums[i] for 0 <= i < n (0-indexed).
# MAGIC
# MAGIC Specifically, ans is the concatenation of two nums arrays.
# MAGIC
# MAGIC Return the array ans.
# MAGIC
# MAGIC  
# MAGIC
# MAGIC Example 1:
# MAGIC
# MAGIC Input: nums = [1,2,1]
# MAGIC Output: [1,2,1,1,2,1]
# MAGIC Explanation: The array ans is formed as follows:
# MAGIC - ans = [nums[0],nums[1],nums[2],nums[0],nums[1],nums[2]]
# MAGIC - ans = [1,2,1,1,2,1]
# MAGIC Example 2:
# MAGIC
# MAGIC Input: nums = [1,3,2,1]
# MAGIC Output: [1,3,2,1,1,3,2,1]
# MAGIC Explanation: The array ans is formed as follows:
# MAGIC - ans = [nums[0],nums[1],nums[2],nums[3],nums[0],nums[1],nums[2],nums[3]]
# MAGIC - ans = [1,3,2,1,1,3,2,1]
# MAGIC  
# MAGIC
# MAGIC Constraints:
# MAGIC
# MAGIC n == nums.length
# MAGIC 1 <= n <= 1000
# MAGIC 1 <= nums[i] <= 1000

# COMMAND ----------

# MAGIC %md
# MAGIC Given the array nums consisting of 2n elements in the form [x1,x2,...,xn,y1,y2,...,yn].
# MAGIC
# MAGIC Return the array in the form [x1,y1,x2,y2,...,xn,yn].
# MAGIC
# MAGIC  
# MAGIC
# MAGIC Example 1:
# MAGIC
# MAGIC Input: nums = [2,5,1,3,4,7], n = 3
# MAGIC Output: [2,3,5,4,1,7] 
# MAGIC Explanation: Since x1=2, x2=5, x3=1, y1=3, y2=4, y3=7 then the answer is [2,3,5,4,1,7].
# MAGIC Example 2:
# MAGIC
# MAGIC Input: nums = [1,2,3,4,4,3,2,1], n = 4
# MAGIC Output: [1,4,2,3,3,2,4,1]
# MAGIC Example 3:
# MAGIC
# MAGIC Input: nums = [1,1,2,2], n = 2
# MAGIC Output: [1,2,1,2]
# MAGIC  
# MAGIC
# MAGIC Constraints:
# MAGIC
# MAGIC 1 <= n <= 500
# MAGIC nums.length == 2n
# MAGIC 1 <= nums[i] <= 10^3

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC There is a programming language with only four operations and one variable X:
# MAGIC
# MAGIC ++X and X++ increments the value of the variable X by 1.
# MAGIC --X and X-- decrements the value of the variable X by 1.
# MAGIC Initially, the value of X is 0.
# MAGIC
# MAGIC Given an array of strings operations containing a list of operations, return the final value of X after performing all the operations.
# MAGIC
# MAGIC  
# MAGIC
# MAGIC Example 1:
# MAGIC
# MAGIC Input: operations = ["--X","X++","X++"]
# MAGIC Output: 1
# MAGIC Explanation: The operations are performed as follows:
# MAGIC Initially, X = 0.
# MAGIC --X: X is decremented by 1, X =  0 - 1 = -1.
# MAGIC X++: X is incremented by 1, X = -1 + 1 =  0.
# MAGIC X++: X is incremented by 1, X =  0 + 1 =  1.
# MAGIC Example 2:
# MAGIC
# MAGIC Input: operations = ["++X","++X","X++"]
# MAGIC Output: 3
# MAGIC Explanation: The operations are performed as follows:
# MAGIC Initially, X = 0.
# MAGIC ++X: X is incremented by 1, X = 0 + 1 = 1.
# MAGIC ++X: X is incremented by 1, X = 1 + 1 = 2.
# MAGIC X++: X is incremented by 1, X = 2 + 1 = 3.
# MAGIC Example 3:
# MAGIC
# MAGIC Input: operations = ["X++","++X","--X","X--"]
# MAGIC Output: 0
# MAGIC Explanation: The operations are performed as follows:
# MAGIC Initially, X = 0.
# MAGIC X++: X is incremented by 1, X = 0 + 1 = 1.
# MAGIC ++X: X is incremented by 1, X = 1 + 1 = 2.
# MAGIC --X: X is decremented by 1, X = 2 - 1 = 1.
# MAGIC X--: X is decremented by 1, X = 1 - 1 = 0.
# MAGIC  
# MAGIC
# MAGIC Constraints:
# MAGIC
# MAGIC 1 <= operations.length <= 100
# MAGIC operations[i] will be either "++X", "X++", "--X", or "X--".
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Given an array of integers nums, return the number of good pairs.
# MAGIC
# MAGIC A pair (i, j) is called good if nums[i] == nums[j] and i < j.
# MAGIC
# MAGIC  
# MAGIC
# MAGIC Example 1:
# MAGIC
# MAGIC Input: nums = [1,2,3,1,1,3]
# MAGIC Output: 4
# MAGIC Explanation: There are 4 good pairs (0,3), (0,4), (3,4), (2,5) 0-indexed.
# MAGIC Example 2:
# MAGIC
# MAGIC Input: nums = [1,1,1,1]
# MAGIC Output: 6
# MAGIC Explanation: Each pair in the array are good.
# MAGIC Example 3:
# MAGIC
# MAGIC Input: nums = [1,2,3]
# MAGIC Output: 0
# MAGIC  
# MAGIC
# MAGIC Constraints:
# MAGIC
# MAGIC 1 <= nums.length <= 100
# MAGIC 1 <= nums[i] <= 100
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.
# MAGIC
# MAGIC You may assume that each input would have exactly one solution, and you may not use the same element twice.
# MAGIC
# MAGIC You can return the answer in any order.
# MAGIC
# MAGIC  
# MAGIC
# MAGIC Example 1:
# MAGIC
# MAGIC Input: nums = [2,7,11,15], target = 9
# MAGIC Output: [0,1]
# MAGIC Explanation: Because nums[0] + nums[1] == 9, we return [0, 1].
# MAGIC Example 2:
# MAGIC
# MAGIC Input: nums = [3,2,4], target = 6
# MAGIC Output: [1,2]
# MAGIC Example 3:
# MAGIC
# MAGIC Input: nums = [3,3], target = 6
# MAGIC Output: [0,1]
# MAGIC  
# MAGIC
# MAGIC Constraints:
# MAGIC
# MAGIC 2 <= nums.length <= 104
# MAGIC -109 <= nums[i] <= 109
# MAGIC -109 <= target <= 109
# MAGIC Only one valid answer exists.
# MAGIC  
# MAGIC
# MAGIC Follow-up: Can you come up with an algorithm that is less than O(n2) time complexity?
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Given two integer arrays nums1 and nums2, return an array of their intersection. Each element in the result must appear as many times as it shows in both arrays and you may return the result in any order.
# MAGIC
# MAGIC  
# MAGIC
# MAGIC Example 1:
# MAGIC
# MAGIC Input: nums1 = [1,2,2,1], nums2 = [2,2]
# MAGIC Output: [2,2]
# MAGIC Example 2:
# MAGIC
# MAGIC Input: nums1 = [4,9,5], nums2 = [9,4,9,8,4]
# MAGIC Output: [4,9]
# MAGIC Explanation: [9,4] is also accepted.
# MAGIC  
# MAGIC
# MAGIC Constraints:
# MAGIC
# MAGIC 1 <= nums1.length, nums2.length <= 1000
# MAGIC 0 <= nums1[i], nums2[i] <= 1000
# MAGIC  
# MAGIC
# MAGIC Follow up:
# MAGIC
# MAGIC What if the given array is already sorted? How would you optimize your algorithm?
# MAGIC What if nums1's size is small compared to nums2's size? Which algorithm is better?
# MAGIC What if elements of nums2 are stored on disk, and the memory is limited such that you cannot load all elements into the memory at once?
# MAGIC

# COMMAND ----------

